<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>Internship Report Portal — Kongu Engineering College</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:#f4f6f8;min-height:100vh;color:#1a1a1a}

/* ── HEADER ── */
.header{background:linear-gradient(135deg,#0a3d20 0%,#1a7a4a 60%,#27ae60 100%);padding:28px 20px 36px;text-align:center}
.header .logo{font-size:22px;margin-bottom:6px}
.header h1{font-size:22px;font-weight:700;color:#fff;letter-spacing:0.5px}
.header p{font-size:13px;color:rgba(255,255,255,0.72);margin-top:4px}
.prog-track{background:rgba(255,255,255,0.2);height:4px;border-radius:2px;margin:18px 20px 0}
.prog-fill{background:#fff;height:4px;border-radius:2px;width:14%;transition:width .4s ease}
.prog-txt{font-size:11px;color:rgba(255,255,255,0.65);text-align:right;padding:5px 20px 0}

/* ── STEPPER NAV ── */
.steps-nav{display:flex;gap:0;overflow-x:auto;padding:20px 20px 0;scrollbar-width:none;background:#f4f6f8}
.steps-nav::-webkit-scrollbar{display:none}
.step-btn{flex:1;min-width:90px;text-align:center;padding:10px 6px 12px;font-size:11px;font-weight:600;
  color:#aaa;border-bottom:3px solid #ddd;cursor:pointer;transition:all .2s;background:none;border-top:none;border-left:none;border-right:none;font-family:inherit;white-space:nowrap}
.step-btn .snum{display:block;width:26px;height:26px;border-radius:50%;background:#e0e0e0;color:#999;
  font-size:12px;font-weight:700;line-height:26px;margin:0 auto 5px;transition:all .2s}
.step-btn.active{color:#1a7a4a;border-bottom-color:#1a7a4a}
.step-btn.active .snum{background:#1a7a4a;color:#fff}
.step-btn.done{color:#27ae60;border-bottom-color:#27ae60}
.step-btn.done .snum{background:#27ae60;color:#fff}

/* ── CARD ── */
.card{background:#fff;border-radius:0 0 14px 14px;margin:0 20px 30px;padding:24px;box-shadow:0 2px 12px rgba(0,0,0,0.07)}

/* ── SECTION HEADER ── */
.sec-head{display:flex;align-items:center;gap:10px;margin-bottom:6px}
.sec-icon{width:36px;height:36px;border-radius:10px;background:#e8f8f0;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.sec-title{font-size:16px;font-weight:700;color:#0a3d20}
.sec-sub{font-size:12px;color:#999;margin-bottom:20px;padding-left:46px}

/* ── DIVIDER ── */
.divider{height:1px;background:#f0f0f0;margin:16px 0}

/* ── FIELDS ── */
.row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
@media(max-width:480px){.row{grid-template-columns:1fr}}
.field{margin-bottom:14px}
.field label{display:block;font-size:12px;font-weight:600;color:#555;margin-bottom:5px;text-transform:uppercase;letter-spacing:0.3px}
.field input,.field textarea,.field select{
  width:100%;padding:11px 13px;font-size:14px;color:#1a1a1a;
  border:1.5px solid #e4e8ec;border-radius:9px;background:#fafbfc;
  outline:none;transition:border .2s,background .2s;font-family:inherit
}
.field input:focus,.field textarea:focus,.field select:focus{border-color:#1a7a4a;background:#fff}
.field textarea{min-height:90px;resize:vertical;line-height:1.6}
.req{color:#e74c3c;margin-left:2px}

/* ── SUBSECTION LABEL ── */
.sub-label{font-size:12px;font-weight:700;color:#1a7a4a;text-transform:uppercase;letter-spacing:0.5px;margin:18px 0 10px;display:flex;align-items:center;gap:6px}
.sub-label::after{content:'';flex:1;height:1px;background:#e8f8f0}

/* ── CHIPS ── */
.chip-row{display:flex;flex-wrap:wrap;gap:8px;margin-top:6px}
.chip{padding:7px 15px;border-radius:20px;font-size:13px;
  border:1.5px solid #dde;cursor:pointer;background:#f7f8fa;color:#555;transition:all .2s;user-select:none}
.chip:hover{border-color:#1a7a4a;color:#1a7a4a}
.chip.on{background:#1a7a4a;color:#fff;border-color:#1a7a4a}

/* ── TAG INPUT ── */
.tag-box{display:flex;flex-wrap:wrap;gap:7px;padding:8px 10px;
  border:1.5px solid #e4e8ec;border-radius:9px;background:#fafbfc;min-height:46px;cursor:text}
.tag-box:focus-within{border-color:#1a7a4a;background:#fff}
.tag-box input{border:none;background:transparent;outline:none;font-size:14px;flex:1;min-width:80px;color:#1a1a1a;font-family:inherit;padding:2px 0}
.tag{background:#e8f8f0;color:#0a5c2a;font-size:12px;font-weight:600;padding:4px 10px;
  border-radius:20px;display:flex;align-items:center;gap:5px}
.tag .x{cursor:pointer;font-size:16px;line-height:1;opacity:0.6}
.tag .x:hover{opacity:1}

/* ── BUTTONS ── */
.btn-row{display:flex;gap:10px;margin-top:20px;justify-content:space-between;align-items:center}
.btn{padding:11px 24px;font-size:14px;font-weight:600;border-radius:9px;
  cursor:pointer;font-family:inherit;transition:all .2s;border:1.5px solid}
.btn-ghost{background:#fff;color:#555;border-color:#dde}
.btn-ghost:hover{background:#f4f6f8;border-color:#bbb}
.btn-primary{background:#1a7a4a;color:#fff;border-color:#1a7a4a}
.btn-primary:hover{background:#0d5c34}
.btn-primary:disabled{opacity:.5;cursor:not-allowed}
.btn-full{flex:1}

/* ── SUCCESS ── */
.success{display:none;text-align:center;padding:40px 20px}
.tick{font-size:56px;display:block;margin-bottom:12px}
.success h2{font-size:20px;font-weight:700;color:#0a3d20;margin-bottom:6px}
.success p{font-size:14px;color:#777;margin-bottom:24px}
.meta-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;text-align:left;margin-top:20px}
@media(max-width:400px){.meta-grid{grid-template-columns:1fr}}
.meta-box{background:#f0faf4;border:1px solid #c8e6d4;border-radius:10px;padding:12px 14px}
.meta-box span{font-size:11px;color:#888;text-transform:uppercase;letter-spacing:0.3px;display:block;margin-bottom:2px}
.meta-box strong{font-size:14px;color:#0a3d20;font-weight:600;word-break:break-word}

/* ── TOAST ── */
.toast{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);
  background:#0a3d20;color:#fff;padding:12px 24px;border-radius:10px;
  font-size:14px;display:none;z-index:999;white-space:nowrap;box-shadow:0 4px 20px rgba(0,0,0,.2)}
.toast.err{background:#c0392b}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
  <div class="logo">✦</div>
  <h1>INTERNSHIP REPORT PORTAL</h1>
  <p>Kongu Engineering College &nbsp;|&nbsp; Industry Ready Portal</p>
  <div class="prog-track"><div class="prog-fill" id="prog"></div></div>
  <div class="prog-txt" id="progTxt">Step 1 of 7</div>
</div>

<!-- STEPPER -->
<div class="steps-nav" id="stepsNav">
  <button class="step-btn active" onclick="goTab(0)"><span class="snum">1</span>Student</button>
  <button class="step-btn" onclick="goTab(1)"><span class="snum">2</span>Company</button>
  <button class="step-btn" onclick="goTab(2)"><span class="snum">3</span>Training</button>
  <button class="step-btn" onclick="goTab(3)"><span class="snum">4</span>Need</button>
  <button class="step-btn" onclick="goTab(4)"><span class="snum">5</span>Tools</button>
  <button class="step-btn" onclick="goTab(5)"><span class="snum">6</span>Phases</button>
  <button class="step-btn" onclick="goTab(6)"><span class="snum">7</span>Conclusion</button>
</div>

<!-- MAIN CARD -->
<div class="card" id="mainCard">

<!-- ═══ TAB 0 — STUDENT INFO ═══ -->
<div id="tab0">
  <div class="sec-head"><div class="sec-icon">🎓</div><div class="sec-title">Student Info & Abstract</div></div>
  <div class="sec-sub">Chapter 1 — Basic details and project abstract</div>

  <div class="row">
    <div class="field"><label>Student Name <span class="req">*</span></label><input id="student_name" placeholder="Enter full name"/></div>
    <div class="field"><label>Register Number <span class="req">*</span></label><input id="reg_no" placeholder="e.g. 21CSR001"/></div>
  </div>
  <div class="row">
    <div class="field"><label>Department</label><input id="dept" placeholder="e.g. CSE, IT, ECE"/></div>
    <div class="field"><label>Year & Semester</label><input id="year_sem" placeholder="e.g. 3rd Year, 6th Sem"/></div>
  </div>
  <div class="field"><label>Academic Year</label><input id="acad_year" placeholder="e.g. 2025–2026"/></div>
  <div class="field"><label>Abstract <span class="req">*</span></label><textarea id="abstract" placeholder="Brief summary of your internship project and what you worked on..."></textarea></div>

  <div class="btn-row"><div></div><button class="btn btn-primary" onclick="next(0)">Next →</button></div>
</div>

<!-- ═══ TAB 1 — COMPANY ═══ -->
<div id="tab1" style="display:none">
  <div class="sec-head"><div class="sec-icon">🏢</div><div class="sec-title">About the Company</div></div>
  <div class="sec-sub">Chapter 2 — Company information and mentor details</div>

  <div class="field"><label>Company Name <span class="req">*</span></label><input id="company_name" placeholder="e.g. TechCorp Pvt Ltd"/></div>
  <div class="row">
    <div class="field"><label>Location</label><input id="company_location" placeholder="City, State"/></div>
    <div class="field"><label>Industry Type</label><input id="industry_type" placeholder="e.g. IT / Software"/></div>
  </div>
  <div class="field"><label>Company Website</label><input id="company_web" placeholder="https://..."/></div>
  <div class="field"><label>Company Overview</label><textarea id="company_overview" placeholder="What does the company do? Products, services, clients..."></textarea></div>
  <div class="divider"></div>
  <div class="sub-label">Mentor Details</div>
  <div class="row">
    <div class="field"><label>Mentor Name</label><input id="mentor_name" placeholder="Industry mentor full name"/></div>
    <div class="field"><label>Mentor Designation</label><input id="mentor_desig" placeholder="e.g. Senior Developer"/></div>
  </div>

  <div class="btn-row"><button class="btn btn-ghost" onclick="prev(1)">← Back</button><button class="btn btn-primary" onclick="next(1)">Next →</button></div>
</div>

<!-- ═══ TAB 2 — TRAINING ═══ -->
<div id="tab2" style="display:none">
  <div class="sec-head"><div class="sec-icon">📋</div><div class="sec-title">Training Details</div></div>
  <div class="sec-sub">Chapter 3 — Duration, mode and overview of your training</div>

  <div class="row">
    <div class="field"><label>Start Date</label><input type="date" id="start_date"/></div>
    <div class="field"><label>End Date</label><input type="date" id="end_date"/></div>
  </div>
  <div class="row">
    <div class="field"><label>Duration</label><input id="duration" placeholder="e.g. 60 days / 2 months"/></div>
    <div class="field"><label>Mode</label>
      <select id="mode"><option value="">Select mode</option><option>On-site</option><option>Remote</option><option>Hybrid</option></select>
    </div>
  </div>
  <div class="field"><label>3.1 Overview of Training</label><textarea id="training_overview" rows="4" placeholder="Describe your daily work, project structure, team, responsibilities..."></textarea></div>

  <div class="btn-row"><button class="btn btn-ghost" onclick="prev(2)">← Back</button><button class="btn btn-primary" onclick="next(2)">Next →</button></div>
</div>

<!-- ═══ TAB 3 — NEED FOR TRAINING ═══ -->
<div id="tab3" style="display:none">
  <div class="sec-head"><div class="sec-icon">💡</div><div class="sec-title">Need for Training</div></div>
  <div class="sec-sub">Chapter 4 — Why this internship was important</div>

  <div class="field"><label>4.1 Skill Development in Modern Technology</label><textarea id="sec41" placeholder="How did this internship help you develop skills in modern technologies?"></textarea></div>
  <div class="field"><label>4.2 Understanding Industry Level Development Practices</label><textarea id="sec42" placeholder="What industry-level practices did you observe, learn and follow?"></textarea></div>
  <div class="field"><label>4.3 Bridging the Gap Between Theory and Practical Implementation</label><textarea id="sec43" placeholder="How was real-world work different from what you learned in class?"></textarea></div>

  <div class="btn-row"><button class="btn btn-ghost" onclick="prev(3)">← Back</button><button class="btn btn-primary" onclick="next(3)">Next →</button></div>
</div>

<!-- ═══ TAB 4 — FRAMEWORKS & TOOLS ═══ -->
<div id="tab4" style="display:none">
  <div class="sec-head"><div class="sec-icon">🛠️</div><div class="sec-title">Frameworks & Tools Learned</div></div>
  <div class="sec-sub">Chapter 5 — Select tools used and describe your experience</div>

  <div class="field">
    <label>Tools Used — select all that apply</label>
    <div class="chip-row" id="toolChips">
      <div class="chip" onclick="toggleChip(this)">Python</div>
      <div class="chip" onclick="toggleChip(this)">Flask</div>
      <div class="chip" onclick="toggleChip(this)">Docker</div>
      <div class="chip" onclick="toggleChip(this)">Redis</div>
      <div class="chip" onclick="toggleChip(this)">Celery</div>
      <div class="chip" onclick="toggleChip(this)">OpenSearch</div>
      <div class="chip" onclick="toggleChip(this)">MySQL</div>
      <div class="chip" onclick="toggleChip(this)">PostgreSQL</div>
      <div class="chip" onclick="toggleChip(this)">Google ADK</div>
      <div class="chip" onclick="toggleChip(this)">WhatsApp API</div>
      <div class="chip" onclick="toggleChip(this)">Git</div>
    </div>
  </div>
  <div class="field">
    <label>Other Tools — type and press Enter</label>
    <div class="tag-box" id="extraWrap" onclick="document.getElementById('extraIn').focus()">
      <input id="extraIn" placeholder="Add more tools..." onkeydown="addTag(event,'extraIn','extraWrap',extraTools)"/>
    </div>
  </div>
  <div class="field"><label>Tools Experience Description</label><textarea id="tools_desc" placeholder="Describe how you used these tools in your project..."></textarea></div>

  <div class="btn-row"><button class="btn btn-ghost" onclick="prev(4)">← Back</button><button class="btn btn-primary" onclick="next(4)">Next →</button></div>
</div>

<!-- ═══ TAB 5 — PHASES ═══ -->
<div id="tab5" style="display:none">
  <div class="sec-head"><div class="sec-icon">📅</div><div class="sec-title">Training & Implementation Phases</div></div>
  <div class="sec-sub">Chapter 6 — Describe each phase of your training</div>

  <div class="sub-label">Phase 1</div>
  <div class="field"><label>6.1 Technology Familiarization & Environmental Setup</label><textarea id="phase1" placeholder="What did you set up? How did you get started with the tech stack? Docker, virtualenv, IDE..."></textarea></div>

  <div class="sub-label">Phase 2</div>
  <div class="field"><label>6.2 Backend Development & API Integration</label><textarea id="phase2" placeholder="What backend features did you build? Which APIs did you integrate? Flask routes, DB models..."></textarea></div>

  <div class="sub-label">Phase 3</div>
  <div class="field"><label>6.3 Asynchronous Processing & Task Management</label><textarea id="phase3" placeholder="How did you handle async tasks? Celery workers, Redis queues, background jobs..."></textarea></div>

  <div class="sub-label">Phase 4</div>
  <div class="field"><label>6.4 Integration, Testing & Deployment Practices</label><textarea id="phase4" placeholder="Testing methods used, how was it deployed? Docker Compose, CI/CD, Git..."></textarea></div>

  <div class="btn-row"><button class="btn btn-ghost" onclick="prev(5)">← Back</button><button class="btn btn-primary" onclick="next(5)">Next →</button></div>
</div>

<!-- ═══ TAB 6 — CONCLUSION ═══ -->
<div id="tab6" style="display:none">
  <div class="sec-head"><div class="sec-icon">🏆</div><div class="sec-title">Conclusion & Final Details</div></div>
  <div class="sec-sub">Chapter 7, 8 & 9 — Wrap up your internship report</div>

  <div class="field"><label>7.1 Summary of Learnings</label><textarea id="summary" placeholder="Key takeaways and highlights from the entire internship..."></textarea></div>
  <div class="field">
    <label>7.2 Skills Gained — type and press Enter</label>
    <div class="tag-box" id="skillsWrap" onclick="document.getElementById('skillIn').focus()">
      <input id="skillIn" placeholder="Add a skill..." onkeydown="addTag(event,'skillIn','skillsWrap',skillTags)"/>
    </div>
  </div>
  <div class="field"><label>7.3 Future Scope</label><textarea id="future_scope" rows="2" placeholder="How will this internship help your future career?"></textarea></div>
  <div class="divider"></div>
  <div class="sub-label">Offer Letter & SDG Goals</div>
  <div class="row">
    <div class="field"><label>Offer Letter No. (Chapter 8)</label><input id="offer_letter_no" placeholder="Reference number"/></div>
    <div class="field"><label>SDG Goals (Chapter 9)</label><input id="sdg_goals" placeholder="e.g. SDG 4, SDG 9"/></div>
  </div>
  <div class="field"><label>SDG Mapping Explanation</label><textarea id="sdg_explain" rows="2" placeholder="How does your internship align with these UN SDG goals?"></textarea></div>

  <div class="btn-row">
    <button class="btn btn-ghost" onclick="prev(6)">← Back</button>
    <button class="btn btn-primary btn-full" id="subBtn" onclick="submitForm()">💾 Save & Submit to Database</button>
  </div>
</div>

</div><!-- /card -->

<!-- SUCCESS -->
<div class="success" id="successBox">
  <span class="tick">✅</span>
  <h2>Report Submitted Successfully!</h2>
  <p>All 7 chapters have been saved to the database.</p>
  <button class="btn btn-primary" onclick="location.reload()">+ Submit Another Report</button>
  <div class="meta-grid" id="metaGrid"></div>
</div>

<div class="toast" id="toast"></div>

<script>
let cur=0;const T=7;const extraTools=[];const skillTags=[];

function showTab(n){
  for(let i=0;i<T;i++){
    document.getElementById('tab'+i).style.display=i===n?'block':'none';
    const b=document.querySelectorAll('.step-btn')[i];
    b.classList.toggle('active',i===n);
  }
  cur=n;
  document.getElementById('prog').style.width=Math.round(((n+1)/T)*100)+'%';
  document.getElementById('progTxt').textContent='Step '+(n+1)+' of '+T;
  window.scrollTo(0,0);
}
function next(n){
  if(n===0){
    if(!v('student_name')){toast('Student name is required',1);return;}
    if(!v('reg_no')){toast('Register number is required',1);return;}
  }
  document.querySelectorAll('.step-btn')[n].classList.add('done');
  if(n<T-1)showTab(n+1);
}
function prev(n){if(n>0)showTab(n-1);}
function goTab(n){showTab(n);}
function toggleChip(el){el.classList.toggle('on');}
function addTag(e,inp,wrap,arr){
  if(e.key==='Enter'||e.key===','){
    e.preventDefault();
    const val=e.target.value.trim();if(!val)return;
    arr.push(val);
    const t=document.createElement('div');t.className='tag';
    t.innerHTML=val+'<span class="x" onclick="this.parentElement.remove()">×</span>';
    document.getElementById(wrap).insertBefore(t,e.target);
    e.target.value='';
  }
}
function v(id){return(document.getElementById(id)||{}).value||'';}
function chips(){return Array.from(document.querySelectorAll('#toolChips .chip.on')).map(c=>c.textContent);}
function toast(msg,err){
  const t=document.getElementById('toast');t.textContent=msg;
  t.className='toast'+(err?' err':'');t.style.display='block';
  setTimeout(()=>t.style.display='none',3000);
}
function submitForm(){
  const btn=document.getElementById('subBtn');
  btn.disabled=true;btn.textContent='Saving...';
  const p={
    student_name:v('student_name'),reg_no:v('reg_no'),dept:v('dept'),
    year_sem:v('year_sem'),acad_year:v('acad_year'),abstract:v('abstract'),
    company_name:v('company_name'),company_location:v('company_location'),
    industry_type:v('industry_type'),company_web:v('company_web'),
    company_overview:v('company_overview'),mentor_name:v('mentor_name'),
    mentor_desig:v('mentor_desig'),start_date:v('start_date'),
    end_date:v('end_date'),duration:v('duration'),mode:v('mode'),
    training_overview:v('training_overview'),sec41:v('sec41'),
    sec42:v('sec42'),sec43:v('sec43'),tools_used:chips(),
    extra_tools:[...extraTools],tools_desc:v('tools_desc'),
    phase1:v('phase1'),phase2:v('phase2'),phase3:v('phase3'),phase4:v('phase4'),
    summary:v('summary'),skills_gained:[...skillTags],
    future_scope:v('future_scope'),offer_letter_no:v('offer_letter_no'),
    sdg_goals:v('sdg_goals'),sdg_explain:v('sdg_explain')
  };
  fetch('submit.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)})
  .then(r=>r.json())
  .then(res=>{
    if(res.status==='success'){
      document.getElementById('mainCard').style.display='none';
      document.getElementById('stepsNav').style.display='none';
      document.getElementById('successBox').style.display='block';
      document.getElementById('prog').style.width='100%';
      document.getElementById('progTxt').textContent='Completed!';
      const rows=[['Student',p.student_name],['Reg No',p.reg_no],['Department',p.dept],
        ['Company',p.company_name],['Duration',p.duration],['Mode',p.mode],
        ['Tools',(p.tools_used||[]).join(', ')],['Skills',(p.skills_gained||[]).join(', ')]];
      document.getElementById('metaGrid').innerHTML=rows.filter(r=>r[1])
        .map(r=>`<div class="meta-box"><span>${r[0]}</span><strong>${r[1]}</strong></div>`).join('');
    } else {
      toast('Error: '+res.message,1);
      btn.disabled=false;btn.textContent='💾 Save & Submit to Database';
    }
  })
  .catch(()=>{
    toast('Network error — check PHP server',1);
    btn.disabled=false;btn.textContent='💾 Save & Submit to Database';
  });
}
showTab(0);
</script>
</body>
</html>