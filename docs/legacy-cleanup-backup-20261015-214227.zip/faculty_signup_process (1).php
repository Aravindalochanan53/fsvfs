<?php

$host     = "localhost";
$user     = "root";
$password = "";
$database = "internship";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}

$roll_number      = $_POST['roll_number'];   // Kongu ID
$student_name     = $_POST['student_name'];  // Faculty Name
$department       = $_POST['department'];
$raw_password     = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

/* CHECK PASSWORD MATCH */
if ($raw_password != $confirm_password) {
    echo "
    <script>
        alert('Password and Confirm Password do not match!');
        window.history.back();
    </script>
    ";
    exit();
}

/* HASH PASSWORD */
$hashed = password_hash($raw_password, PASSWORD_DEFAULT);

/* INSERT INTO faculty_signup */
$sql = "INSERT INTO faculty_signup
        (roll_number, student_name, password, department)
        VALUES
        ('$roll_number', '$student_name', '$hashed', '$department')";

if (mysqli_query($conn, $sql)) {
    echo "
    <script>
        alert('Faculty account created successfully!');
        window.location.href='facultylogin.php';
    </script>
    ";
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);

?>
