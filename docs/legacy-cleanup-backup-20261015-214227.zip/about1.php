<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>About Us | KEC Internship Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
    --blue-900: #041b11;
    --blue-800: #072b18;
    --blue-700: #0b4425;
    --blue-600: #116530;
    --blue-500: #15803d;
    --blue-400: #22c55e;
    --blue-300: #4ade80;
    --blue-100: #dcfce7;
    --blue-50:  #f0fdf4;

    --accent:   #86efac;

    --white:    #ffffff;

    --text-dark: #0b1d13;
    --text-mid:  #36543d;
    --text-muted:#5f7d66;
}

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'DM Sans', sans-serif;
            background: #f0f6ff;
            color: var(--text-dark);
        }

        /* ---- HEADER ---- */
        .site-header {
            background: linear-gradient(135deg, var(--blue-900) 0%, var(--blue-700) 60%, var(--blue-500) 100%);
            padding: 18px 20px 14px;
            text-align: center;
            position: sticky;
            top: 0;
            z-index: 1030;
            box-shadow: 0 4px 24px rgba(10,22,40,0.35);
        }
        .site-header h1 {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 1.9rem;
            letter-spacing: 3px;
            color: #fff;
            text-transform: uppercase;
        }
        .site-header p {
            font-size: 0.85rem;
            color: var(--blue-300);
            margin-top: 2px;
            letter-spacing: 0.5px;
        }
        .header-line {
            width: 60px;
            height: 3px;
            background: var(--accent);
            margin: 8px auto 0;
            border-radius: 2px;
        }

        /* ---- NAVBAR ---- */
        
        .site-nav { background: var(--white); border-bottom: 2px solid var(--blue-100); position: sticky; top: 78px; z-index: 1020; box-shadow: 0 2px 12px rgba(18,81,181,0.08); }
        .site-nav nav { display: flex; justify-content: center; gap: 10px; padding: 10px 16px; flex-wrap: wrap; }
        .site-nav .nav-btn { font-family: 'Sora', sans-serif; font-weight: 600; font-size: 0.82rem; letter-spacing: 0.5px; color: var(--blue-600); border: 2px solid var(--blue-100); background: var(--blue-50); border-radius: 40px; padding: 7px 20px; text-decoration: none; transition: all 0.22s ease; white-space: nowrap; }
        .site-nav .nav-btn:hover, .site-nav .nav-btn.active { background: var(--blue-600); color: #fff; border-color: var(--blue-600); box-shadow: 0 4px 16px rgba(18,81,181,0.3); transform: translateY(-1px); }


        /* ---- PAGE HERO BANNER ---- */
        .page-hero {
            background: linear-gradient(135deg, var(--blue-800) 0%, var(--blue-600) 60%, var(--blue-400) 100%);
            padding: 64px 20px 56px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .page-hero::before {
            content: '';
            position: absolute;
            inset: 0;
            background: url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1400&q=60') center/cover no-repeat;
            opacity: 0.12;
        }
        .page-hero-content { position: relative; z-index: 2; }
        .page-hero h2 {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 2.6rem;
            color: #fff;
            letter-spacing: 1px;
            margin-bottom: 14px;
        }
        .page-hero h2 span { color: var(--accent); }
        .page-hero p {
            color: var(--blue-100);
            font-size: 1.05rem;
            max-width: 640px;
            margin: 0 auto;
            line-height: 1.7;
        }
        .hero-accent-line {
            width: 70px;
            height: 4px;
            background: var(--accent);
            border-radius: 3px;
            margin: 18px auto 0;
        }

        /* ---- SECTION TITLES ---- */
        .section-title {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 1.9rem;
            color: var(--blue-800);
            text-align: center;
            margin-bottom: 8px;
        }
        .section-sub {
            text-align: center;
            color: var(--text-muted);
            font-size: 1rem;
            margin-bottom: 36px;
        }

        /* ---- COLLEGE ABOUT SECTION ---- */
        .college-section {
            max-width: 1200px;
            margin: 56px auto 0;
            padding: 0 20px;
        }
        .college-card {
            background: var(--white);
            border-radius: 24px;
            padding: 40px 40px;
            border: 1.5px solid var(--blue-100);
            box-shadow: 0 8px 32px rgba(18,81,181,0.07);
            display: flex;
            gap: 40px;
            align-items: center;
        }
        .college-img-wrap {
            flex-shrink: 0;
            position: relative;
        }
        .college-img-bg {
            width: 260px;
            height: 260px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--blue-100), var(--blue-300));
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        .college-img {
            width: 240px;
            height: 240px;
            border-radius: 50%;
            object-fit: cover;
            border: 5px solid #fff;
            box-shadow: 0 20px 48px rgba(10,22,40,0.2);
            position: relative;
            z-index: 2;
            transition: transform 0.3s;
        }
        .college-img:hover { transform: scale(1.03); }
        .college-body h3 {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 1.7rem;
            color: var(--blue-800);
            margin-bottom: 12px;
        }
        .college-body h3 span { color: var(--blue-500); }
        .college-body p {
            color: var(--text-mid);
            font-size: 0.98rem;
            line-height: 1.75;
            margin-bottom: 10px;
        }
        .info-pill-row { margin-top: 18px; display: flex; flex-wrap: wrap; gap: 10px; }
        .info-pill {
            background: var(--blue-50);
            color: var(--blue-700);
            border: 1.5px solid var(--blue-100);
            border-radius: 40px;
            padding: 6px 18px;
            font-size: 0.84rem;
            font-weight: 600;
            font-family: 'Sora', sans-serif;
        }

        /* ---- STATS BAND ---- */
        .stats-band {
            background: linear-gradient(135deg, var(--blue-800), var(--blue-600));
            margin: 56px 0 0;
            padding: 48px 20px;
            text-align: center;
        }
        .stats-grid {
            max-width: 1000px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 24px;
        }
        .stat-box { padding: 10px 8px; }
        .stat-number {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 2.4rem;
            color: var(--accent);
            line-height: 1;
        }
        .stat-label {
            color: var(--blue-100);
            font-size: 0.88rem;
            margin-top: 6px;
            line-height: 1.4;
        }

        /* ---- VISION MISSION CARDS ---- */
        .vm-section {
            max-width: 1200px;
            margin: 56px auto 0;
            padding: 0 20px;
        }
        .vm-card {
            background: var(--white);
            border-radius: 20px;
            padding: 32px 28px;
            border: 1.5px solid var(--blue-100);
            box-shadow: 0 4px 20px rgba(18,81,181,0.07);
            height: 100%;
            transition: all 0.25s;
            text-align: center;
        }
        .vm-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 16px 40px rgba(18,81,181,0.15);
            border-color: var(--blue-300);
        }
        .vm-icon {
            font-size: 2.6rem;
            display: block;
            margin-bottom: 14px;
        }
        .vm-card h4 {
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 1.15rem;
            color: var(--blue-700);
            margin-bottom: 12px;
        }
        .vm-card p { color: var(--text-muted); font-size: 0.94rem; line-height: 1.65; }

        /* ---- INFO BAND ---- */
        .info-band {
            background: linear-gradient(135deg, var(--blue-800), var(--blue-600));
            margin: 56px 0 0;
            padding: 52px 20px;
            text-align: center;
        }
        .info-band h2 {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 1.8rem;
            color: #fff;
            margin-bottom: 14px;
        }
        .info-band p {
            color: var(--blue-100);
            font-size: 1.02rem;
            max-width: 720px;
            margin: 0 auto;
            line-height: 1.7;
        }

        /* ---- GRID CARDS ---- */
        .grid-section {
            max-width: 1200px;
            margin: 56px auto 0;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
        }
        .grid-card {
            background: var(--white);
            border-radius: 20px;
            padding: 28px 24px;
            border: 1.5px solid var(--blue-100);
            box-shadow: 0 4px 16px rgba(18,81,181,0.06);
            transition: all 0.25s;
        }
        .grid-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(18,81,181,0.14);
            border-color: var(--blue-400);
        }
        .grid-card-title {
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 1.05rem;
            color: var(--blue-700);
            margin-bottom: 16px;
            padding-bottom: 10px;
            border-bottom: 3px solid var(--blue-100);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .grid-card ul { list-style: none; padding: 0; }
        .grid-card ul li {
            padding: 7px 0 7px 28px;
            position: relative;
            font-size: 0.93rem;
            color: var(--text-mid);
            border-bottom: 1px solid #f0f6ff;
        }
        .grid-card ul li:last-child { border-bottom: none; }
        .grid-card ul li::before {
            content: "✓";
            color: var(--blue-500);
            font-weight: 700;
            position: absolute;
            left: 0;
        }

        /* ---- PORTAL OVERVIEW BAND ---- */
        .overview-band {
            background: var(--white);
            border: 1.5px solid var(--blue-100);
            border-radius: 24px;
            max-width: 1100px;
            margin: 56px auto 0;
            padding: 48px 36px;
            text-align: center;
            box-shadow: 0 8px 32px rgba(18,81,181,0.07);
        }
        .overview-band h2 {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 1.8rem;
            color: var(--blue-800);
            margin-bottom: 14px;
        }
        .overview-band p {
            color: var(--text-mid);
            font-size: 1rem;
            line-height: 1.75;
            max-width: 700px;
            margin: 0 auto 24px;
        }
        .badge-pill {
            display: inline-block;
            background: var(--blue-50);
            color: var(--blue-700);
            border: 1.5px solid var(--blue-100);
            border-radius: 40px;
            padding: 8px 20px;
            font-size: 0.87rem;
            font-weight: 600;
            margin: 5px;
            font-family: 'Sora', sans-serif;
        }

        /* ---- DEPARTMENTS SECTION ---- */
        .dept-section {
            max-width: 1200px;
            margin: 56px auto 0;
            padding: 0 20px;
        }
        .dept-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-top: 32px;
        }
        .dept-item {
            background: var(--white);
            border-radius: 16px;
            padding: 20px 16px;
            border: 1.5px solid var(--blue-100);
            text-align: center;
            font-family: 'Sora', sans-serif;
            font-size: 0.88rem;
            font-weight: 600;
            color: var(--blue-700);
            box-shadow: 0 2px 12px rgba(18,81,181,0.05);
            transition: all 0.22s;
        }
        .dept-item:hover {
            background: var(--blue-600);
            color: #fff;
            border-color: var(--blue-600);
            transform: translateY(-3px);
            box-shadow: 0 10px 28px rgba(18,81,181,0.22);
        }
        .dept-item .dept-icon { font-size: 1.8rem; display: block; margin-bottom: 8px; }

        /* ---- FOOTER ---- */
        footer {
            background: var(--blue-900);
            margin-top: 64px;
            padding: 36px 20px;
            text-align: center;
        }
        footer p { color: var(--blue-300); font-size: 0.88rem; margin-bottom: 4px; }
        footer .footer-line {
            width: 50px;
            height: 2px;
            background: var(--accent);
            margin: 12px auto;
            border-radius: 2px;
        }

        /* ---- RESPONSIVE ---- */
        @media (max-width: 768px) {
            .college-card { flex-direction: column; align-items: center; text-align: center; padding: 28px 20px; }
            .college-img-bg, .college-img { width: 190px; height: 190px; }
            .info-pill-row { justify-content: center; }
            .page-hero h2 { font-size: 1.8rem; }
            .section-title { font-size: 1.5rem; }
            .overview-band { padding: 32px 20px; }
        }
        @media (max-width: 480px) {
            .site-header h1 { font-size: 1.4rem; letter-spacing: 2px; }
            .site-nav .nav-btn { font-size: 0.75rem; padding: 6px 14px; }
        }
    </style>
</head>
<body>

<!-- ==================== HEADER ==================== -->
<div class="site-header">
    <h1>✦ INTERNSHIP PORTAL</h1>
    <p>Kongu Engineering College &nbsp;|&nbsp; Industry Ready Portal</p>
    
</div>

<!-- ==================== NAVBAR ==================== -->
<div class="site-nav">
    <nav>
        <a class="nav-btn" href="home1.php">🏠 HOME</a>
        <a class="nav-btn" href="consolidate.php">📊 CONSOLIDATE</a>
        
        <a class="nav-btn" href="about1.php">ℹ️ ABOUT US</a>
    </nav>
</div>

<!-- ==================== PAGE HERO BANNER ==================== -->
<div class="page-hero">
    <div class="page-hero-content">
        <h2>About <span>Kongu Engineering College</span></h2>
        <p>A premier institution shaping industry-ready engineers since 1983 — committed to excellence, innovation, and community development in the heart of Tamil Nadu.</p>
        <div class="hero-accent-line"></div>
    </div>
</div>

<!-- ==================== COLLEGE ABOUT SECTION ==================== -->
<div class="college-section">
    <div class="college-card">
        <div class="college-img-wrap">
            <div class="college-img-bg"></div>
            <img src="https://images.unsplash.com/photo-1562774053-701939374585?w=600&q=80" class="college-img" alt="Kongu Engineering College Campus">
        </div>
        <div class="college-body">
            <h3>Kongu <span>Engineering College</span></h3>
            <p>Kongu Engineering College is a recognised institution offering multi-disciplinary, research-oriented education. It provides interdisciplinary learning that integrates theoretical knowledge with practical application, fostering rigorous scholarship and community engagement.</p>
            <p>The institution is managed by the Kongu Vellalar Institute of Technology Trust, located in Erode District, Tamil Nadu. Since its establishment in 1983, the Trust has developed the college into a prominent institution for value-based technical education. The sprawling 167-acre campus features extensive greenery, modern laboratories, and state-of-the-art infrastructure.</p>
            <p>Affiliated with Anna University, Chennai, the college has provided over 40 years of service in technical education and is recognised as one of India's most reputable engineering institutions.</p>
            <div class="info-pill-row">
                <span class="info-pill">📅 Est. 1983</span>
                <span class="info-pill">🏫 167-Acre Campus</span>
                <span class="info-pill">🎓 Anna University Affiliated</span>
                <span class="info-pill">✅ AICTE Approved</span>
                <span class="info-pill">📍 Perundurai, Erode</span>
            </div>
        </div>
    </div>
</div>

<!-- ==================== STATS BAND ==================== -->
<div class="stats-band">
    <div class="stats-grid">
        <div class="stat-box">
            <div class="stat-number">40+</div>
            <div class="stat-label">Years of Academic Excellence</div>
        </div>
        <div class="stat-box">
            <div class="stat-number">167</div>
            <div class="stat-label">Acre Green Campus</div>
        </div>
        <div class="stat-box">
            <div class="stat-number">15+</div>
            <div class="stat-label">Engineering Departments</div>
        </div>
        <div class="stat-box">
            <div class="stat-number">10K+</div>
            <div class="stat-label">Students Enrolled</div>
        </div>
        <div class="stat-box">
            <div class="stat-number">500+</div>
            <div class="stat-label">Industry Partners</div>
        </div>
    </div>
</div>

<!-- ==================== VISION MISSION SECTION ==================== -->
<div class="vm-section">
    <h2 class="section-title">Our Vision & Mission</h2>
    <p class="section-sub">The values that guide everything we do at Kongu Engineering College.</p>
    <div class="row g-4">
        <div class="col-md-4">
            <div class="vm-card">
                <span class="vm-icon">🔭</span>
                <h4>Vision</h4>
                <p>To be a globally recognised institution that provides quality education, develops students with strong technical knowledge and professional skills, and produces leaders who drive industry and societal progress.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="vm-card">
                <span class="vm-icon">🎯</span>
                <h4>Mission</h4>
                <p>To create skilled engineers through continuous learning, practical exposure, and innovative thinking. The institution supports career development through internship programs, industry collaboration, and project-based learning.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="vm-card">
                <span class="vm-icon">🏆</span>
                <h4>Quality Education</h4>
                <p>The college maintains high academic standards and encourages students to participate in technical activities, workshops, hackathons, symposiums, and internships that prepare them for real-world challenges.</p>
            </div>
        </div>
    </div>
</div>

<!-- ==================== DEPARTMENTS SECTION ==================== -->
<div class="dept-section">
    <h2 class="section-title">Our Departments</h2>
    <p class="section-sub">Multidisciplinary programs that bridge technical expertise with industry demands.</p>
    <div class="dept-grid">
        <div class="dept-item"><span class="dept-icon">💻</span>Computer Science & Engg</div>
        <div class="dept-item"><span class="dept-icon">⚡</span>Electrical & Electronics</div>
        <div class="dept-item"><span class="dept-icon">🔧</span>Mechanical Engineering</div>
        <div class="dept-item"><span class="dept-icon">🏗️</span>Civil Engineering</div>
        <div class="dept-item"><span class="dept-icon">📡</span>Electronics & Comm</div>
        <div class="dept-item"><span class="dept-icon">🤖</span>Artificial Intelligence</div>
        <div class="dept-item"><span class="dept-icon">🧪</span>Chemical Engineering</div>
        <div class="dept-item"><span class="dept-icon">📊</span>Information Technology</div>
    </div>
</div>

<!-- ==================== INFO BAND ==================== -->
<div class="info-band">
    <h2>🏛️ Academic Excellence & Placement</h2>
    <p>Kongu Engineering College encourages innovation through research laboratories, industry-supported centres of excellence, and project-based learning. The dedicated placement cell provides training in aptitude, communication, and technical skills — and top companies visit the campus every year, helping students secure excellent career opportunities in leading organisations worldwide.</p>
</div>

<!-- ==================== PORTAL & BENEFITS GRID ==================== -->
<div class="grid-section">
    <div class="grid-card">
        <div class="grid-card-title">ℹ️ About the Portal</div>
        <ul>
            <li>Developed to manage internship records</li>
            <li>Reduces manual documentation effort</li>
            <li>Maintains data in organized format</li>
            <li>Simplifies report generation</li>
            <li>Accessible by students & faculty</li>
        </ul>
    </div>
    <div class="grid-card">
        <div class="grid-card-title">🎓 Student Benefits</div>
        <ul>
            <li>Track internship progress easily</li>
            <li>Store company & role details</li>
            <li>Access consolidated report anytime</li>
            <li>Improve documentation quality</li>
            <li>Better academic record management</li>
        </ul>
    </div>
    <div class="grid-card">
        <div class="grid-card-title">👨‍🏫 Faculty Benefits</div>
        <ul>
            <li>Monitor student internship activity</li>
            <li>Verify and approve records</li>
            <li>Easy department-level tracking</li>
            <li>Generate consolidated reports fast</li>
            <li>Improved data accuracy & management</li>
        </ul>
    </div>
</div>

<!-- ==================== PORTAL OVERVIEW BAND ==================== -->
<div class="overview-band" style="margin-left:auto; margin-right:auto; margin-bottom: 0;">
    <h2>📌 About the Internship Portal</h2>
    <p>The KEC Internship Portal is a structured digital system built to manage and track internship information for students and faculty. It significantly reduces manual paperwork, improves the accuracy of internship data, and ensures proper documentation for academic evaluation and industry reporting. Every student's internship journey — from company details to completion certificates — is managed efficiently in one place.</p>
    <div>
        <span class="badge-pill">📅 Real-time Tracking</span>
        <span class="badge-pill">📑 Consolidated Reports</span>
        <span class="badge-pill">🔐 Role-based Access</span>
        <span class="badge-pill">🏢 Industry Integration</span>
        <span class="badge-pill">📱 Mobile Friendly</span>
    </div>
</div>

<!-- ==================== FOOTER ==================== -->
<footer>
    <p>© 2025 Kongu Engineering College — Internship Management Portal</p>
    <p>📍 Perundurai, Erode, Tamil Nadu &nbsp;|&nbsp; 📧 internship@kongu.edu</p>
    <div class="footer-line"></div>
    <p>Empowering students with industry-ready internship tracking</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const btns = document.querySelectorAll('.nav-btn');
        btns.forEach(btn => {
            btn.addEventListener('mouseenter', () => btn.style.letterSpacing = '0.8px');
            btn.addEventListener('mouseleave', () => {
                if (!btn.classList.contains('active')) btn.style.letterSpacing = '0.5px';
            });
        });
    });
</script>
</body>
</html>