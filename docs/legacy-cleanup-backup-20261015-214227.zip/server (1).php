<?php
$hostname='localhost';
$username='root';
$password='';
$database='internship';
$con=mysqli_connect($hostname,$username,$password,$database);
if($con)
{
//echo 'successfull';
}
if($con->connect_error){
    die("Connection failed: " . $con->connect_error);
}
    
else
    {
     echo mysqli_error($con);
    }
    
?>