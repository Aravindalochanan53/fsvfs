<?php

session_start();

$host = "localhost";
$user = "root";
$password = "";
$database = "internship";

$conn = mysqli_connect($host, $user, $password, $database);

$roll_number = $_POST['roll_number'];
$entered_password = $_POST['password'];

$sql = "SELECT * FROM student_signup WHERE roll_number='$roll_number'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

    $row = mysqli_fetch_assoc($result);

    $db_password = $row['password'];

    if (password_verify($entered_password, $db_password)) {

        // STUDENT DATA
        $student_id   = $row['id'];
        $student_name = $row['student_name'];

        // SET SESSION
        $_SESSION['student_id']   = $row['id'];
        $_SESSION['student_name'] = $row['student_name'];
        $_SESSION['register_no']  = $row['roll_number'];

        // TODAY DATE
        $today = date("Y-m-d");

        // CHECK ALREADY EXISTS
        $check = "SELECT * FROM attendance 
                  WHERE student_id='$student_id' 
                  AND attendance_date='$today'";

        $check_result = mysqli_query($conn, $check);

        if (mysqli_num_rows($check_result) == 0) {

            // INSERT ATTENDANCE
            $insert = "INSERT INTO attendance
            (student_id, student_name, attendance_date, status)
            VALUES
            ('$student_id', '$student_name', '$today', 'Present')";

            mysqli_query($conn, $insert);
        }

        echo "
        <script>
            window.location.href='home1.php';
        </script>
        ";

    } else {

        echo "
        <script>
            alert('Wrong Password');
            window.history.back();
        </script>
        ";

    }

} else {

    echo "
    <script>
        alert('Register Number Not Found');
        window.history.back();
    </script>
    ";

}

mysqli_close($conn);

?>