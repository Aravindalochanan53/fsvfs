<?php

session_start();

$host     = "localhost";
$user     = "root";
$password = "";
$database = "internship";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}

$roll_number      = $_POST['roll_number'];
$entered_password = $_POST['password'];

// Use prepared statement to avoid SQL injection
$stmt = $conn->prepare("SELECT * FROM faculty_signup WHERE roll_number = ?");
$stmt->bind_param("s", $roll_number);
$stmt->execute();
$result = $stmt->get_result();

if (mysqli_num_rows($result) > 0) {

    $row         = $result->fetch_assoc();
    $db_password = $row['password'];

    if (password_verify($entered_password, $db_password)) {

        // SET SESSION
        $_SESSION['faculty_id']   = $row['id'];
        $_SESSION['faculty_name'] = $row['student_name'];  // column name in DB
        $_SESSION['kongu_id']     = $row['roll_number'];
        $_SESSION['department']   = $row['department'];

        echo "
        <script>
            window.location.href='home2.php';
        </script>
        ";

    } else {

        echo "
        <script>
            alert('Wrong Password');
            window.history.back();
        </script>
        ";

    }

} else {

    echo "
    <script>
        alert('Kongu ID Not Found');
        window.history.back();
    </script>
    ";

}

$stmt->close();
mysqli_close($conn);

?>
