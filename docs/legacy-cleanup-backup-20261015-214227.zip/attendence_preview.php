<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AttendIQ — College Attendance Management System Preview</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<style>
:root {
  --g900:#052e16;--g800:#14532d;--g700:#15803d;--g600:#16a34a;
  --g500:#22c55e;--g400:#4ade80;--g300:#86efac;--g200:#bbf7d0;
  --g100:#dcfce7;--g50:#f0fdf4;
  --dark:#0a1628;--surface:#0f2213;--card:#122918;
  --border:rgba(34,197,94,0.18);
  --text-primary:#f0fdf4;--text-secondary:#86efac;--text-muted:#4ade80;
  --shadow-green:0 0 40px rgba(34,197,94,0.12);
  --radius:16px;
  --danger:#ef4444;
}
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--dark);color:var(--text-primary);min-height:100vh;
  background-image:radial-gradient(ellipse 80% 50% at 50% -20%,rgba(21,128,61,0.25) 0%,transparent 60%),
    radial-gradient(ellipse 40% 30% at 80% 80%,rgba(34,197,94,0.08) 0%,transparent 50%);}

/* NAV */
.nav{background:rgba(9,18,13,0.85);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);
  padding:0 2rem;height:68px;display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:100;}
.brand{display:flex;align-items:center;gap:12px;font-weight:800;font-size:1.25rem;color:var(--text-primary);text-decoration:none;}
.brand-icon{width:40px;height:40px;background:linear-gradient(135deg,var(--g600),var(--g400));border-radius:10px;
  display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 4px 20px rgba(34,197,94,0.35);}
.brand span{color:var(--g400);}
.nav-tabs-custom{display:flex;gap:4px;}
.ntab{padding:8px 20px;border-radius:10px;border:1px solid transparent;font-weight:600;font-size:.875rem;
  cursor:pointer;transition:.2s;color:var(--text-muted);background:none;}
.ntab:hover{background:rgba(34,197,94,0.08);color:var(--g400);}
.ntab.active{background:rgba(34,197,94,0.15);border-color:rgba(34,197,94,0.25);color:var(--g300);}
.nav-status{display:flex;align-items:center;gap:6px;font-size:.8rem;color:var(--text-muted);}

/* WRAP */
.wrap{max-width:1100px;margin:0 auto;padding:40px 16px 80px;}

/* PAGE */
.page{display:none;} .page.active{display:block;}

/* HERO */
.hero{padding:0 0 40px;text-align:center;}
.hero-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.25);
  color:var(--g400);padding:6px 16px;border-radius:100px;font-size:.8rem;font-weight:600;letter-spacing:.08em;text-transform:uppercase;margin-bottom:20px;}
.hero h1{font-size:clamp(1.8rem,4vw,3rem);font-weight:800;line-height:1.1;
  background:linear-gradient(135deg,#f0fdf4 0%,var(--g300) 50%,var(--g500) 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:12px;}
.hero p{color:var(--text-secondary);font-size:1.05rem;max-width:520px;margin:0 auto 36px;}

.stats-strip{display:flex;justify-content:center;gap:48px;flex-wrap:wrap;margin-bottom:48px;}
.stat-item{text-align:center;}
.stat-num{font-size:1.8rem;font-weight:800;background:linear-gradient(135deg,var(--g400),var(--g500));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.stat-lbl{font-size:.72rem;color:var(--text-muted);font-weight:600;letter-spacing:.06em;text-transform:uppercase;}

/* SEARCH CARD */
.search-card{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:24px;margin-bottom:24px;}
.search-row{display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;}
.search-wrap{position:relative;flex:1;min-width:200px;}
.search-wrap i{position:absolute;left:16px;top:50%;transform:translateY(-50%);color:var(--g500);pointer-events:none;}
.si{width:100%;padding:13px 16px 13px 46px;background:rgba(34,197,94,0.06);border:1.5px solid var(--border);
  border-radius:12px;color:var(--text-primary);font-size:.9rem;font-family:inherit;outline:none;}
.si:focus{border-color:var(--g500);}
.si::placeholder{color:rgba(134,239,172,.35);}
.fsel{padding:13px 16px;background:rgba(34,197,94,0.06);border:1.5px solid var(--border);
  border-radius:12px;color:var(--text-primary);font-family:inherit;font-size:.85rem;outline:none;cursor:pointer;min-width:140px;}
.fsel option{background:#122918;color:var(--text-primary);}
.btn-s{background:linear-gradient(135deg,var(--g700),var(--g500));border:none;color:#fff;
  padding:13px 24px;border-radius:12px;font-weight:700;font-size:.9rem;cursor:pointer;white-space:nowrap;transition:.2s;}
.btn-s:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(34,197,94,.35);}

/* RESULT META */
.rmeta{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;padding:0 2px;}
.rcnt{font-size:.85rem;color:var(--text-muted);}
.rcnt strong{color:var(--g400);}

/* GRID */
.sgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;}
.sc{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:20px;
  cursor:pointer;transition:.2s;position:relative;overflow:hidden;}
.sc::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;
  background:linear-gradient(90deg,var(--g700),var(--g400));transform:scaleX(0);transform-origin:left;transition:.3s;}
.sc:hover{transform:translateY(-4px);border-color:rgba(34,197,94,0.4);box-shadow:0 12px 40px rgba(34,197,94,0.15);}
.sc:hover::before{transform:scaleX(1);}
.sc-inner{display:flex;align-items:center;gap:16px;}
.sav{width:54px;height:54px;border-radius:14px;border:2px solid rgba(34,197,94,0.25);
  background:linear-gradient(135deg,var(--g800),var(--g600));display:flex;align-items:center;
  justify-content:center;font-size:1.3rem;font-weight:800;color:#fff;flex-shrink:0;}
.sinfo{flex:1;min-width:0;}
.sname{font-weight:700;font-size:.95rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:3px;}
.sreg{font-family:'JetBrains Mono',monospace;font-size:.75rem;color:var(--g400);margin-bottom:6px;}
.stags{display:flex;gap:5px;flex-wrap:wrap;}
.stag{font-size:.68rem;padding:2px 9px;border-radius:100px;font-weight:600;
  background:rgba(34,197,94,0.1);color:var(--g300);border:1px solid rgba(34,197,94,0.18);}
.apill{display:inline-flex;align-items:center;gap:5px;padding:4px 11px;border-radius:100px;font-size:.75rem;font-weight:700;margin-top:8px;}
.pe{background:rgba(34,197,94,0.15);color:var(--g400);border:1px solid rgba(34,197,94,0.3);}
.pw{background:rgba(239,68,68,0.12);color:#fca5a5;border:1px solid rgba(239,68,68,0.25);}
.brpt{width:100%;margin-top:12px;background:linear-gradient(135deg,var(--g800),var(--g600));
  border:1px solid rgba(34,197,94,0.25);color:var(--g200);padding:9px;border-radius:10px;
  font-weight:600;font-size:.85rem;text-align:center;cursor:pointer;transition:.2s;border-style:solid;}
.brpt:hover{background:linear-gradient(135deg,var(--g700),var(--g500));color:#fff;}

/* ── REPORT PAGE ── */
.ph{background:var(--card);border:1px solid var(--border);border-radius:24px;padding:32px;margin-bottom:24px;
  box-shadow:var(--shadow-green);position:relative;overflow:hidden;}
.ph::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;
  background:linear-gradient(90deg,var(--g800),var(--g500),var(--g400));}
.ph-grid{display:flex;gap:28px;align-items:flex-start;flex-wrap:wrap;}
.pav-w{position:relative;flex-shrink:0;}
.pav{width:90px;height:90px;border-radius:18px;border:3px solid rgba(34,197,94,0.35);
  background:linear-gradient(135deg,var(--g800),var(--g600));display:flex;align-items:center;
  justify-content:center;font-size:2rem;font-weight:800;color:#fff;}
.dot{position:absolute;bottom:4px;right:4px;width:14px;height:14px;background:var(--g500);border-radius:50%;border:2px solid var(--card);}
.pname{font-size:1.6rem;font-weight:800;margin-bottom:4px;}
.preg{font-family:'JetBrains Mono',monospace;color:var(--g400);font-size:.85rem;margin-bottom:10px;}
.ptags{display:flex;gap:7px;flex-wrap:wrap;}
.ptag{background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.2);color:var(--g300);padding:4px 12px;border-radius:100px;font-size:.72rem;font-weight:600;}
.pr-right{margin-left:auto;text-align:right;}
.bigpct{font-size:3.2rem;font-weight:800;line-height:1;background:linear-gradient(135deg,var(--g400),var(--g500));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.bigpct-w{background:linear-gradient(135deg,#ef4444,#fca5a5)!important;}
.plbl{font-size:.72rem;color:var(--text-muted);font-weight:600;letter-spacing:.06em;text-transform:uppercase;margin-top:4px;}
.ebadge{display:inline-flex;align-items:center;gap:6px;padding:5px 14px;border-radius:100px;font-size:.78rem;font-weight:700;margin-top:8px;}
.ey{background:rgba(34,197,94,0.15);color:var(--g400);border:1px solid rgba(34,197,94,0.3);}
.en{background:rgba(239,68,68,0.15);color:#fca5a5;border:1px solid rgba(239,68,68,0.3);}

.abar{display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap;}
.btn-a{display:flex;align-items:center;gap:8px;padding:10px 22px;border-radius:12px;font-weight:600;font-size:.875rem;cursor:pointer;transition:.2s;border:none;}
.btn-pr{background:rgba(34,197,94,0.12);color:var(--g400);border:1px solid rgba(34,197,94,0.25)!important;border-style:solid!important;}
.btn-pr:hover{background:rgba(34,197,94,0.2);}
.btn-pd{background:linear-gradient(135deg,var(--g700),var(--g500));color:#fff;}
.btn-pd:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(34,197,94,.35);}

.sboxes{display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:14px;margin-bottom:24px;}
.sbox{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:20px;text-align:center;}
.sbox-ico{font-size:1.3rem;margin-bottom:8px;}
.sbox-n{font-size:1.7rem;font-weight:800;line-height:1;}
.sbox-l{font-size:.7rem;color:var(--text-muted);font-weight:600;letter-spacing:.06em;text-transform:uppercase;margin-top:4px;}
.bg{border-top:3px solid var(--g500);} .bg .sbox-n{color:var(--g400);}
.br2{border-top:3px solid var(--danger);} .br2 .sbox-n{color:#fca5a5;}
.bb{border-top:3px solid #60a5fa;} .bb .sbox-n{color:#93c5fd;}
.ba{border-top:3px solid #f59e0b;} .ba .sbox-n{color:#fcd34d;}

.secc{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);margin-bottom:24px;overflow:hidden;}
.sech{padding:18px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.sect{font-weight:700;font-size:.95rem;display:flex;align-items:center;gap:10px;}
.sect i{color:var(--g500);}
.secb{padding:24px;}

.stbl{width:100%;border-collapse:collapse;}
.stbl th{font-size:.72rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--text-muted);padding:10px 12px;border-bottom:1px solid var(--border);text-align:left;}
.stbl td{padding:13px 12px;border-bottom:1px solid rgba(34,197,94,0.07);font-size:.875rem;}
.stbl tr:last-child td{border-bottom:none;}
.stbl tr:hover td{background:rgba(34,197,94,0.04);}
.cc{font-family:'JetBrains Mono',monospace;font-size:.78rem;color:var(--g400);}
.pw2{min-width:120px;}
.pb{height:6px;border-radius:100px;background:rgba(34,197,94,0.1);}
.pbf{height:100%;border-radius:100px;transition:width 1s ease;}
.pfg{background:linear-gradient(90deg,var(--g600),var(--g400));}
.pfr{background:linear-gradient(90deg,#dc2626,#f87171);}
.ppct{font-size:.75rem;font-weight:700;margin-top:3px;}
.bel{padding:3px 10px;border-radius:100px;font-size:.7rem;font-weight:700;}
.bey{background:rgba(34,197,94,0.15);color:var(--g400);}
.ben{background:rgba(239,68,68,0.15);color:#fca5a5;}

.mgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px;}
.mc{background:rgba(34,197,94,0.05);border:1px solid var(--border);border-radius:12px;padding:16px;text-align:center;}
.ml{font-size:.78rem;font-weight:600;color:var(--text-muted);margin-bottom:8px;}
.mp{font-size:1.4rem;font-weight:800;}
.mm{font-size:.72rem;color:var(--text-secondary);margin-top:4px;}

.rtbl{width:100%;border-collapse:collapse;font-size:.85rem;}
.rtbl th{font-size:.7rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:var(--text-muted);padding:9px 12px;border-bottom:1px solid var(--border);}
.rtbl td{padding:9px 12px;border-bottom:1px solid rgba(34,197,94,0.06);}
.chip{padding:3px 11px;border-radius:100px;font-size:.7rem;font-weight:700;}
.cp{background:rgba(34,197,94,0.15);color:var(--g400);}
.ca{background:rgba(239,68,68,0.12);color:#fca5a5;}

.row2{display:grid;grid-template-columns:1fr 2fr;gap:20px;margin-bottom:24px;}
@media(max-width:700px){.row2{grid-template-columns:1fr;}}

canvas{max-height:280px!important;}
</style>
</head>
<body>

<!-- Nav -->
<nav class="nav">
  <div class="brand">
    <div class="brand-icon"><i class="fa-solid fa-graduation-cap"></i></div>
    Attend<span>IQ</span>
  </div>
  <div class="nav-tabs-custom">
    <button class="ntab active" onclick="showPage('p1',this)"><i class="fa-solid fa-users me-2"></i>Student Selection</button>
    <button class="ntab" onclick="showPage('p2',this)"><i class="fa-solid fa-chart-bar me-2"></i>Student Report</button>
  </div>
  <div class="nav-status">
    <i class="fa-solid fa-circle" style="color:var(--g500);font-size:.45rem;"></i>
    Preview Mode
  </div>
</nav>

<div class="wrap">

<!-- ══════════ PAGE 1: STUDENT SELECTION ══════════ -->
<div class="page active" id="p1">
  <div class="hero">
    <div class="hero-badge"><i class="fa-solid fa-chart-line"></i> Attendance Tracking System</div>
    <h1>Student Attendance<br>Management Portal</h1>
    <p>Search, filter and view detailed attendance reports for every enrolled student.</p>
    <div class="stats-strip">
      <div class="stat-item"><div class="stat-num">15</div><div class="stat-lbl">Students</div></div>
      <div class="stat-item"><div class="stat-num">4</div><div class="stat-lbl">Departments</div></div>
      <div class="stat-item"><div class="stat-num">4</div><div class="stat-lbl">Courses</div></div>
      <div class="stat-item"><div class="stat-num">75%</div><div class="stat-lbl">Min. Required</div></div>
    </div>
  </div>

  <div class="search-card">
    <div class="search-row">
      <div class="search-wrap">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input class="si" id="sq" type="text" placeholder="Search by name or register number…" oninput="filterStudents()">
      </div>
      <select class="fsel" id="sdept" onchange="filterStudents()">
        <option value="">All Departments</option>
        <option>Computer Science</option>
        <option>Electronics</option>
        <option>Mechanical</option>
        <option>Civil</option>
      </select>
      <select class="fsel" id="scourse" onchange="filterStudents()">
        <option value="">All Courses</option>
        <option>B.E. CSE</option>
        <option>B.E. ECE</option>
        <option>B.E. Mechanical</option>
        <option>B.E. Civil</option>
        <option>MCA</option>
      </select>
      <select class="fsel" id="syear" onchange="filterStudents()">
        <option value="">Year</option>
        <option value="1">Year 1</option>
        <option value="2">Year 2</option>
        <option value="3">Year 3</option>
        <option value="4">Year 4</option>
      </select>
      <button class="btn-s"><i class="fa-solid fa-magnifying-glass me-2"></i>Search</button>
    </div>
  </div>

  <div class="rmeta">
    <div class="rcnt" id="rcnt">Showing <strong>15</strong> students</div>
    <div style="font-size:.78rem;color:var(--text-muted);"><i class="fa-solid fa-circle-info me-1"></i>Click any card to view full report</div>
  </div>

  <div class="sgrid" id="sgrid"></div>
</div>

<!-- ══════════ PAGE 2: STUDENT REPORT ══════════ -->
<div class="page" id="p2">

  <!-- Profile Header -->
  <div class="ph" style="margin-bottom:24px;">
    <div class="ph-grid">
      <div class="pav-w">
        <div class="pav">AK</div>
        <div class="dot"></div>
      </div>
      <div style="flex:1;min-width:180px;">
        <div class="pname">Aarav Krishnan</div>
        <div class="preg">CSE2021001</div>
        <div class="ptags">
          <span class="ptag">Computer Science</span>
          <span class="ptag">B.E. CSE</span>
          <span class="ptag">Year 3</span>
          <span class="ptag">Semester 5</span>
        </div>
        <div style="margin-top:12px;font-size:.82rem;color:var(--text-secondary);">
          <i class="fa-solid fa-envelope me-2"></i>aarav@student.edu
          &nbsp;&nbsp;
          <i class="fa-solid fa-phone me-2"></i>9876543210
        </div>
      </div>
      <div class="pr-right">
        <div class="bigpct" id="bigPctDisplay">85.0%</div>
        <div class="plbl">Overall Attendance</div>
        <div class="ebadge ey"><i class="fa-solid fa-circle-check"></i> Eligible for Exams</div>
      </div>
    </div>
  </div>

  <!-- Action Bar -->
  <div class="abar">
    <button class="btn-a btn-pr"><i class="fa-solid fa-print"></i> Print Report</button>
    <button class="btn-a btn-pd"><i class="fa-solid fa-file-pdf"></i> Download PDF</button>
  </div>

  <!-- Stat Boxes -->
  <div class="sboxes">
    <div class="sbox bg"><div class="sbox-ico" style="color:var(--g500)"><i class="fa-solid fa-circle-check"></i></div><div class="sbox-n">86</div><div class="sbox-l">Total Present</div></div>
    <div class="sbox br2"><div class="sbox-ico" style="color:#f87171"><i class="fa-solid fa-circle-xmark"></i></div><div class="sbox-n">14</div><div class="sbox-l">Total Absent</div></div>
    <div class="sbox bb"><div class="sbox-ico" style="color:#93c5fd"><i class="fa-solid fa-calendar-days"></i></div><div class="sbox-n">100</div><div class="sbox-l">Total Classes</div></div>
    <div class="sbox ba"><div class="sbox-ico" style="color:#fcd34d"><i class="fa-solid fa-book-open"></i></div><div class="sbox-n">5</div><div class="sbox-l">Subjects</div></div>
  </div>

  <!-- Charts Row -->
  <div class="row2">
    <div class="secc">
      <div class="sech"><div class="sect"><i class="fa-solid fa-chart-pie"></i>Overview</div></div>
      <div class="secb"><canvas id="donutChart"></canvas></div>
    </div>
    <div class="secc">
      <div class="sech"><div class="sect"><i class="fa-solid fa-chart-bar"></i>Subject-wise Attendance</div></div>
      <div class="secb"><canvas id="barChart"></canvas></div>
    </div>
  </div>

  <!-- Subject Table -->
  <div class="secc">
    <div class="sech">
      <div class="sect"><i class="fa-solid fa-table"></i>Subject-wise Breakdown</div>
      <span style="font-size:.78rem;color:var(--text-muted);">5 subjects</span>
    </div>
    <div class="secb" style="padding:0;overflow-x:auto;">
      <table class="stbl">
        <thead><tr><th>#</th><th>Code</th><th>Subject</th><th>Present</th><th>Absent</th><th>Total</th><th>Progress</th><th>Status</th></tr></thead>
        <tbody id="stbody"></tbody>
      </table>
    </div>
  </div>

  <!-- Monthly Line -->
  <div class="secc">
    <div class="sech"><div class="sect"><i class="fa-solid fa-calendar-days"></i>Monthly Attendance Trend</div></div>
    <div class="secb"><canvas id="lineChart" style="max-height:240px;"></canvas></div>
  </div>

  <!-- Monthly Cards -->
  <div class="secc">
    <div class="sech"><div class="sect"><i class="fa-solid fa-grid-2"></i>Monthly Summary</div></div>
    <div class="secb"><div class="mgrid" id="mgrid"></div></div>
  </div>

  <!-- Recent Log -->
  <div class="secc">
    <div class="sech"><div class="sect"><i class="fa-solid fa-clock-rotate-left"></i>Recent Attendance Log</div><span style="font-size:.78rem;color:var(--text-muted);">Latest records</span></div>
    <div class="secb" style="padding:0;max-height:350px;overflow-y:auto;">
      <table class="rtbl">
        <thead style="position:sticky;top:0;background:var(--card);">
          <tr><th>Date</th><th>Subject</th><th>Code</th><th>Status</th></tr>
        </thead>
        <tbody id="rtbody"></tbody>
      </table>
    </div>
  </div>

  <div style="text-align:center;margin-top:28px;color:var(--text-muted);font-size:.78rem;">
    <i class="fa-solid fa-circle-info me-1"></i>Attendance below 75% may lead to detention. Contact your faculty advisor for assistance.
  </div>

</div><!-- /p2 -->
</div><!-- /wrap -->

<script>
Chart.defaults.color = '#86efac';
Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";

/* ── SAMPLE DATA ── */
const STUDENTS = [
  {id:1,reg:'CSE2021001',name:'Aarav Krishnan',dept:'Computer Science',course:'B.E. CSE',year:3,sem:5,pct:85.0},
  {id:2,reg:'CSE2021002',name:'Meera Sundar',dept:'Computer Science',course:'B.E. CSE',year:3,sem:5,pct:58.0},
  {id:3,reg:'CSE2021003',name:'Rohan Patel',dept:'Computer Science',course:'B.E. CSE',year:3,sem:5,pct:91.0},
  {id:4,reg:'CSE2021004',name:'Ananya Iyer',dept:'Computer Science',course:'B.E. CSE',year:3,sem:5,pct:78.5},
  {id:5,reg:'CSE2021005',name:'Vikram Rajesh',dept:'Computer Science',course:'B.E. CSE',year:3,sem:5,pct:82.0},
  {id:6,reg:'ECE2022001',name:'Divya Menon',dept:'Electronics',course:'B.E. ECE',year:2,sem:3,pct:88.7},
  {id:7,reg:'ECE2022002',name:'Karthik Balaji',dept:'Electronics',course:'B.E. ECE',year:2,sem:3,pct:72.3},
  {id:8,reg:'ECE2022003',name:'Lakshmi Priya',dept:'Electronics',course:'B.E. ECE',year:2,sem:3,pct:93.3},
  {id:9,reg:'MECH2020001',name:'Suresh Natarajan',dept:'Mechanical',course:'B.E. Mechanical',year:4,sem:7,pct:86.7},
  {id:10,reg:'MECH2020002',name:'Preethi Vasu',dept:'Mechanical',course:'B.E. Mechanical',year:4,sem:7,pct:64.4},
  {id:11,reg:'CIVIL2023001',name:'Naveen Chandran',dept:'Civil',course:'B.E. Civil',year:1,sem:1,pct:0},
  {id:12,reg:'CIVIL2023002',name:'Sowmya Rajan',dept:'Civil',course:'B.E. Civil',year:1,sem:1,pct:0},
  {id:13,reg:'MCA2022001',name:'Deepak Venkat',dept:'Computer Science',course:'MCA',year:2,sem:3,pct:79.5},
  {id:14,reg:'MCA2022002',name:'Nithya Subramaniam',dept:'Computer Science',course:'MCA',year:2,sem:3,pct:85.0},
  {id:15,reg:'CSE2021006',name:'Arun Murugan',dept:'Computer Science',course:'B.E. CSE',year:3,sem:5,pct:67.0},
];

function initials(n){return n.split(' ').slice(0,2).map(w=>w[0]).join('').toUpperCase();}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

function filterStudents(){
  const q=document.getElementById('sq').value.toLowerCase();
  const d=document.getElementById('sdept').value;
  const c=document.getElementById('scourse').value;
  const y=document.getElementById('syear').value;
  const filtered=STUDENTS.filter(s=>{
    if(q&&!s.name.toLowerCase().includes(q)&&!s.reg.toLowerCase().includes(q))return false;
    if(d&&s.dept!==d)return false;
    if(c&&s.course!==c)return false;
    if(y&&String(s.year)!==y)return false;
    return true;
  });
  renderGrid(filtered);
}

function renderGrid(list){
  document.getElementById('rcnt').innerHTML=`Showing <strong>${list.length}</strong> student${list.length!==1?'s':''}`;
  document.getElementById('sgrid').innerHTML=list.map(s=>{
    const elig=s.pct>=75;
    const pill=s.pct>0?(elig?`<div class="apill pe"><i class="fa-solid fa-circle-check"></i>${s.pct}% — Eligible</div>`:`<div class="apill pw"><i class="fa-solid fa-triangle-exclamation"></i>${s.pct}% — Warning</div>`):'<div class="apill" style="background:rgba(100,116,139,0.15);color:#94a3b8;border:1px solid rgba(100,116,139,0.25)"><i class="fa-solid fa-minus"></i>No data yet</div>';
    return `<div class="sc" onclick="viewReport(${s.id})">
      <div class="sc-inner">
        <div class="sav">${initials(s.name)}</div>
        <div class="sinfo">
          <div class="sname">${esc(s.name)}</div>
          <div class="sreg">${esc(s.reg)}</div>
          <div class="stags">
            <span class="stag">${esc(s.dept)}</span>
            <span class="stag">${esc(s.course)}</span>
            <span class="stag">Year ${s.year}</span>
          </div>
          ${pill}
        </div>
      </div>
      <button class="brpt"><i class="fa-solid fa-chart-bar" style="margin-right:6px;"></i>View Attendance Report</button>
    </div>`;
  }).join('');
}

function viewReport(id){
  const s=STUDENTS.find(x=>x.id===id);
  if(!s)return;
  showPage('p2',document.querySelectorAll('.ntab')[1]);
  // Update profile with selected student
  document.querySelector('.pav').textContent=initials(s.name);
  document.querySelector('.pname').textContent=s.name;
  document.querySelector('.preg').textContent=s.reg;
  const elig=s.pct>=75;
  const bpe=document.getElementById('bigPctDisplay');
  bpe.textContent=s.pct+'%';
  bpe.className=elig?'bigpct':'bigpct bigpct-w';
  document.querySelector('.ebadge').className=elig?'ebadge ey':'ebadge en';
  document.querySelector('.ebadge').innerHTML=elig?'<i class="fa-solid fa-circle-check"></i> Eligible for Exams':'<i class="fa-solid fa-triangle-exclamation"></i> Attendance Warning';
  rebuildCharts(s);
  window.scrollTo({top:0,behavior:'smooth'});
}

/* ── CHART DATA ── */
const SUBJECTS=['OS','DBMS','CN','SE','Web Tech'];
const SUBJ_DATA=[
  {code:'CS501',name:'Operating Systems',p:17,a:3,t:20,pct:85},
  {code:'CS502',name:'Database Management',p:18,a:2,t:20,pct:90},
  {code:'CS503',name:'Computer Networks',p:15,a:5,t:20,pct:75},
  {code:'CS504',name:'Software Engineering',p:16,a:4,t:20,pct:80},
  {code:'CS505',name:'Web Technologies',p:18,a:2,t:20,pct:90},
];
const MONTHLY=[
  {label:'Jul 2024',p:42,t:50,pct:84},
  {label:'Aug 2024',p:44,t:50,pct:88},
];

let charts={};

function buildCharts(){
  buildDonut(86,14);
  buildBar(SUBJ_DATA);
  buildLine(MONTHLY);
  buildSubjectTable(SUBJ_DATA);
  buildMonthlyCards(MONTHLY);
  buildRecentLog();
}

function rebuildCharts(s){
  // Destroy & rebuild with slight variations per student
  Object.values(charts).forEach(c=>{try{c.destroy();}catch(e){}});
  const seed=s.id;
  const presentTotal=Math.round(s.pct);
  buildDonut(presentTotal,100-presentTotal);
  // Generate subject data based on overall pct
  const subj=SUBJ_DATA.map((sub,i)=>{
    const variation=(i%2===0?5:-5);
    const p=Math.min(100,Math.max(50,Math.round(s.pct+variation)));
    const t=20; const a=t-Math.round(p/100*t);
    return {...sub,p:Math.round(p/100*t),a:t-Math.round(p/100*t),t,pct:p};
  });
  buildBar(subj);
  buildLine(MONTHLY);
  buildSubjectTable(subj);
  buildMonthlyCards(MONTHLY);
}

function buildDonut(p,a){
  const ctx=document.getElementById('donutChart').getContext('2d');
  charts.donut=new Chart(ctx,{type:'doughnut',data:{labels:['Present','Absent'],datasets:[{data:[p,a],backgroundColor:['rgba(34,197,94,0.8)','rgba(239,68,68,0.7)'],borderColor:['#22c55e','#ef4444'],borderWidth:2,hoverOffset:6}]},options:{responsive:true,cutout:'68%',plugins:{legend:{position:'bottom',labels:{padding:18,font:{size:12,weight:'600'}}},tooltip:{callbacks:{label:c=>` ${c.label}: ${c.raw}%`}}}}});
}
function buildBar(subj){
  const ctx=document.getElementById('barChart').getContext('2d');
  charts.bar=new Chart(ctx,{type:'bar',data:{labels:subj.map(s=>s.code),datasets:[{label:'Present',data:subj.map(s=>s.p),backgroundColor:'rgba(34,197,94,0.75)',borderColor:'#22c55e',borderWidth:1.5,borderRadius:6},{label:'Absent',data:subj.map(s=>s.a),backgroundColor:'rgba(239,68,68,0.6)',borderColor:'#ef4444',borderWidth:1.5,borderRadius:6}]},options:{responsive:true,plugins:{legend:{position:'top',labels:{font:{size:11,weight:'600'},padding:14}}},scales:{x:{grid:{color:'rgba(34,197,94,0.07)'}},y:{beginAtZero:true,grid:{color:'rgba(34,197,94,0.07)'}}}}});
}
function buildLine(monthly){
  const ctx=document.getElementById('lineChart').getContext('2d');
  charts.line=new Chart(ctx,{type:'line',data:{labels:monthly.map(m=>m.label),datasets:[{label:'Attendance %',data:monthly.map(m=>m.pct),borderColor:'#22c55e',backgroundColor:'rgba(34,197,94,0.08)',borderWidth:2.5,pointBackgroundColor:'#22c55e',pointRadius:6,tension:.4,fill:true},{label:'75% Threshold',data:monthly.map(()=>75),borderColor:'rgba(239,68,68,0.5)',borderDash:[8,4],borderWidth:1.5,pointRadius:0,fill:false}]},options:{responsive:true,plugins:{legend:{position:'top',labels:{font:{size:11,weight:'600'},padding:14}}},scales:{x:{grid:{color:'rgba(34,197,94,0.07)'}},y:{min:0,max:100,grid:{color:'rgba(34,197,94,0.07)'},ticks:{callback:v=>v+'%'}}}}});
}
function buildSubjectTable(subj){
  document.getElementById('stbody').innerHTML=subj.map((s,i)=>{
    const elig=s.pct>=75;
    return `<tr>
      <td style="color:var(--text-muted);">${i+1}</td>
      <td class="cc">${s.code}</td>
      <td style="font-weight:600;">${s.name}</td>
      <td style="color:var(--g400);font-weight:700;">${s.p}</td>
      <td style="color:#fca5a5;font-weight:700;">${s.a}</td>
      <td style="color:var(--text-muted);">${s.t}</td>
      <td class="pw2">
        <div class="pb"><div class="pbf ${elig?'pfg':'pfr'}" style="width:${s.pct}%"></div></div>
        <div class="ppct" style="color:${elig?'var(--g400)':'#fca5a5'}">${s.pct}%</div>
      </td>
      <td><span class="bel ${elig?'bey':'ben'}">${elig?'Eligible':'Warning'}</span></td>
    </tr>`;
  }).join('');
}
function buildMonthlyCards(monthly){
  document.getElementById('mgrid').innerHTML=monthly.map(m=>{
    const elig=m.pct>=75;
    const col=elig?'var(--g400)':'#fca5a5';
    return `<div class="mc"><div class="ml">${m.label}</div><div class="mp" style="color:${col}">${m.pct}%</div><div class="mm">${m.p}P / ${m.t-m.p}A</div></div>`;
  }).join('');
}
function buildRecentLog(){
  const log=[
    {date:'14 Aug 2024',sub:'Web Technologies',code:'CS505',st:'Present'},
    {date:'14 Aug 2024',sub:'Software Engineering',code:'CS504',st:'Present'},
    {date:'13 Aug 2024',sub:'Database Management',code:'CS502',st:'Present'},
    {date:'12 Aug 2024',sub:'Operating Systems',code:'CS501',st:'Absent'},
    {date:'12 Aug 2024',sub:'Computer Networks',code:'CS503',st:'Present'},
    {date:'10 Aug 2024',sub:'Web Technologies',code:'CS505',st:'Present'},
    {date:'09 Aug 2024',sub:'Software Engineering',code:'CS504',st:'Absent'},
    {date:'08 Aug 2024',sub:'Database Management',code:'CS502',st:'Present'},
    {date:'07 Aug 2024',sub:'Operating Systems',code:'CS501',st:'Present'},
    {date:'06 Aug 2024',sub:'Computer Networks',code:'CS503',st:'Present'},
  ];
  document.getElementById('rtbody').innerHTML=log.map(l=>`
    <tr>
      <td style="font-family:'JetBrains Mono',monospace;font-size:.78rem;color:var(--text-secondary);">${l.date}</td>
      <td>${l.sub}</td>
      <td class="cc">${l.code}</td>
      <td><span class="chip ${l.st==='Present'?'cp':'ca'}">${l.st}</span></td>
    </tr>`).join('');
}

function showPage(id,btn){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.ntab').forEach(b=>b.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  btn.classList.add('active');
}

/* INIT */
renderGrid(STUDENTS);
buildCharts();
</script>
</body>
</html>