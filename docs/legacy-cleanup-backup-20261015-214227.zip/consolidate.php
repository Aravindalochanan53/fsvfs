<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>KEC Internship Portal | Consolidated Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
    --blue-900: #041b11;
    --blue-800: #072b18;
    --blue-700: #0b4425;
    --blue-600: #116530;
    --blue-500: #15803d;
    --blue-400: #22c55e;
    --blue-300: #4ade80;
    --blue-100: #dcfce7;
    --blue-50:  #f0fdf4;
    --accent:   #86efac;
    --white:    #ffffff;
    --text-dark: #0b1d13;
    --text-mid:  #36543d;
    --text-muted:#5f7d66;
}
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DM Sans', sans-serif; background: #f0f6ff; color: var(--text-dark); }

        .site-header {
            background: linear-gradient(135deg, var(--blue-900) 0%, var(--blue-700) 60%, var(--blue-500) 100%);
            padding: 18px 20px 14px;
            text-align: center;
            position: sticky;
            top: 0;
            z-index: 1030;
            box-shadow: 0 4px 24px rgba(10,22,40,0.35);
        }
        .site-header h1 { font-family: 'Sora', sans-serif; font-weight: 800; font-size: 1.9rem; letter-spacing: 3px; color: #fff; text-transform: uppercase; }
        .site-header p { font-size: 0.85rem; color: var(--blue-300); margin-top: 2px; letter-spacing: 0.5px; }
        .header-line { width: 60px; height: 3px; background: var(--accent); margin: 8px auto 0; border-radius: 2px; }

        .site-nav { background: var(--white); border-bottom: 2px solid var(--blue-100); position: sticky; top: 78px; z-index: 1020; box-shadow: 0 2px 12px rgba(18,81,181,0.08); }
        .site-nav nav { display: flex; justify-content: center; gap: 10px; padding: 10px 16px; flex-wrap: wrap; }
        .site-nav .nav-btn { font-family: 'Sora', sans-serif; font-weight: 600; font-size: 0.82rem; letter-spacing: 0.5px; color: var(--blue-600); border: 2px solid var(--blue-100); background: var(--blue-50); border-radius: 40px; padding: 7px 20px; text-decoration: none; transition: all 0.22s ease; white-space: nowrap; }
        .site-nav .nav-btn:hover, .site-nav .nav-btn.active { background: var(--blue-600); color: #fff; border-color: var(--blue-600); box-shadow: 0 4px 16px rgba(18,81,181,0.3); transform: translateY(-1px); }

        .page-hero { background: linear-gradient(135deg, var(--blue-800) 0%, var(--blue-600) 60%, var(--blue-400) 100%); padding: 56px 20px 48px; text-align: center; position: relative; overflow: hidden; }
        .page-hero::before { content: ''; position: absolute; inset: 0; background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.04'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E"); }
        .page-hero h2 { font-family: 'Sora', sans-serif; font-weight: 800; font-size: 2.4rem; color: #fff; position: relative; z-index: 2; }
        .page-hero p { color: var(--blue-100); font-size: 1.05rem; margin-top: 12px; max-width: 600px; margin-left: auto; margin-right: auto; position: relative; z-index: 2; line-height: 1.65; }
        .hero-badge { display: inline-block; background: rgba(255,255,255,0.15); border: 1.5px solid rgba(255,255,255,0.3); border-radius: 40px; padding: 6px 20px; font-family: 'Sora', sans-serif; font-size: 0.8rem; font-weight: 600; color: #fff; letter-spacing: 1px; margin-bottom: 20px; position: relative; z-index: 2; }

        .stat-strip { background: var(--white); border-bottom: 1.5px solid var(--blue-100); padding: 0 20px; box-shadow: 0 4px 20px rgba(18,81,181,0.06); }
        .stat-strip-inner { max-width: 1100px; margin: 0 auto; display: grid; grid-template-columns: repeat(4, 1fr); gap: 0; }
        .stat-item { padding: 24px 16px; text-align: center; border-right: 1.5px solid var(--blue-100); }
        .stat-item:last-child { border-right: none; }
        .stat-number { font-family: 'Sora', sans-serif; font-size: 2rem; font-weight: 800; color: var(--blue-600); line-height: 1; }
        .stat-label { font-size: 0.8rem; color: var(--text-muted); margin-top: 4px; font-weight: 500; }

        .actions-section { max-width: 1100px; margin: 48px auto 0; padding: 0 20px; }
        .actions-section .section-title { font-family: 'Sora', sans-serif; font-weight: 800; font-size: 1.7rem; color: var(--blue-800); text-align: center; margin-bottom: 8px; }
        .actions-section .section-sub { text-align: center; color: var(--text-muted); font-size: 0.97rem; margin-bottom: 36px; }
        .action-card { background: var(--white); border-radius: 20px; padding: 32px 28px; border: 1.5px solid var(--blue-100); box-shadow: 0 4px 20px rgba(18,81,181,0.07); text-align: center; height: 100%; transition: all 0.25s; display: flex; flex-direction: column; align-items: center; justify-content: space-between; gap: 16px; }
        .action-card:hover { transform: translateY(-6px); box-shadow: 0 20px 48px rgba(18,81,181,0.16); border-color: var(--blue-300); }
        .action-icon { font-size: 2.6rem; display: block; }
        .action-card h5 { font-family: 'Sora', sans-serif; font-weight: 700; font-size: 1.05rem; color: var(--blue-700); }
        .action-card p { font-size: 0.88rem; color: var(--text-muted); line-height: 1.6; }
        .action-btn { display: inline-block; background: linear-gradient(135deg, var(--blue-600), var(--blue-400)); color: #fff; font-family: 'Sora', sans-serif; font-weight: 700; font-size: 0.85rem; padding: 11px 28px; border-radius: 50px; text-decoration: none; border: none; cursor: pointer; box-shadow: 0 6px 20px rgba(18,81,181,0.28); transition: all 0.22s; width: 100%; }
        .action-btn:hover { transform: translateY(-2px); box-shadow: 0 10px 28px rgba(18,81,181,0.4); color: #fff; }
        .action-btn.secondary { background: var(--white); color: var(--blue-600); border: 2px solid var(--blue-300); box-shadow: none; }
        .action-btn.secondary:hover { background: var(--blue-50); color: var(--blue-700); }

        .table-section { max-width: 1200px; margin: 56px auto 0; padding: 0 20px; }
        .table-wrap { background: var(--white); border-radius: 20px; border: 1.5px solid var(--blue-100); box-shadow: 0 8px 32px rgba(18,81,181,0.07); overflow: hidden; }
        .table-header { background: linear-gradient(135deg, var(--blue-800), var(--blue-600)); padding: 22px 28px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
        .table-header h4 { font-family: 'Sora', sans-serif; font-weight: 700; font-size: 1.1rem; color: #fff; }
        .table-header p { font-size: 0.82rem; color: var(--blue-200, #bfdbfe); margin: 0; }
        .search-box { background: rgba(255,255,255,0.15); border: 1.5px solid rgba(255,255,255,0.25); border-radius: 40px; padding: 8px 18px; color: #fff; font-size: 0.85rem; outline: none; font-family: 'DM Sans', sans-serif; width: 220px; }
        .search-box::placeholder { color: rgba(255,255,255,0.6); }
        .table-body { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
        thead th { background: var(--blue-50); color: var(--blue-700); font-family: 'Sora', sans-serif; font-weight: 700; font-size: 0.78rem; letter-spacing: 0.5px; text-transform: uppercase; padding: 14px 16px; border-bottom: 2px solid var(--blue-100); white-space: nowrap; }
        tbody tr { border-bottom: 1px solid #f0f6ff; transition: background 0.15s; }
        tbody tr:hover { background: var(--blue-50); }
        tbody tr:last-child { border-bottom: none; }
        tbody td { padding: 14px 16px; color: var(--text-mid); vertical-align: middle; }
        .status-pill { display: inline-block; padding: 4px 14px; border-radius: 40px; font-size: 0.75rem; font-weight: 700; font-family: 'Sora', sans-serif; }
        .status-completed { background: #dcfce7; color: #15803d; }
        .status-ongoing   { background: #fef9c3; color: #92400e; }
        .status-pending   { background: #fee2e2; color: #b91c1c; }
        .att-high { color: #15803d; font-weight: 700; }
        .att-mid  { color: #b45309; font-weight: 700; }
        .att-low  { color: #b91c1c; font-weight: 700; }

        .info-band { background: linear-gradient(135deg, var(--blue-800), var(--blue-600)); margin: 56px 0 0; padding: 52px 20px; text-align: center; }
        .info-band h2 { font-family: 'Sora', sans-serif; font-weight: 800; font-size: 1.8rem; color: #fff; margin-bottom: 14px; }
        .info-band p { color: var(--blue-100); font-size: 1rem; max-width: 720px; margin: 0 auto; line-height: 1.7; }

        .section-title { font-family: 'Sora', sans-serif; font-weight: 800; font-size: 1.9rem; color: var(--blue-800); text-align: center; margin-bottom: 8px; }
        .section-sub { text-align: center; color: var(--text-muted); font-size: 1rem; margin-bottom: 36px; }
        .grid-section { max-width: 1200px; margin: 56px auto 0; padding: 0 20px; display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px; }
        .grid-card { background: #fff; border-radius: 20px; padding: 28px 24px; border: 1.5px solid var(--blue-100); box-shadow: 0 4px 16px rgba(18,81,181,0.06); transition: all 0.25s; }
        .grid-card:hover { transform: translateY(-5px); box-shadow: 0 20px 40px rgba(18,81,181,0.14); border-color: var(--blue-400); }
        .grid-card-title { font-family: 'Sora', sans-serif; font-weight: 700; font-size: 1.05rem; color: var(--blue-700); margin-bottom: 16px; padding-bottom: 10px; border-bottom: 3px solid var(--blue-100); }
        .grid-card ul { list-style: none; padding: 0; }
        .grid-card ul li { padding: 7px 0 7px 28px; position: relative; font-size: 0.93rem; color: var(--text-mid); border-bottom: 1px solid #f0f6ff; }
        .grid-card ul li:last-child { border-bottom: none; }
        .grid-card ul li::before { content: "✓"; color: var(--blue-500); font-weight: 700; position: absolute; left: 0; }

        .timeline-section { max-width: 900px; margin: 56px auto 0; padding: 0 20px; }
        .timeline { position: relative; padding-left: 40px; margin-top: 36px; }
        .timeline::before { content: ''; position: absolute; left: 12px; top: 0; bottom: 0; width: 3px; background: linear-gradient(180deg, var(--blue-500), var(--blue-300)); border-radius: 2px; }
        .timeline-item { position: relative; margin-bottom: 32px; }
        .timeline-dot { position: absolute; left: -35px; top: 4px; width: 22px; height: 22px; border-radius: 50%; background: linear-gradient(135deg, var(--blue-600), var(--blue-400)); border: 3px solid #fff; box-shadow: 0 2px 8px rgba(18,81,181,0.3); }
        .timeline-content { background: #fff; border-radius: 16px; padding: 20px 24px; border: 1.5px solid var(--blue-100); box-shadow: 0 4px 16px rgba(18,81,181,0.06); }
        .timeline-content h5 { font-family: 'Sora', sans-serif; font-weight: 700; color: var(--blue-700); font-size: 1rem; margin-bottom: 4px; }
        .timeline-content p { color: var(--text-muted); font-size: 0.88rem; margin: 0; line-height: 1.55; }
        .timeline-num { display: inline-block; background: var(--blue-50); color: var(--blue-600); border: 1.5px solid var(--blue-100); border-radius: 40px; padding: 2px 12px; font-size: 0.75rem; font-weight: 700; font-family: 'Sora', sans-serif; margin-bottom: 6px; }

        .overview-band { background: var(--white); border: 1.5px solid var(--blue-100); border-radius: 24px; max-width: 1100px; margin: 56px auto 0; padding: 48px 36px; text-align: center; box-shadow: 0 8px 32px rgba(18,81,181,0.07); }
        .overview-band h2 { font-family: 'Sora', sans-serif; font-weight: 800; font-size: 1.8rem; color: var(--blue-800); margin-bottom: 14px; }
        .overview-band p { color: var(--text-mid); font-size: 1rem; line-height: 1.75; max-width: 700px; margin: 0 auto 24px; }
        .badge-pill { display: inline-block; background: var(--blue-50); color: var(--blue-700); border: 1.5px solid var(--blue-100); border-radius: 40px; padding: 8px 20px; font-size: 0.87rem; font-weight: 600; margin: 5px; font-family: 'Sora', sans-serif; }

        footer { background: var(--blue-900); margin-top: 64px; padding: 36px 20px; text-align: center; }
        footer p { color: var(--blue-300); font-size: 0.88rem; margin-bottom: 4px; }
        footer .footer-line { width: 50px; height: 2px; background: var(--accent); margin: 12px auto; border-radius: 2px; }

        @media (max-width: 768px) {
            .page-hero h2 { font-size: 1.7rem; }
            .stat-strip-inner { grid-template-columns: repeat(2, 1fr); }
            .stat-item:nth-child(2) { border-right: none; }
            .stat-item:nth-child(3) { border-top: 1.5px solid var(--blue-100); }
            .stat-item:nth-child(4) { border-top: 1.5px solid var(--blue-100); border-right: none; }
            .table-header { flex-direction: column; align-items: flex-start; }
            .search-box { width: 100%; }
            .overview-band { padding: 32px 20px; }
        }
        @media (max-width: 480px) {
            .site-header h1 { font-size: 1.4rem; letter-spacing: 2px; }
            .site-nav .nav-btn { font-size: 0.75rem; padding: 6px 14px; }
            .stat-number { font-size: 1.6rem; }
        }

        /* ===================== PHOTO UPLOAD MODAL ===================== */
        .upload-modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(4, 27, 17, 0.7);
            backdrop-filter: blur(6px);
            z-index: 9999;
            align-items: center;
            justify-content: center;
            animation: fadeInOverlay 0.25s ease;
        }
        .upload-modal-overlay.show {
            display: flex;
        }
        @keyframes fadeInOverlay {
            from { opacity: 0; }
            to   { opacity: 1; }
        }
        .upload-modal {
            background: #fff;
            border-radius: 28px;
            width: 92%;
            max-width: 520px;
            box-shadow: 0 32px 80px rgba(4, 27, 17, 0.45);
            overflow: hidden;
            animation: slideUpModal 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        @keyframes slideUpModal {
            from { transform: translateY(40px) scale(0.96); opacity: 0; }
            to   { transform: translateY(0) scale(1);     opacity: 1; }
        }
        .upload-modal-header {
            background: linear-gradient(135deg, var(--blue-800), var(--blue-600));
            padding: 24px 28px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .upload-modal-header h5 {
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 1.1rem;
            color: #fff;
            margin: 0;
        }
        .upload-modal-header p {
            font-size: 0.8rem;
            color: var(--blue-100);
            margin: 4px 0 0;
        }
        .modal-close-btn {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border: 2px solid rgba(255,255,255,0.3);
            background: rgba(255,255,255,0.1);
            color: #fff;
            font-size: 1.2rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            flex-shrink: 0;
        }
        .modal-close-btn:hover {
            background: rgba(255,255,255,0.25);
            border-color: rgba(255,255,255,0.6);
        }
        .upload-modal-body {
            padding: 28px;
        }

        /* Drop Zone */
        .drop-zone {
            border: 2.5px dashed var(--blue-300);
            border-radius: 18px;
            background: var(--blue-50);
            padding: 40px 24px;
            text-align: center;
            cursor: pointer;
            transition: all 0.22s;
            position: relative;
            overflow: hidden;
        }
        .drop-zone:hover, .drop-zone.dragover {
            border-color: var(--blue-500);
            background: #e6f9ee;
            transform: scale(1.01);
        }
        .drop-zone input[type="file"] {
            position: absolute;
            inset: 0;
            opacity: 0;
            cursor: pointer;
            width: 100%;
            height: 100%;
        }
        .drop-zone-icon {
            font-size: 3rem;
            display: block;
            margin-bottom: 12px;
        }
        .drop-zone h6 {
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            color: var(--blue-700);
            font-size: 1rem;
            margin-bottom: 6px;
        }
        .drop-zone p {
            font-size: 0.82rem;
            color: var(--text-muted);
            margin: 0;
        }
        .drop-zone .browse-link {
            color: var(--blue-500);
            font-weight: 700;
            text-decoration: underline;
        }

        /* Preview Area */
        .preview-area {
            display: none;
            margin-top: 20px;
            position: relative;
        }
        .preview-area.show { display: block; }
        .preview-wrap {
            border-radius: 16px;
            overflow: hidden;
            border: 2px solid var(--blue-100);
            position: relative;
        }
        .preview-wrap img {
            width: 100%;
            max-height: 220px;
            object-fit: cover;
            display: block;
        }
        .preview-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background: rgba(4,27,17,0.75);
            color: #fff;
            font-family: 'Sora', sans-serif;
            font-size: 0.72rem;
            font-weight: 700;
            padding: 4px 12px;
            border-radius: 40px;
            backdrop-filter: blur(4px);
        }
        .preview-remove {
            position: absolute;
            top: 10px;
            right: 10px;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: rgba(185,28,28,0.85);
            color: #fff;
            border: none;
            font-size: 1rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        .preview-remove:hover { background: #b91c1c; transform: scale(1.1); }
        .preview-filename {
            margin-top: 10px;
            font-size: 0.83rem;
            color: var(--text-mid);
            text-align: center;
            font-weight: 500;
        }
        .preview-filename span {
            color: var(--blue-600);
            font-weight: 700;
        }

        /* File type note */
        .file-types-row {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin-top: 16px;
            flex-wrap: wrap;
        }
        .file-type-tag {
            background: var(--blue-50);
            border: 1.5px solid var(--blue-100);
            color: var(--blue-600);
            border-radius: 40px;
            padding: 3px 12px;
            font-size: 0.75rem;
            font-weight: 700;
            font-family: 'Sora', sans-serif;
        }

        /* Modal Footer Buttons */
        .upload-modal-footer {
            padding: 0 28px 28px;
            display: flex;
            gap: 12px;
        }
        .modal-btn-cancel {
            flex: 1;
            background: var(--white);
            color: var(--blue-600);
            border: 2px solid var(--blue-100);
            border-radius: 50px;
            padding: 12px;
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 0.88rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        .modal-btn-cancel:hover { background: var(--blue-50); border-color: var(--blue-300); }
        .modal-btn-upload {
            flex: 2;
            background: linear-gradient(135deg, var(--blue-600), var(--blue-400));
            color: #fff;
            border: none;
            border-radius: 50px;
            padding: 12px;
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 0.88rem;
            cursor: pointer;
            box-shadow: 0 6px 20px rgba(17,101,48,0.35);
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .modal-btn-upload:hover { transform: translateY(-2px); box-shadow: 0 10px 28px rgba(17,101,48,0.45); }
        .modal-btn-upload:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

        /* Success state */
        .upload-success {
            display: none;
            text-align: center;
            padding: 24px;
        }
        .upload-success.show { display: block; }
        .success-icon { font-size: 3.5rem; margin-bottom: 12px; animation: bounceIn 0.5s cubic-bezier(0.34,1.56,0.64,1); }
        @keyframes bounceIn {
            from { transform: scale(0); opacity: 0; }
            to   { transform: scale(1); opacity: 1; }
        }
        .upload-success h5 { font-family: 'Sora', sans-serif; font-weight: 800; color: var(--blue-700); font-size: 1.2rem; margin-bottom: 6px; }
        .upload-success p { color: var(--text-muted); font-size: 0.9rem; }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="site-header">
    <h1>✦ INTERNSHIP PORTAL</h1>
    <p>Kongu Engineering College &nbsp;|&nbsp; Industry Ready Portal</p>
    
</div>

<!-- NAVBAR -->
<div class="site-nav">
    <nav>
        <a class="nav-btn" href="home1.php">🏠 HOME</a>
        <a class="nav-btn active" href="consolidate.php">📊 CONSOLIDATE</a>
   
        <a class="nav-btn" href="about1.php">ℹ️ ABOUT US</a>
    </nav>
</div>

<!-- PAGE HERO -->
<div class="page-hero">
    <div class="hero-badge">📊 CONSOLIDATED REPORTS</div>
    <h2>Internship Data at a Glance</h2>
    <p>View, manage and export all student internship records from a single unified dashboard. Track progress, attendance and status in real time.</p>
</div>

<!-- STAT STRIP -->


<!-- QUICK ACTIONS -->
<div class="actions-section mt-5">
    
    <div class="row g-4">
        <div class="col-md-4">
            <div class="action-card">
                <span class="action-icon">📄</span>
                <div>
                    <h5>Add Internship Report</h5>
                    <p>Submit a new internship document for a student. Upload your report photo or scan directly.</p>
                </div>
                <!-- ✅ This button opens the photo upload modal -->
                <button class="action-btn" onclick="openUploadModal()">📸 Upload Report Photo</button>
            </div>
        </div>
        <div class="col-md-4">
            <div class="action-card">
                <span class="action-icon">🎓</span>
                <div>
                    <h5>Add Student Record</h5>
                    <p>Register a new student's internship entry with all required personal and company details.</p>
                </div>
                <a href="report.php" class="action-btn">➕ Add Student Report</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="action-card">
                <span class="action-icon">📅</span>
                <div>
                    <h5>Attendance Tracker</h5>
                    <p>Mark and review internship attendance records. Ensure minimum criteria are met for completion.</p>
                </div>
                <a href="attendence.php" class="action-btn">📋 Go to Attendance</a>
            </div>
        </div>
    </div>
</div>

<!-- CONSOLIDATED TABLE -->


<!-- INFO BAND -->
<div class="info-band">
    <h2>📋 Why Consolidated Reports Matter</h2>
    <p>A consolidated internship report gives faculty and coordinators a bird's eye view of all student activities. It enables quick verification, accurate record keeping and seamless data submission to the university, making the entire process efficient and transparent.</p>
</div>

<!-- GRID CARDS -->
<div class="grid-section">
    <div class="grid-card">
        <div class="grid-card-title">📌 Report Contents</div>
        <ul>
            <li>Student name &amp; registration</li>
            <li>Company &amp; department</li>
            <li>Duration &amp; date range</li>
            <li>Attendance percentage</li>
            <li>Completion status</li>
            <li>Faculty verification remarks</li>
        </ul>
    </div>
    <div class="grid-card">
        <div class="grid-card-title">🎓 Student Advantages</div>
        <ul>
            <li>Single dashboard for all data</li>
            <li>Instant report download</li>
            <li>Attendance alerts</li>
            <li>Company history maintained</li>
            <li>Easier placement preparation</li>
            <li>Anytime data access</li>
        </ul>
    </div>
    <div class="grid-card">
        <div class="grid-card-title">👨‍🏫 Faculty Controls</div>
        <ul>
            <li>Department-level filtering</li>
            <li>Bulk status verification</li>
            <li>Attendance shortfall alerts</li>
            <li>Export reports to PDF</li>
            <li>Monitor ongoing internships</li>
            <li>Academic record update</li>
        </ul>
    </div>
</div>

<!-- TIMELINE -->
<div class="timeline-section">
    <h2 class="section-title">📍 Report Workflow</h2>
    <p class="section-sub">Follow these steps to ensure a complete and verified consolidated report.</p>
    <div class="timeline">
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <div class="timeline-num">STEP 01</div>
                <h5>Student Submits Internship Details</h5>
                <p>Fill the internship form with company name, domain, mentor contact, duration and location through the Internship page.</p>
            </div>
        </div>
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <div class="timeline-num">STEP 02</div>
                <h5>Attendance is Recorded Daily</h5>
                <p>Students mark daily attendance through the Attendance Tracker. A minimum of 75% attendance is required for report validation.</p>
            </div>
        </div>
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <div class="timeline-num">STEP 03</div>
                <h5>Consolidated Data Auto-Populated</h5>
                <p>Once the form is submitted, all student records automatically appear in the consolidated table with attendance and status.</p>
            </div>
        </div>
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <div class="timeline-num">STEP 04</div>
                <h5>Faculty Reviews &amp; Verifies</h5>
                <p>The faculty coordinator reviews the consolidated report, verifies attendance and updates the final status for each student.</p>
            </div>
        </div>
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <div class="timeline-num">STEP 05</div>
                <h5>Report Exported &amp; Submitted</h5>
                <p>The final verified report is exported and submitted to the department for academic record and university compliance.</p>
            </div>
        </div>
    </div>
</div>

<!-- OVERVIEW BAND -->
<div class="overview-band">
    <h2>📌 About the Consolidate Module</h2>
    <p>The Consolidate page brings together all internship data in one structured view. Students, faculty and coordinators can access a unified record of every internship, track completion and ensure no entry is missed before the academic submission deadline.</p>
    <div>
        <span class="badge-pill">📅 Real-time Data</span>
        <span class="badge-pill">📑 Auto-populated Table</span>
        <span class="badge-pill">🔐 Faculty Verified</span>
        <span class="badge-pill">📤 Exportable Reports</span>
    </div>
</div>

<!-- FOOTER -->
<footer>
    <p>© 2025 Kongu Engineering College — Internship Management Portal</p>
    <p>📍 Perundurai, Erode, Tamil Nadu &nbsp;|&nbsp; 📧 internship@kongu.edu</p>
    <div class="footer-line"></div>
    <p>Empowering students with industry-ready internship tracking</p>
</footer>


<!-- ==================== PHOTO UPLOAD MODAL ==================== -->
<div class="upload-modal-overlay" id="uploadModalOverlay" onclick="handleOverlayClick(event)">
    <div class="upload-modal" id="uploadModal">

        <!-- Modal Header -->
        <div class="upload-modal-header">
            <div>
                <h5>📸 Upload Internship Report Photo</h5>
                <p>Upload a clear photo or scanned copy of the document</p>
            </div>
            <button class="modal-close-btn" onclick="closeUploadModal()">✕</button>
        </div>

        <!-- Modal Body -->
        <div class="upload-modal-body" id="uploadModalBody">

            <!-- Drop Zone -->
            <div class="drop-zone" id="dropZone"
                 ondragover="handleDragOver(event)"
                 ondragleave="handleDragLeave(event)"
                 ondrop="handleDrop(event)">
                <input type="file" id="photoInput" accept="image/jpeg,image/png,image/jpg,image/webp,image/heic,.pdf"
                       onchange="handleFileSelect(event)">
                <span class="drop-zone-icon">📁</span>
                <h6>Drag &amp; Drop your file here</h6>
                <p>or <span class="browse-link">click to browse</span> from your device</p>
            </div>

            <!-- File type tags -->
            <div class="file-types-row">
                <span class="file-type-tag">JPG</span>
                <span class="file-type-tag">PNG</span>
                <span class="file-type-tag">WEBP</span>
                <span class="file-type-tag">HEIC</span>
                <span class="file-type-tag">PDF</span>
                <span class="file-type-tag">Max 10 MB</span>
            </div>

            <!-- Preview Area -->
            <div class="preview-area" id="previewArea">
                <div class="preview-wrap">
                    <img id="previewImg" src="" alt="Preview">
                    <span class="preview-badge" id="previewBadge">📄 Report Photo</span>
                    <button class="preview-remove" onclick="removeFile()" title="Remove">✕</button>
                </div>
                <div class="preview-filename">
                    File: <span id="previewFilename">—</span>
                </div>
            </div>

        </div>

        <!-- Success State -->
        <div class="upload-success" id="uploadSuccess">
            <div class="success-icon">✅</div>
            <h5>Photo Uploaded Successfully!</h5>
            <p>The internship report photo has been saved. It will appear in the student's record shortly.</p>
        </div>

        <!-- Modal Footer -->
        <div class="upload-modal-footer" id="uploadModalFooter">
            <button class="modal-btn-cancel" onclick="closeUploadModal()">Cancel</button>
            <button class="modal-btn-upload" id="uploadBtn" onclick="submitUpload()" disabled>
                <span>📤</span> Upload Photo
            </button>
        </div>

    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
    /* ---- Load saved data from localStorage ---- */
    window.onload = function () {
        var savedData = localStorage.getItem("internData");
        if (savedData) {
            var data = JSON.parse(savedData);
            var tbody = document.getElementById("tableBody");
            var rowCount = tbody.rows.length + 1;
            var row = tbody.insertRow(-1);
            row.insertCell(0).innerHTML = rowCount;
            row.insertCell(1).innerHTML = "<strong>" + (data.name || "—") + "</strong>";
            row.insertCell(2).innerHTML = data.reg || "—";
            row.insertCell(3).innerHTML = data.dept || "—";
            row.insertCell(4).innerHTML = data.company || "—";
            row.insertCell(5).innerHTML = data.duration || "—";
            var att = localStorage.getItem("attendancePercent") || "—";
            var attNum = parseFloat(att);
            var attClass = attNum >= 85 ? "att-high" : attNum >= 75 ? "att-mid" : "att-low";
            row.insertCell(6).innerHTML = "<span class='" + attClass + "'>" + (isNaN(attNum) ? att : att + "%") + "</span>";
            var status = data.status || "Ongoing";
            var pill = status === "Completed" ? "status-completed" : status === "Pending" ? "status-pending" : "status-ongoing";
            row.insertCell(7).innerHTML = "<span class='status-pill " + pill + "'>" + status + "</span>";
            row.insertCell(8).innerHTML = "<span style='color:var(--text-muted);font-size:0.8rem;'>—</span>";
            localStorage.removeItem("internData");
        }
        updateStats();
    };

    function updateStats() {
        var rows = document.querySelectorAll("#tableBody tr");
        var total = rows.length, completed = 0, ongoing = 0, attSum = 0, attCount = 0;
        rows.forEach(function (row) {
            var statusEl = row.querySelector(".status-pill");
            if (statusEl) {
                if (statusEl.classList.contains("status-completed")) completed++;
                if (statusEl.classList.contains("status-ongoing")) ongoing++;
            }
            var attEl = row.cells[6];
            if (attEl) {
                var val = parseFloat(attEl.textContent);
                if (!isNaN(val)) { attSum += val; attCount++; }
            }
        });
        animateCount("totalStudents", total);
        animateCount("completedCount", completed);
        animateCount("ongoingCount", ongoing);
        document.getElementById("avgAttendance").textContent = attCount ? Math.round(attSum / attCount) + "%" : "—";
    }

    function animateCount(id, target) {
        var el = document.getElementById(id);
        var current = 0;
        var step = Math.ceil(target / 30);
        var timer = setInterval(function () {
            current += step;
            if (current >= target) { current = target; clearInterval(timer); }
            el.textContent = current;
        }, 30);
    }

    function filterTable() {
        var q = document.getElementById("searchInput").value.toLowerCase();
        document.querySelectorAll("#tableBody tr").forEach(function (row) {
            row.style.display = row.textContent.toLowerCase().includes(q) ? "" : "none";
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('mouseenter', () => btn.style.letterSpacing = '0.8px');
            btn.addEventListener('mouseleave', () => btn.style.letterSpacing = '0.5px');
        });
    });

    /* ============ PHOTO UPLOAD MODAL LOGIC ============ */

    var selectedFile = null;

    function openUploadModal() {
        // Reset modal state
        resetModal();
        document.getElementById("uploadModalOverlay").classList.add("show");
        document.body.style.overflow = "hidden";
    }

    function closeUploadModal() {
        document.getElementById("uploadModalOverlay").classList.remove("show");
        document.body.style.overflow = "";
        setTimeout(resetModal, 300);
    }

    function handleOverlayClick(e) {
        if (e.target === document.getElementById("uploadModalOverlay")) {
            closeUploadModal();
        }
    }

    function resetModal() {
        selectedFile = null;
        document.getElementById("photoInput").value = "";
        document.getElementById("previewArea").classList.remove("show");
        document.getElementById("previewImg").src = "";
        document.getElementById("previewFilename").textContent = "—";
        document.getElementById("uploadBtn").disabled = true;
        document.getElementById("uploadSuccess").classList.remove("show");
        document.getElementById("uploadModalBody").style.display = "block";
        document.getElementById("uploadModalFooter").style.display = "flex";
        document.getElementById("dropZone").style.display = "block";
    }

    function handleFileSelect(e) {
        var file = e.target.files[0];
        if (file) processFile(file);
    }

    function handleDragOver(e) {
        e.preventDefault();
        document.getElementById("dropZone").classList.add("dragover");
    }

    function handleDragLeave(e) {
        document.getElementById("dropZone").classList.remove("dragover");
    }

    function handleDrop(e) {
        e.preventDefault();
        document.getElementById("dropZone").classList.remove("dragover");
        var file = e.dataTransfer.files[0];
        if (file) processFile(file);
    }

    function processFile(file) {
        // Validate size (10MB)
        if (file.size > 10 * 1024 * 1024) {
            alert("❌ File size exceeds 10 MB. Please upload a smaller file.");
            return;
        }
        // Validate type
        var allowed = ["image/jpeg", "image/png", "image/jpg", "image/webp", "image/heic", "application/pdf"];
        if (!allowed.includes(file.type) && !file.name.endsWith(".heic")) {
            alert("❌ Invalid file type. Please upload JPG, PNG, WEBP, HEIC, or PDF.");
            return;
        }

        selectedFile = file;
        document.getElementById("previewFilename").textContent = file.name;
        document.getElementById("previewBadge").textContent = file.type === "application/pdf" ? "📄 PDF Document" : "🖼️ Report Photo";
        document.getElementById("uploadBtn").disabled = false;

        // Show image preview (for images only)
        if (file.type.startsWith("image/")) {
            var reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById("previewImg").src = e.target.result;
                document.getElementById("previewArea").classList.add("show");
            };
            reader.readAsDataURL(file);
        } else {
            // PDF — show placeholder
            document.getElementById("previewImg").src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='520' height='160' viewBox='0 0 520 160'%3E%3Crect width='520' height='160' fill='%23f0fdf4'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-size='48'%3E📄%3C/text%3E%3C/svg%3E";
            document.getElementById("previewArea").classList.add("show");
        }
    }

    function removeFile() {
        selectedFile = null;
        document.getElementById("photoInput").value = "";
        document.getElementById("previewArea").classList.remove("show");
        document.getElementById("previewImg").src = "";
        document.getElementById("uploadBtn").disabled = true;
    }

    function submitUpload() {
        if (!selectedFile) return;

        var btn = document.getElementById("uploadBtn");
        btn.disabled = true;
        btn.innerHTML = "<span>⏳</span> Uploading…";

        // Simulate upload (replace with real fetch/FormData for backend)
        setTimeout(function () {
            // Show success
            document.getElementById("uploadModalBody").style.display = "none";
            document.getElementById("uploadModalFooter").style.display = "none";
            document.getElementById("uploadSuccess").classList.add("show");

            // Update last table row's Photo cell with a thumbnail link
            var rows = document.querySelectorAll("#tableBody tr");
            if (rows.length > 0 && selectedFile.type.startsWith("image/")) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    var lastPhotoCell = rows[rows.length - 1].cells[8];
                    if (lastPhotoCell) {
                        lastPhotoCell.innerHTML =
                            "<a href='" + e.target.result + "' target='_blank' title='View Photo'>" +
                            "<img src='" + e.target.result + "' style='width:38px;height:38px;object-fit:cover;border-radius:8px;border:2px solid var(--blue-100);cursor:pointer;'>" +
                            "</a>";
                    } 
                };
                reader.readAsDataURL(selectedFile);
            }

            // Auto close after 2s
            setTimeout(closeUploadModal, 2200);
        }, 1400);
    }

    // ESC key closes modal
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") closeUploadModal();
    });
</script>
</body>
</html>