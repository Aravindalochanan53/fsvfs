<?php
// student_report.php — Individual student internship attendance report
// URL: student_report.php?id=<student_id>
$studentId = (int)($_GET['id'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>InternTrack — Student Report</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<style>
:root{
  --g900:#052e16;--g800:#14532d;--g700:#166534;--g600:#16a34a;
  --g500:#22c55e;--g400:#4ade80;--g300:#86efac;--g200:#bbf7d0;--g100:#dcfce7;
  --surface:#f8fdf9;--card:#fff;--card-alt:#f0fdf4;
  --border:#d1fae5;--border-md:#a7f3d0;
  --t900:#052e16;--t700:#166534;--t500:#16a34a;--tmuted:#6b7280;--tsubtle:#9ca3af;
  --danger:#ef4444;--warn:#f59e0b;--info:#3b82f6;
  --sh-sm:0 1px 3px rgba(0,0,0,.06);
  --sh-md:0 4px 16px rgba(0,0,0,.08);
  --sh-lg:0 10px 40px rgba(0,0,0,.1);
  --sh-green:0 4px 24px rgba(34,197,94,.18);
  --r:14px;--rlg:20px;--rxl:28px;
}
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Sora',sans-serif;background:var(--surface);color:var(--t900);min-height:100vh;}

/* TOPBAR */
.topbar{background:#fff;border-bottom:1px solid var(--border);padding:0 2rem;height:64px;
  display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:200;box-shadow:var(--sh-sm);}
.brand{display:flex;align-items:center;gap:12px;text-decoration:none;}
.brand-mark{width:38px;height:38px;background:linear-gradient(135deg,var(--g700),var(--g500));
  border-radius:10px;display:flex;align-items:center;justify-content:center;box-shadow:var(--sh-green);}
.brand-mark svg{width:20px;height:20px;fill:#fff;}
.brand-name{font-size:1.15rem;font-weight:800;letter-spacing:-.02em;color:var(--t900);}
.brand-name span{color:var(--g600);}
.topbar-right{display:flex;align-items:center;gap:14px;}
.btn-back{display:flex;align-items:center;gap:7px;padding:8px 16px;background:var(--card-alt);
  border:1.5px solid var(--border-md);border-radius:10px;color:var(--g700);font-size:.82rem;
  font-weight:700;text-decoration:none;transition:.15s;font-family:inherit;}
.btn-back:hover{background:var(--g700);color:#fff;border-color:transparent;}
.btn-pdf{display:flex;align-items:center;gap:7px;padding:8px 18px;
  background:linear-gradient(135deg,var(--g700),var(--g500));border:none;border-radius:10px;
  color:#fff;font-size:.82rem;font-weight:700;cursor:pointer;box-shadow:var(--sh-green);
  font-family:inherit;transition:.2s;}
.btn-pdf:hover{transform:translateY(-2px);box-shadow:0 8px 28px rgba(34,197,94,.3);}

/* SHELL */
.shell{max-width:1100px;margin:0 auto;padding:36px 20px 80px;}

/* PROFILE HEADER */
.profile-card{
  background:var(--card);border:1px solid var(--border);border-radius:var(--rxl);
  padding:32px;margin-bottom:24px;box-shadow:var(--sh-sm);
  position:relative;overflow:hidden;
}
.profile-card::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;
  background:linear-gradient(90deg,var(--g800),var(--g600),var(--g400));}
.pc-grid{display:flex;gap:24px;align-items:flex-start;flex-wrap:wrap;}
.pc-av-wrap{position:relative;flex-shrink:0;}
.pc-av{
  width:88px;height:88px;border-radius:20px;
  background:linear-gradient(135deg,var(--g800),var(--g600));
  display:flex;align-items:center;justify-content:center;
  font-size:2rem;font-weight:800;color:#fff;
  border:3px solid var(--g200);
  box-shadow:var(--sh-green);
}
.pc-online{position:absolute;bottom:5px;right:5px;width:15px;height:15px;
  background:var(--g500);border-radius:50%;border:2.5px solid #fff;}
.pc-body{flex:1;min-width:200px;}
.pc-name{font-size:1.5rem;font-weight:800;letter-spacing:-.03em;margin-bottom:3px;}
.pc-reg{font-family:'JetBrains Mono',monospace;font-size:.82rem;color:var(--g600);margin-bottom:10px;}
.pc-tags{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px;}
.ptag{font-size:.68rem;font-weight:700;padding:3px 10px;border-radius:100px;
  border:1px solid;text-transform:uppercase;letter-spacing:.04em;}
.ptag-dept{background:#f0fdf4;color:var(--g800);border-color:#bbf7d0;}
.ptag-course{background:#fffbeb;color:#92400e;border-color:#fde68a;}
.ptag-year{background:#eff6ff;color:#1d4ed8;border-color:#bfdbfe;}
.pc-contact{font-size:.78rem;color:var(--tmuted);display:flex;gap:16px;flex-wrap:wrap;}
.pc-contact i{color:var(--g600);margin-right:4px;}
.pc-right{margin-left:auto;text-align:right;}
.big-pct{font-size:3rem;font-weight:800;letter-spacing:-.06em;line-height:1;
  background:linear-gradient(135deg,var(--g600),var(--g400));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.big-pct-warn{background:linear-gradient(135deg,#dc2626,#f87171)!important;}
.pct-lbl{font-size:.7rem;color:var(--tmuted);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-top:2px;}
.elig-badge{display:inline-flex;align-items:center;gap:6px;padding:5px 14px;
  border-radius:100px;font-size:.77rem;font-weight:700;margin-top:10px;}
.elig-ok{background:#f0fdf4;color:var(--g800);border:1px solid #bbf7d0;}
.elig-warn{background:#fff7ed;color:#9a3412;border:1px solid #fed7aa;}

/* INTERNSHIP INFO CARD */
.info-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;margin-bottom:24px;}
.info-block{
  background:var(--card);border:1px solid var(--border);border-radius:var(--r);
  padding:18px 20px;box-shadow:var(--sh-sm);
}
.ib-label{font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--tmuted);margin-bottom:6px;}
.ib-val{font-size:.9rem;font-weight:700;color:var(--t900);display:flex;align-items:center;gap:7px;}
.ib-val i{color:var(--g600);font-size:.85rem;flex-shrink:0;}
.ib-sub{font-size:.75rem;color:var(--tmuted);margin-top:3px;}

/* STATUS INDICATOR */
.work-mode-badge{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;
  border-radius:100px;font-size:.7rem;font-weight:700;letter-spacing:.04em;}
.wm-onsite{background:#f0fdf4;color:var(--g800);border:1px solid #bbf7d0;}
.wm-remote{background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;}
.wm-hybrid{background:#fffbeb;color:#92400e;border:1px solid #fde68a;}

/* STAT BOXES */
.stat-boxes{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:24px;}
@media(max-width:700px){.stat-boxes{grid-template-columns:repeat(2,1fr);}}
.sbox{background:var(--card);border:1px solid var(--border);border-radius:var(--r);
  padding:20px;text-align:center;box-shadow:var(--sh-sm);border-top:3px solid;}
.sbox-g{border-top-color:var(--g500);}  .sbox-g .sn{color:var(--g700);}
.sbox-r{border-top-color:var(--danger);} .sbox-r .sn{color:#dc2626;}
.sbox-b{border-top-color:var(--info);}   .sbox-b .sn{color:#1d4ed8;}
.sbox-a{border-top-color:var(--warn);}   .sbox-a .sn{color:#d97706;}
.sbox-ico{font-size:1.2rem;margin-bottom:8px;}
.sn{font-size:1.9rem;font-weight:800;line-height:1;letter-spacing:-.04em;}
.sl{font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--tmuted);margin-top:4px;}

/* SECTION CARD */
.secc{background:var(--card);border:1px solid var(--border);border-radius:var(--r);
  margin-bottom:20px;box-shadow:var(--sh-sm);overflow:hidden;}
.sech{padding:16px 22px;border-bottom:1px solid var(--border);
  display:flex;align-items:center;justify-content:space-between;}
.sect{font-size:.9rem;font-weight:700;display:flex;align-items:center;gap:8px;color:var(--t900);}
.sect i{color:var(--g600);}
.secb{padding:22px;}
.secb-0{padding:0;overflow-x:auto;}

/* 2-col charts */
.charts2{display:grid;grid-template-columns:1fr 2fr;gap:18px;margin-bottom:20px;}
@media(max-width:700px){.charts2{grid-template-columns:1fr;}}
canvas{max-height:260px!important;}

/* TABLES */
.rtbl{width:100%;border-collapse:collapse;font-size:.85rem;}
.rtbl th{font-size:.7rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;
  color:var(--tmuted);padding:10px 14px;border-bottom:1px solid var(--border);text-align:left;
  white-space:nowrap;}
.rtbl td{padding:10px 14px;border-bottom:1px solid rgba(22,163,74,.07);vertical-align:middle;}
.rtbl tr:last-child td{border:none;}
.rtbl tr:hover td{background:rgba(22,163,74,.03);}
.mono{font-family:'JetBrains Mono',monospace;font-size:.78rem;}
.chip{padding:3px 10px;border-radius:100px;font-size:.7rem;font-weight:700;}
.cp{background:#f0fdf4;color:var(--g800);}
.ca{background:#fef2f2;color:#dc2626;}
.ch{background:#fffbeb;color:#d97706;}
.cl{background:#eff6ff;color:#1d4ed8;}
.gps-ok{color:var(--g600);}
.gps-no{color:#e5e7eb;}

/* PROGRESS BAR */
.prog-bar{height:8px;background:#f3f4f6;border-radius:100px;overflow:hidden;margin-top:4px;}
.prog-fill{height:100%;border-radius:100px;}
.pf-g{background:linear-gradient(90deg,var(--g700),var(--g500));}
.pf-r{background:linear-gradient(90deg,#dc2626,#f87171);}

/* MONTHLY CARDS */
.mgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;}
.mc{background:var(--card-alt);border:1px solid var(--border);border-radius:10px;
  padding:14px;text-align:center;}
.ml{font-size:.72rem;font-weight:600;color:var(--tmuted);margin-bottom:6px;}
.mp{font-size:1.3rem;font-weight:800;letter-spacing:-.04em;}
.mm{font-size:.7rem;color:var(--tmuted);margin-top:3px;}

/* LOADER */
.loader-wrap{text-align:center;padding:80px 20px;color:var(--tmuted);}
.loader{display:inline-flex;gap:6px;margin-bottom:14px;}
.loader span{width:9px;height:9px;background:var(--g500);border-radius:50%;animation:ld .7s infinite ease-in-out both;}
.loader span:nth-child(2){animation-delay:.15s;}
.loader span:nth-child(3){animation-delay:.3s;}
@keyframes ld{0%,80%,100%{transform:scale(0);opacity:.4}40%{transform:scale(1);opacity:1}}

/* GPS dot */
.loc-dot{display:inline-flex;align-items:center;gap:4px;font-size:.72rem;
  padding:2px 8px;border-radius:100px;font-weight:600;}
.loc-ok{background:#f0fdf4;color:var(--g700);}
.loc-no{background:#f9fafb;color:var(--tmuted);}
</style>
</head>
<body>

<!-- TOPBAR -->
<header class="topbar">
  <a href="index.php" class="brand">
    <div class="brand-mark">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/></svg>
    </div>
    
  </a>
  <div class="topbar-right">
    <a href=".php" class="btn-back"><i class="fa-solid fa-arrow-left"></i>Back</a>
    <button class="btn-pdf" onclick="window.print()"><i class="fa-solid fa-file-pdf"></i>Export PDF</button>
  </div>
</header>

<main class="shell">
  <!-- Content injected by JS -->
  <div id="reportContent">
    <div class="loader-wrap">
      <div class="loader"><span></span><span></span><span></span></div>
      <div>Loading student report…</div>
    </div>
  </div>
</main>

<script>
Chart.defaults.font.family = "'Sora', sans-serif";
Chart.defaults.color = '#6b7280';

const studentId = <?= $studentId ?>;
const API = 'api/students.php';
let charts = {};

// ── Init ─────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  if (!studentId) { showError('Invalid student ID.'); return; }
  await loadReport();
});

async function loadReport() {
  try {
    const res  = await fetch(`${API}?action=student&id=${studentId}`);
    const json = await res.json();
    if (json.success) render(json.data);
    else renderFallback(studentId);
  } catch(e) {
    renderFallback(studentId);
  }
}

function render({ student: s, logs, monthly }) {
  const pct   = parseFloat(s.attendance_pct) || 0;
  const ok    = pct >= 75;

  const html = `
    <!-- Profile -->
    <div class="profile-card">
      <div class="pc-grid">
        <div class="pc-av-wrap">
          <div class="pc-av">${initials(s.student_name)}</div>
          ${s.internship_status === 'active' ? '<div class="pc-online"></div>' : ''}
        </div>
        <div class="pc-body">
          <div class="pc-name">${esc(s.student_name)}</div>
          <div class="pc-reg">${esc(s.register_number)}</div>
          <div class="pc-tags">
            <span class="ptag ptag-dept">${esc(s.department)}</span>
            <span class="ptag ptag-course">${esc(s.course)}</span>
            <span class="ptag ptag-year">Year ${s.year}</span>
          </div>
          <div class="pc-contact">
            <span><i class="fa-solid fa-envelope"></i>${esc(s.email || '—')}</span>
            <span><i class="fa-solid fa-phone"></i>${esc(s.phone || '—')}</span>
          </div>
        </div>
        <div class="pc-right">
          <div class="big-pct${ok ? '' : ' big-pct-warn'}">${pct}%</div>
          <div class="pct-lbl">Attendance Rate</div>
          <div class="elig-badge ${ok ? 'elig-ok' : 'elig-warn'}">
            <i class="fa-solid ${ok ? 'fa-circle-check' : 'fa-triangle-exclamation'}"></i>
            ${ok ? 'Good Standing' : 'Attendance Low'}
          </div>
        </div>
      </div>
    </div>

    <!-- Internship Info Grid -->
    <div class="info-grid">
      ${infoBlock('fa-building','Company',s.company_name,s.company_city ? s.company_city+', '+s.company_address?.split(',').pop() : '')}
      ${infoBlock('fa-briefcase','Domain / Role',s.domain || '—',s.role_title || '')}
      ${infoBlock('fa-calendar-range','Duration',fmtDate(s.start_date)+' → '+fmtDate(s.end_date), daysLeft(s.end_date))}
      ${infoBlock('fa-location-dot','Location',s.current_location || '—', modeChip(s.work_mode))}
      ${infoBlock('fa-chalkboard-user','Faculty Guide',s.faculty_guide || '—','')}
      ${infoBlock('fa-user-tie','Industry Mentor',s.industry_mentor_name || '—', s.industry_mentor_phone ? '<i class="fa-solid fa-phone" style="font-size:.7rem"></i> '+s.industry_mentor_phone : '')}
      ${infoBlock('fa-headset','Company HR',s.hr_name || '—', s.hr_email || '')}
      ${infoBlock('fa-globe','Industry Sector',s.industry_sector || '—', s.company_website ? `<a href="${s.company_website}" target="_blank" style="color:var(--g600);font-size:.72rem">Visit site</a>` : '')}
    </div>

    <!-- Stat Boxes -->
    <div class="stat-boxes">
      <div class="sbox sbox-b"><div class="sbox-ico" style="color:#3b82f6"><i class="fa-solid fa-calendar-days"></i></div><div class="sn">${s.logged_days || 0}</div><div class="sl">Logged Days</div></div>
      <div class="sbox sbox-g"><div class="sbox-ico" style="color:var(--g600)"><i class="fa-solid fa-circle-check"></i></div><div class="sn">${s.present_days || 0}</div><div class="sl">Present</div></div>
      <div class="sbox sbox-r"><div class="sbox-ico" style="color:#dc2626"><i class="fa-solid fa-circle-xmark"></i></div><div class="sn">${s.absent_days || 0}</div><div class="sl">Absent</div></div>
      <div class="sbox sbox-a"><div class="sbox-ico" style="color:#d97706"><i class="fa-solid fa-chart-pie"></i></div><div class="sn">${pct}%</div><div class="sl">Rate</div></div>
    </div>

    <!-- Charts -->
    <div class="charts2">
      <div class="secc">
        <div class="sech"><div class="sect"><i class="fa-solid fa-chart-pie"></i>Overview</div></div>
        <div class="secb" style="display:flex;justify-content:center;"><canvas id="donutChart" style="max-height:220px;"></canvas></div>
      </div>
      <div class="secc">
        <div class="sech"><div class="sect"><i class="fa-solid fa-chart-line"></i>Monthly Trend</div></div>
        <div class="secb"><canvas id="lineChart"></canvas></div>
      </div>
    </div>

    <!-- Progress Bar Section -->
    <div class="secc" style="margin-bottom:20px;">
      <div class="sech"><div class="sect"><i class="fa-solid fa-hourglass-half"></i>Internship Progress</div>
        <span style="font-size:.75rem;color:var(--tmuted);">${fmtDate(s.start_date)} → ${fmtDate(s.end_date)}</span>
      </div>
      <div class="secb">
        ${progressBar(s.start_date, s.end_date)}
      </div>
    </div>

    <!-- Monthly Summary -->
    <div class="secc">
      <div class="sech"><div class="sect"><i class="fa-solid fa-calendar-check"></i>Monthly Summary</div></div>
      <div class="secb"><div class="mgrid" id="mgrid"></div></div>
    </div>

    <!-- Daily Attendance Log -->
    <div class="secc">
      <div class="sech">
        <div class="sect"><i class="fa-solid fa-clock-rotate-left"></i>Daily Internship Log</div>
        <span style="font-size:.75rem;color:var(--tmuted);">Recent 60 days</span>
      </div>
      <div class="secb-0">
        <table class="rtbl">
          <thead>
            <tr>
              <th>Date</th>
              <th>Check In</th>
              <th>Check Out</th>
              <th>Hours</th>
              <th>GPS</th>
              <th>Status</th>
              <th>Work Summary</th>
            </tr>
          </thead>
          <tbody id="logBody"></tbody>
        </table>
      </div>
    </div>

    <div style="text-align:center;margin-top:28px;font-size:.75rem;color:var(--tmuted);">
      <i class="fa-solid fa-circle-info" style="margin-right:5px;color:var(--g600);"></i>
      Report generated by InternTrack Portal · ${new Date().toLocaleString('en-IN')}
    </div>
  `;

  document.getElementById('reportContent').innerHTML = html;

  // Build charts & tables
  buildDonut(parseInt(s.present_days)||0, parseInt(s.absent_days)||0);
  buildLine(monthly || []);
  buildMonthlyCards(monthly || []);
  buildLogTable(logs || []);
}

// ── Chart builders ────────────────────────────────────────────
function buildDonut(p, a) {
  const ctx = document.getElementById('donutChart')?.getContext('2d');
  if (!ctx) return;
  if (charts.donut) charts.donut.destroy();
  charts.donut = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Present', 'Absent'],
      datasets: [{ data: [p, a],
        backgroundColor: ['rgba(22,163,74,.8)', 'rgba(239,68,68,.65)'],
        borderColor: ['#16a34a', '#ef4444'], borderWidth: 2, hoverOffset: 5 }]
    },
    options: {
      responsive: true, cutout: '68%',
      plugins: { legend: { position: 'bottom', labels: { padding: 16, font: { size:11, weight:'600' } } } }
    }
  });
}

function buildLine(data) {
  const ctx = document.getElementById('lineChart')?.getContext('2d');
  if (!ctx || !data.length) return;
  if (charts.line) charts.line.destroy();
  charts.line = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: data.map(d => d.month_label),
      datasets: [
        { label: 'Present', data: data.map(d => d.present), backgroundColor: 'rgba(22,163,74,.75)', borderColor: '#16a34a', borderWidth: 1.5, borderRadius: 6 },
        { label: 'Absent',  data: data.map(d => d.total - d.present), backgroundColor: 'rgba(239,68,68,.55)', borderColor: '#ef4444', borderWidth: 1.5, borderRadius: 6 }
      ]
    },
    options: {
      responsive: true,
      plugins: { legend: { position:'top', labels: { font:{size:11,weight:'600'}, padding:14 } } },
      scales: {
        x: { stacked: true, grid: { color: 'rgba(0,0,0,.04)' } },
        y: { stacked: true, beginAtZero: true, grid: { color: 'rgba(0,0,0,.04)' } }
      }
    }
  });
}

function buildMonthlyCards(data) {
  if (!data.length) {
    document.getElementById('mgrid').innerHTML = '<p style="color:var(--tmuted);font-size:.85rem;">No monthly data yet.</p>';
    return;
  }
  document.getElementById('mgrid').innerHTML = data.map(m => {
    const col = parseFloat(m.pct) >= 75 ? 'var(--g700)' : '#dc2626';
    return `<div class="mc"><div class="ml">${m.month_label}</div><div class="mp" style="color:${col}">${m.pct}%</div><div class="mm">${m.present}P / ${m.total - m.present}A</div></div>`;
  }).join('');
}

function buildLogTable(logs) {
  if (!logs.length) {
    document.getElementById('logBody').innerHTML = `<tr><td colspan="7" style="text-align:center;padding:28px;color:var(--tmuted);">No attendance logs found.</td></tr>`;
    return;
  }
  document.getElementById('logBody').innerHTML = logs.map(l => {
    const hours = calcHours(l.checkin_time, l.checkout_time);
    const statusMap = { present:'Present', absent:'Absent', half_day:'Half Day', holiday:'Holiday', leave:'Leave' };
    const chipMap   = { present:'cp', absent:'ca', half_day:'ch', holiday:'cl', leave:'cl' };
    return `<tr>
      <td class="mono">${fmtDate(l.log_date)}</td>
      <td class="mono">${l.checkin_time  ? l.checkin_time.substring(0,5)  : '—'}</td>
      <td class="mono">${l.checkout_time ? l.checkout_time.substring(0,5) : '—'}</td>
      <td style="font-weight:600;color:var(--t700);">${hours}</td>
      <td><span class="${l.location_verified ? 'loc-dot loc-ok' : 'loc-dot loc-no'}">
        <i class="fa-solid fa-location-dot"></i>${l.location_verified ? 'Verified' : 'N/A'}
      </span></td>
      <td><span class="chip ${chipMap[l.status] || 'ca'}">${statusMap[l.status] || l.status}</span></td>
      <td style="max-width:260px;font-size:.78rem;color:var(--tmuted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(l.work_summary || '—')}</td>
    </tr>`;
  }).join('');
}

// ── Helpers ───────────────────────────────────────────────────
function infoBlock(icon, label, value, sub) {
  return `<div class="info-block">
    <div class="ib-label">${label}</div>
    <div class="ib-val"><i class="fa-solid ${icon}"></i>${esc(String(value))}</div>
    ${sub ? `<div class="ib-sub">${sub}</div>` : ''}
  </div>`;
}

function modeChip(mode) {
  if (!mode) return '';
  const cls = { onsite:'wm-onsite', remote:'wm-remote', hybrid:'wm-hybrid' }[mode] || 'wm-onsite';
  return `<span class="work-mode-badge ${cls}">${mode.charAt(0).toUpperCase()+mode.slice(1)}</span>`;
}

function progressBar(start, end) {
  const s = new Date(start), e = new Date(end), n = new Date();
  const total = e - s;
  const done  = Math.min(n - s, total);
  const pct   = Math.max(0, Math.min(100, Math.round(done / total * 100)));
  const daysTotal = Math.round(total / 86400000);
  const daysDone  = Math.max(0, Math.round(done  / 86400000));

  return `<div style="margin-bottom:10px;display:flex;justify-content:space-between;font-size:.8rem;font-weight:700;color:var(--tmuted);">
    <span>${daysDone} days completed</span><span>${pct}% done</span>
  </div>
  <div class="prog-bar" style="height:12px;">
    <div class="prog-fill pf-g" style="width:${pct}%"></div>
  </div>
  <div style="margin-top:8px;font-size:.75rem;color:var(--tmuted);">Total duration: ${daysTotal} days</div>`;
}

function daysLeft(end) {
  const diff = Math.ceil((new Date(end) - new Date()) / 86400000);
  if (diff < 0) return 'Completed';
  return diff + ' days remaining';
}

function calcHours(ci, co) {
  if (!ci || !co) return '—';
  const a = ci.split(':').map(Number), b = co.split(':').map(Number);
  const diff = (b[0]*60+b[1]) - (a[0]*60+a[1]);
  if (diff < 0) return '—';
  return `${Math.floor(diff/60)}h ${diff%60}m`;
}

function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});
}

function initials(n) {
  return String(n).split(' ').slice(0,2).map(w=>w[0]).join('').toUpperCase();
}

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function showError(msg) {
  document.getElementById('reportContent').innerHTML = `
    <div style="text-align:center;padding:80px 20px;color:var(--tmuted);">
      <div style="font-size:3rem;opacity:.2;margin-bottom:16px;"><i class="fa-solid fa-user-slash"></i></div>
      <div style="font-size:1rem;font-weight:600;">${msg}</div>
      <a href="home2.php" style="display:inline-flex;align-items:center;gap:7px;margin-top:20px;padding:10px 22px;background:var(--card-alt);border:1.5px solid var(--border-md);border-radius:10px;color:var(--g700);font-weight:700;text-decoration:none;font-size:.85rem;">
        <i class="fa-solid fa-arrow-left"></i>Back to Dashboard
      </a>
    </div>`;
}

// ── Fallback demo render ──────────────────────────────────────
function renderFallback(id) {
  const STUDENTS = {
    1:{student_name:'Aarav Krishnan',register_number:'23CSE001',department:'Computer Science & Engineering',course:'B.E. Computer Science',year:3,email:'aarav@student.kec.edu',phone:'9500001001',company_name:'Zoho Corporation',company_city:'Chennai',company_address:'Estancia IT Park, Chennai',domain:'Full-Stack Development',role_title:'Software Intern',start_date:'2025-05-01',end_date:'2025-07-31',current_location:'Chennai',work_mode:'onsite',faculty_guide:'Dr. Anitha Rajendran',industry_mentor_name:'Mr. Aravind Prasad',industry_mentor_phone:'9800009999',hr_name:'Deepa R.',hr_email:'deepa.hr@zoho.com',company_website:'https://zoho.com',industry_sector:'SaaS / Product',internship_status:'active',attendance_pct:92.3,present_days:18,absent_days:2,logged_days:20},
    2:{student_name:'Meera Sundar',register_number:'23CSE002',department:'Computer Science & Engineering',course:'B.E. Computer Science',year:3,email:'meera@student.kec.edu',phone:'9500001002',company_name:'TCS',company_city:'Chennai',domain:'Data Science',role_title:'Data Analyst Intern',start_date:'2025-05-01',end_date:'2025-07-31',current_location:'Chennai',work_mode:'hybrid',faculty_guide:'Dr. Anitha Rajendran',industry_mentor_name:'Ms. Kavitha Nair',hr_name:'Priya Sharma',hr_email:'priya.hr@tcs.com',industry_sector:'IT Services',internship_status:'active',attendance_pct:68.0,present_days:12,absent_days:6,logged_days:18},
  };

  const sampleLogs = [
    {log_date:'2025-05-29',checkin_time:'09:12:00',checkout_time:'18:05:00',location_verified:1,status:'present',work_summary:'Sprint review and planning meeting'},
    {log_date:'2025-05-28',checkin_time:'09:08:00',checkout_time:'18:10:00',location_verified:1,status:'present',work_summary:'Feature implementation for dashboard module'},
    {log_date:'2025-05-27',checkin_time:'09:20:00',checkout_time:'18:00:00',location_verified:1,status:'present',work_summary:'Code review and documentation'},
    {log_date:'2025-05-26',checkin_time:'09:05:00',checkout_time:'17:55:00',location_verified:1,status:'present',work_summary:'Bug fixes and testing'},
    {log_date:'2025-05-23',checkin_time:null,checkout_time:null,location_verified:0,status:'absent',work_summary:null},
    {log_date:'2025-05-22',checkin_time:'09:15:00',checkout_time:'18:15:00',location_verified:1,status:'present',work_summary:'Client demo preparation'},
    {log_date:'2025-05-21',checkin_time:'09:25:00',checkout_time:'18:10:00',location_verified:1,status:'present',work_summary:'Integration testing'},
    {log_date:'2025-05-20',checkin_time:'09:10:00',checkout_time:'18:08:00',location_verified:1,status:'present',work_summary:'API documentation update'},
    {log_date:'2025-05-19',checkin_time:'09:05:00',checkout_time:'18:00:00',location_verified:1,status:'present',work_summary:'Performance optimization'},
    {log_date:'2025-05-16',checkin_time:null,checkout_time:null,location_verified:0,status:'absent',work_summary:null},
  ];

  const sampleMonthly = [
    {month_label:'Mar 2025',present:18,total:21,pct:85.7},
    {month_label:'Apr 2025',present:20,total:23,pct:87.0},
    {month_label:'May 2025',present:18,total:20,pct:90.0},
  ];

  const s = STUDENTS[id] || STUDENTS[1];
  render({ student: s, logs: sampleLogs, monthly: sampleMonthly });
}
</script>
</body>
</html>