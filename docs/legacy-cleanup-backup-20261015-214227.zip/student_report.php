<?php
// student_report.php — Dynamic Student Report Page
$studentId = (int)($_GET['id'] ?? 0);
if ($studentId <= 0) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Attendance Report — AttendIQ</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root {
  --g900: #052e16; --g800: #14532d; --g700: #15803d; --g600: #16a34a;
  --g500: #22c55e; --g400: #4ade80; --g300: #86efac; --g200: #bbf7d0;
  --g100: #dcfce7; --g50: #f0fdf4;
  --dark: #0a1628; --surface: #0f2213; --card: #122918;
  --border: rgba(34,197,94,0.18);
  --text-primary: #f0fdf4; --text-secondary: #86efac; --text-muted: #4ade80;
  --shadow-green: 0 0 40px rgba(34,197,94,0.12);
  --radius: 16px;
  --danger: #ef4444; --danger-light: rgba(239,68,68,0.15);
  --warning: #f59e0b; --warning-light: rgba(245,158,11,0.15);
}
* { margin:0; padding:0; box-sizing:border-box; }

body {
  font-family:'Plus Jakarta Sans',sans-serif;
  background:var(--dark); color:var(--text-primary); min-height:100vh;
  background-image:
    radial-gradient(ellipse 80% 50% at 50% -10%, rgba(21,128,61,0.2) 0%, transparent 60%);
}

/* ── NAV ── */
.navbar-custom {
  background:rgba(9,18,13,0.85); backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
  padding:0 2rem; height:68px;
  position:sticky; top:0; z-index:100;
  display:flex; align-items:center; justify-content:space-between;
}
.brand { display:flex; align-items:center; gap:12px; font-weight:800; font-size:1.2rem; color:var(--text-primary); text-decoration:none; }
.brand-icon { width:38px; height:38px; background:linear-gradient(135deg,var(--g600),var(--g400)); border-radius:9px; display:flex; align-items:center; justify-content:center; font-size:16px; }
.brand span { color:var(--g400); }
.btn-back { display:flex; align-items:center; gap:8px; color:var(--text-muted); text-decoration:none; font-size:.875rem; font-weight:600; padding:8px 16px; border-radius:10px; border:1px solid var(--border); transition:.2s; }
.btn-back:hover { color:var(--g400); border-color:rgba(34,197,94,0.4); }

/* ── PAGE WRAPPER ── */
.page-wrap { max-width:1100px; margin:0 auto; padding:36px 16px 80px; }

/* ── PROFILE HEADER ── */
.profile-header {
  background:var(--card); border:1px solid var(--border);
  border-radius:24px; padding:32px; margin-bottom:24px;
  box-shadow:var(--shadow-green); position:relative; overflow:hidden;
}
.profile-header::before {
  content:''; position:absolute; top:0; left:0; right:0; height:4px;
  background:linear-gradient(90deg,var(--g800),var(--g500),var(--g400));
}
.profile-grid { display:flex; gap:28px; align-items:flex-start; flex-wrap:wrap; }

.profile-avatar-wrap { position:relative; flex-shrink:0; }
.profile-avatar {
  width:96px; height:96px; border-radius:20px; overflow:hidden;
  border:3px solid rgba(34,197,94,0.35);
  background:linear-gradient(135deg,var(--g800),var(--g600));
  display:flex; align-items:center; justify-content:center;
  font-size:2.2rem; font-weight:800; color:#fff;
}
.profile-avatar img { width:100%; height:100%; object-fit:cover; }
.online-dot {
  position:absolute; bottom:4px; right:4px;
  width:14px; height:14px; background:var(--g500); border-radius:50%;
  border:2px solid var(--card);
}

.profile-info { flex:1; min-width:200px; }
.profile-name { font-size:1.7rem; font-weight:800; line-height:1.2; margin-bottom:4px; }
.profile-reg { font-family:'JetBrains Mono',monospace; color:var(--g400); font-size:.9rem; margin-bottom:12px; }
.profile-tags { display:flex; gap:8px; flex-wrap:wrap; }
.ptag {
  background:rgba(34,197,94,0.1); border:1px solid rgba(34,197,94,0.2);
  color:var(--g300); padding:4px 12px; border-radius:100px;
  font-size:.75rem; font-weight:600;
}

.profile-right { margin-left:auto; text-align:right; }
.big-pct {
  font-size:3.5rem; font-weight:800; line-height:1;
  background:linear-gradient(135deg,var(--g400),var(--g500));
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
}
.big-pct-warning { background:linear-gradient(135deg,var(--danger),#fca5a5) !important; }
.pct-label { font-size:.8rem; color:var(--text-muted); font-weight:600; letter-spacing:.06em; text-transform:uppercase; margin-top:4px; }

.eligibility-badge {
  display:inline-flex; align-items:center; gap:6px;
  padding:6px 16px; border-radius:100px; font-size:.8rem; font-weight:700;
  margin-top:8px;
}
.elig-yes { background:rgba(34,197,94,0.15); color:var(--g400); border:1px solid rgba(34,197,94,0.3); }
.elig-no  { background:rgba(239,68,68,0.15); color:#fca5a5; border:1px solid rgba(239,68,68,0.3); }

/* ── ACTION BUTTONS ── */
.action-bar { display:flex; gap:12px; margin-bottom:24px; flex-wrap:wrap; }
.btn-action {
  display:flex; align-items:center; gap:8px;
  padding:10px 22px; border-radius:12px; font-weight:600; font-size:.875rem;
  cursor:pointer; transition:.2s; text-decoration:none; border:none;
}
.btn-print { background:rgba(34,197,94,0.12); color:var(--g400); border:1px solid rgba(34,197,94,0.25); }
.btn-print:hover { background:rgba(34,197,94,0.2); color:var(--g300); }
.btn-pdf { background:linear-gradient(135deg,var(--g700),var(--g500)); color:#fff; }
.btn-pdf:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(34,197,94,.35); }

/* ── STAT BOXES ── */
.stat-boxes { display:grid; grid-template-columns:repeat(auto-fill,minmax(160px,1fr)); gap:16px; margin-bottom:24px; }
.stat-box {
  background:var(--card); border:1px solid var(--border);
  border-radius:var(--radius); padding:20px; text-align:center;
}
.stat-box-icon { font-size:1.4rem; margin-bottom:10px; }
.stat-box-num { font-size:1.8rem; font-weight:800; line-height:1; }
.stat-box-lbl { font-size:.72rem; color:var(--text-muted); font-weight:600; letter-spacing:.06em; text-transform:uppercase; margin-top:4px; }
.box-green { border-top:3px solid var(--g500); }
.box-green .stat-box-num { color:var(--g400); }
.box-red   { border-top:3px solid var(--danger); }
.box-red .stat-box-num   { color:#fca5a5; }
.box-blue  { border-top:3px solid #60a5fa; }
.box-blue .stat-box-num  { color:#93c5fd; }
.box-amber { border-top:3px solid var(--warning); }
.box-amber .stat-box-num { color:#fcd34d; }

/* ── SECTION CARD ── */
.sec-card {
  background:var(--card); border:1px solid var(--border);
  border-radius:var(--radius); margin-bottom:24px;
  box-shadow:var(--shadow-green); overflow:hidden;
}
.sec-header {
  padding:18px 24px; border-bottom:1px solid var(--border);
  display:flex; align-items:center; justify-content:space-between;
}
.sec-title { font-weight:700; font-size:1rem; display:flex; align-items:center; gap:10px; }
.sec-title i { color:var(--g500); }
.sec-body { padding:24px; }

/* ── SUBJECT TABLE ── */
.subject-table { width:100%; border-collapse:collapse; }
.subject-table th { font-size:.75rem; font-weight:700; letter-spacing:.06em; text-transform:uppercase; color:var(--text-muted); padding:10px 12px; border-bottom:1px solid var(--border); text-align:left; }
.subject-table td { padding:13px 12px; border-bottom:1px solid rgba(34,197,94,0.07); font-size:.9rem; }
.subject-table tr:last-child td { border-bottom:none; }
.subject-table tr:hover td { background:rgba(34,197,94,0.04); }

.code-cell { font-family:'JetBrains Mono',monospace; font-size:.8rem; color:var(--g400); }

.progress-wrap { min-width:130px; }
.prog-bar {
  height:6px; border-radius:100px;
  background:rgba(34,197,94,0.1); overflow:hidden;
}
.prog-fill { height:100%; border-radius:100px; transition:width 1s ease; }
.fill-green { background:linear-gradient(90deg,var(--g600),var(--g400)); }
.fill-red   { background:linear-gradient(90deg,#dc2626,#f87171); }
.prog-pct   { font-size:.78rem; font-weight:700; margin-top:4px; }

.badge-elig { padding:3px 10px; border-radius:100px; font-size:.72rem; font-weight:700; white-space:nowrap; }
.be-yes { background:rgba(34,197,94,0.15); color:var(--g400); }
.be-no  { background:rgba(239,68,68,0.15); color:#fca5a5; }

/* ── CHART AREAS ── */
.chart-container { position:relative; }
.chart-container canvas { max-height:300px; }

/* ── MONTHLY TABLE ── */
.month-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(160px,1fr)); gap:12px; }
.month-card {
  background:rgba(34,197,94,0.05); border:1px solid var(--border);
  border-radius:12px; padding:16px; text-align:center;
}
.month-label { font-size:.8rem; font-weight:600; color:var(--text-muted); margin-bottom:8px; }
.month-pct   { font-size:1.5rem; font-weight:800; }
.month-meta  { font-size:.75rem; color:var(--text-secondary); margin-top:4px; }

/* ── RECENT TABLE ── */
.recent-table { width:100%; border-collapse:collapse; font-size:.875rem; }
.recent-table th { font-size:.72rem; font-weight:700; letter-spacing:.05em; text-transform:uppercase; color:var(--text-muted); padding:9px 12px; border-bottom:1px solid var(--border); }
.recent-table td { padding:10px 12px; border-bottom:1px solid rgba(34,197,94,0.06); }
.recent-table tr:last-child td { border-bottom:none; }
.status-chip {
  padding:3px 12px; border-radius:100px; font-size:.72rem; font-weight:700; letter-spacing:.04em;
}
.chip-present { background:rgba(34,197,94,0.15); color:var(--g400); }
.chip-absent  { background:rgba(239,68,68,0.12); color:#fca5a5; }

/* ── LOADING SKELETON ── */
.skel { background:linear-gradient(90deg,rgba(34,197,94,0.06),rgba(34,197,94,0.12),rgba(34,197,94,0.06)); background-size:300% 100%; animation:skel-shine 1.8s infinite; border-radius:8px; }
@keyframes skel-shine { 0%{background-position:100% 0} 100%{background-position:-100% 0} }

/* ── PRINT ── */
@media print {
  .navbar-custom,.action-bar,.btn-back { display:none !important; }
  body { background:#fff; color:#000; }
  .sec-card,.profile-header { background:#fff; border-color:#ccc; box-shadow:none; }
  :root { --text-primary:#000; --text-muted:#555; --text-secondary:#333; --border:#ccc; }
  .profile-name { color:#000; }
  .big-pct,-webkit-text-fill-color:transparent { -webkit-text-fill-color:#15803d !important; }
}
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar-custom">
  <a href="index.php" class="brand">
    <div class="brand-icon"><i class="fa-solid fa-graduation-cap"></i></div>
    Attend<span>IQ</span>
  </a>
  <a href="index.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> Back to Students</a>
</nav>

<div class="page-wrap" id="pageWrap">
  <!-- Loading skeleton -->
  <div id="loadingState" style="padding:40px 0;">
    <div class="skel" style="height:200px;margin-bottom:24px;border-radius:24px;"></div>
    <div class="row g-3 mb-4">
      <div class="col-3"><div class="skel" style="height:100px;border-radius:16px;"></div></div>
      <div class="col-3"><div class="skel" style="height:100px;border-radius:16px;"></div></div>
      <div class="col-3"><div class="skel" style="height:100px;border-radius:16px;"></div></div>
      <div class="col-3"><div class="skel" style="height:100px;border-radius:16px;"></div></div>
    </div>
    <div class="skel" style="height:300px;border-radius:16px;margin-bottom:24px;"></div>
  </div>

  <!-- Real content (hidden until loaded) -->
  <div id="reportContent" style="display:none;">

    <!-- Profile Header -->
    <div class="profile-header" id="profileHeader">
      <div class="profile-grid">
        <div class="profile-avatar-wrap">
          <div class="profile-avatar" id="profileAvatar"></div>
          <div class="online-dot"></div>
        </div>
        <div class="profile-info">
          <div class="profile-name" id="profileName">—</div>
          <div class="profile-reg" id="profileReg">—</div>
          <div class="profile-tags" id="profileTags"></div>
          <div style="margin-top:12px;font-size:.85rem;color:var(--text-secondary);">
            <i class="fa-solid fa-envelope me-2"></i><span id="profileEmail">—</span>
            &nbsp;&nbsp;
            <i class="fa-solid fa-phone me-2"></i><span id="profilePhone">—</span>
          </div>
        </div>
        <div class="profile-right">
          <div class="big-pct" id="bigPct">0%</div>
          <div class="pct-label">Overall Attendance</div>
          <div id="eligBadge" class="eligibility-badge elig-yes mt-2">
            <i class="fa-solid fa-circle-check"></i><span>Eligible</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Action Bar -->
    <div class="action-bar">
      <button class="btn-action btn-print" onclick="window.print()">
        <i class="fa-solid fa-print"></i> Print Report
      </button>
      <button class="btn-action btn-pdf" onclick="downloadPDF()">
        <i class="fa-solid fa-file-pdf"></i> Download PDF
      </button>
    </div>

    <!-- Stat Boxes -->
    <div class="stat-boxes" id="statBoxes"></div>

    <!-- Row: Donut + Bar Chart -->
    <div class="row g-4 mb-4">
      <div class="col-md-4">
        <div class="sec-card h-100">
          <div class="sec-header">
            <div class="sec-title"><i class="fa-solid fa-chart-pie"></i>Attendance Overview</div>
          </div>
          <div class="sec-body">
            <div class="chart-container"><canvas id="donutChart"></canvas></div>
          </div>
        </div>
      </div>
      <div class="col-md-8">
        <div class="sec-card h-100">
          <div class="sec-header">
            <div class="sec-title"><i class="fa-solid fa-chart-bar"></i>Subject-wise Attendance</div>
          </div>
          <div class="sec-body">
            <div class="chart-container"><canvas id="subjectBar"></canvas></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Subject Table -->
    <div class="sec-card">
      <div class="sec-header">
        <div class="sec-title"><i class="fa-solid fa-table"></i>Subject-wise Breakdown</div>
        <span style="font-size:.8rem;color:var(--text-muted);" id="subjectCount"></span>
      </div>
      <div class="sec-body" style="padding:0;">
        <div style="overflow-x:auto;">
          <table class="subject-table" id="subjectTable">
            <thead>
              <tr>
                <th>#</th><th>Code</th><th>Subject</th>
                <th>Present</th><th>Absent</th><th>Total</th>
                <th>Progress</th><th>Status</th>
              </tr>
            </thead>
            <tbody id="subjectTbody"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Monthly Chart -->
    <div class="sec-card">
      <div class="sec-header">
        <div class="sec-title"><i class="fa-solid fa-calendar-days"></i>Monthly Attendance Trend</div>
      </div>
      <div class="sec-body">
        <div class="chart-container"><canvas id="monthlyLine" style="max-height:260px;"></canvas></div>
      </div>
    </div>

    <!-- Monthly Cards -->
    <div class="sec-card">
      <div class="sec-header">
        <div class="sec-title"><i class="fa-solid fa-grid-2"></i>Monthly Summary</div>
      </div>
      <div class="sec-body">
        <div class="month-grid" id="monthGrid"></div>
      </div>
    </div>

    <!-- Recent Attendance Log -->
    <div class="sec-card">
      <div class="sec-header">
        <div class="sec-title"><i class="fa-solid fa-clock-rotate-left"></i>Recent Attendance Log</div>
        <span style="font-size:.8rem;color:var(--text-muted);">Latest 100 records</span>
      </div>
      <div class="sec-body" style="padding:0;max-height:400px;overflow-y:auto;">
        <table class="recent-table">
          <thead style="position:sticky;top:0;background:var(--card);z-index:1;">
            <tr><th>Date</th><th>Subject</th><th>Code</th><th>Status</th></tr>
          </thead>
          <tbody id="recentTbody"></tbody>
        </table>
      </div>
    </div>

    <!-- Footer note -->
    <div style="text-align:center;margin-top:32px;color:var(--text-muted);font-size:.8rem;">
      <i class="fa-solid fa-circle-info me-1"></i>
      Attendance below 75% in any subject may lead to detention. Contact your faculty advisor for further assistance.
    </div>

  </div><!-- /reportContent -->
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script>
const STUDENT_ID = <?= $studentId ?>;
const API        = 'api/students.php';

Chart.defaults.color = '#86efac';
Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";

let charts = {};

// ── LOAD REPORT ──
async function loadReport() {
  try {
    const res  = await fetch(`${API}?action=report&id=${STUDENT_ID}`);
    const data = await res.json();
    if (!data.success) { showError(data.message || 'Student not found.'); return; }
    render(data);
  } catch(e) {
    showError('Could not load report. Check API connection.');
  }
}

function render(data) {
  const s      = data.student;
  const totals = data.totals;
  const pct    = data.overall_pct;
  const eligible = pct >= 75;

  // ── Profile ──
  const initials = s.student_name.split(' ').slice(0,2).map(w=>w[0]).join('').toUpperCase();
  const avatarEl = document.getElementById('profileAvatar');
  if (s.profile_photo && s.profile_photo !== 'default.png') {
    avatarEl.innerHTML = `<img src="uploads/profiles/${s.profile_photo}" alt="${s.student_name}">`;
  } else {
    avatarEl.textContent = initials;
  }

  document.getElementById('profileName').textContent = s.student_name;
  document.getElementById('profileReg').textContent  = s.register_number;
  document.getElementById('profileEmail').textContent = s.email;
  document.getElementById('profilePhone').textContent = s.phone || '—';
  document.title = `Report — ${s.student_name}`;

  document.getElementById('profileTags').innerHTML = [
    s.department, s.course, `Year ${s.year}`, `Semester ${s.semester}`
  ].map(t => `<span class="ptag">${t}</span>`).join('');

  const bigEl = document.getElementById('bigPct');
  bigEl.textContent = `${pct}%`;
  if (!eligible) bigEl.style.background = 'linear-gradient(135deg,#ef4444,#fca5a5)';

  const eb = document.getElementById('eligBadge');
  if (eligible) {
    eb.className = 'eligibility-badge elig-yes';
    eb.innerHTML = `<i class="fa-solid fa-circle-check"></i><span>Eligible for Exams</span>`;
  } else {
    eb.className = 'eligibility-badge elig-no';
    eb.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i><span>Attendance Warning</span>`;
  }

  // ── Stat Boxes ──
  document.getElementById('statBoxes').innerHTML = `
    <div class="stat-box box-green">
      <div class="stat-box-icon" style="color:var(--g500)"><i class="fa-solid fa-circle-check"></i></div>
      <div class="stat-box-num">${totals.total_present}</div>
      <div class="stat-box-lbl">Total Present</div>
    </div>
    <div class="stat-box box-red">
      <div class="stat-box-icon" style="color:#f87171"><i class="fa-solid fa-circle-xmark"></i></div>
      <div class="stat-box-num">${totals.total_absent}</div>
      <div class="stat-box-lbl">Total Absent</div>
    </div>
    <div class="stat-box box-blue">
      <div class="stat-box-icon" style="color:#93c5fd"><i class="fa-solid fa-calendar-days"></i></div>
      <div class="stat-box-num">${totals.total_classes}</div>
      <div class="stat-box-lbl">Total Classes</div>
    </div>
    <div class="stat-box box-amber">
      <div class="stat-box-icon" style="color:#fcd34d"><i class="fa-solid fa-book-open"></i></div>
      <div class="stat-box-num">${data.subjects.length}</div>
      <div class="stat-box-lbl">Subjects</div>
    </div>`;

  // ── Subject Table ──
  document.getElementById('subjectCount').textContent = `${data.subjects.length} subjects`;
  const tbody = document.getElementById('subjectTbody');
  tbody.innerHTML = data.subjects.map((sub, i) => {
    const elig = parseFloat(sub.percentage) >= 75;
    const fillClass = elig ? 'fill-green' : 'fill-red';
    const pctColor  = elig ? 'var(--g400)' : '#fca5a5';
    return `<tr>
      <td style="color:var(--text-muted);">${i+1}</td>
      <td class="code-cell">${sub.subject_code}</td>
      <td style="font-weight:600;">${sub.subject_name}</td>
      <td style="color:var(--g400);font-weight:700;">${sub.total_present}</td>
      <td style="color:#fca5a5;font-weight:700;">${sub.total_absent}</td>
      <td style="color:var(--text-muted);">${sub.total_classes}</td>
      <td class="progress-wrap">
        <div class="prog-bar"><div class="prog-fill ${fillClass}" style="width:${sub.percentage}%"></div></div>
        <div class="prog-pct" style="color:${pctColor}">${sub.percentage}%</div>
      </td>
      <td><span class="badge-elig ${elig?'be-yes':'be-no'}">${elig?'Eligible':'Warning'}</span></td>
    </tr>`;
  }).join('');

  // ── Monthly Cards ──
  const monthGrid = document.getElementById('monthGrid');
  monthGrid.innerHTML = data.monthly.map(m => {
    const elig = parseFloat(m.percentage) >= 75;
    const col  = elig ? 'var(--g400)' : '#fca5a5';
    return `<div class="month-card">
      <div class="month-label">${m.month_label}</div>
      <div class="month-pct" style="color:${col}">${m.percentage}%</div>
      <div class="month-meta">${m.total_present}P / ${parseInt(m.total_classes)-parseInt(m.total_present)}A</div>
    </div>`;
  }).join('') || '<p style="color:var(--text-muted);text-align:center;padding:20px;">No monthly data available</p>';

  // ── Recent Log ──
  const recentTbody = document.getElementById('recentTbody');
  recentTbody.innerHTML = data.daily.map(d => `
    <tr>
      <td style="font-family:'JetBrains Mono',monospace;font-size:.8rem;color:var(--text-secondary);">${formatDate(d.attendance_date)}</td>
      <td style="font-size:.875rem;">${d.subject_name}</td>
      <td class="code-cell" style="font-size:.78rem;">${d.subject_code}</td>
      <td><span class="status-chip ${d.status==='Present'?'chip-present':'chip-absent'}">${d.status}</span></td>
    </tr>`).join('') || '<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-muted);">No attendance records found</td></tr>';

  // ── Charts ──
  buildDonut(totals);
  buildSubjectBar(data.subjects);
  buildMonthlyLine(data.monthly);

  // Show content
  document.getElementById('loadingState').style.display  = 'none';
  document.getElementById('reportContent').style.display = 'block';
}

// ── CHARTS ──
function buildDonut(totals) {
  const ctx = document.getElementById('donutChart').getContext('2d');
  charts.donut = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Present', 'Absent'],
      datasets: [{
        data: [totals.total_present, totals.total_absent],
        backgroundColor: ['rgba(34,197,94,0.8)', 'rgba(239,68,68,0.7)'],
        borderColor:     ['#22c55e','#ef4444'],
        borderWidth: 2, hoverOffset: 6,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      cutout: '70%',
      plugins: {
        legend: { position:'bottom', labels:{ padding:20, font:{size:13,weight:'600'} } },
        tooltip: { callbacks:{ label: c => ` ${c.label}: ${c.raw} classes` } }
      }
    }
  });
}

function buildSubjectBar(subjects) {
  const ctx = document.getElementById('subjectBar').getContext('2d');
  charts.bar = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: subjects.map(s => s.subject_code),
      datasets: [
        { label:'Present', data: subjects.map(s=>s.total_present), backgroundColor:'rgba(34,197,94,0.75)', borderColor:'#22c55e', borderWidth:1.5, borderRadius:6 },
        { label:'Absent',  data: subjects.map(s=>s.total_absent),  backgroundColor:'rgba(239,68,68,0.6)',  borderColor:'#ef4444', borderWidth:1.5, borderRadius:6 },
      ]
    },
    options: {
      responsive:true, maintainAspectRatio:true,
      plugins:{ legend:{ position:'top', labels:{font:{size:12,weight:'600'},padding:16} } },
      scales:{
        x:{ grid:{color:'rgba(34,197,94,0.07)'}, ticks:{font:{size:11}} },
        y:{ beginAtZero:true, grid:{color:'rgba(34,197,94,0.07)'}, ticks:{font:{size:11}} }
      }
    }
  });
}

function buildMonthlyLine(monthly) {
  const ctx = document.getElementById('monthlyLine').getContext('2d');
  charts.line = new Chart(ctx, {
    type: 'line',
    data: {
      labels: monthly.map(m => m.month_label),
      datasets: [{
        label: 'Attendance %',
        data: monthly.map(m => m.percentage),
        borderColor:'#22c55e', backgroundColor:'rgba(34,197,94,0.08)',
        borderWidth:2.5, pointBackgroundColor:'#22c55e', pointRadius:5,
        tension:.35, fill:true,
      }, {
        label: '75% Threshold',
        data: monthly.map(() => 75),
        borderColor:'rgba(239,68,68,0.5)', borderDash:[8,4],
        borderWidth:1.5, pointRadius:0, fill:false,
      }]
    },
    options: {
      responsive:true, maintainAspectRatio:true,
      plugins:{ legend:{position:'top',labels:{font:{size:12,weight:'600'},padding:16}} },
      scales:{
        x:{ grid:{color:'rgba(34,197,94,0.07)'} },
        y:{ min:0, max:100, grid:{color:'rgba(34,197,94,0.07)'}, ticks:{callback:v=>v+'%'} }
      }
    }
  });
}

// ── PDF DOWNLOAD ──
function downloadPDF() {
  const btn = event.target.closest('button');
  const orig = btn.innerHTML;
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Generating…';
  btn.disabled = true;
  setTimeout(() => { window.print(); btn.innerHTML = orig; btn.disabled = false; }, 300);
}

// ── HELPERS ──
function formatDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
}

function showError(msg) {
  document.getElementById('loadingState').innerHTML = `
    <div style="text-align:center;padding:80px 20px;color:var(--text-muted);">
      <i class="fa-solid fa-circle-exclamation" style="font-size:3rem;margin-bottom:16px;display:block;color:#f87171;"></i>
      <p style="font-size:1.1rem;">${msg}</p>
      <a href="index.php" class="btn-back mt-4" style="display:inline-flex;">
        <i class="fa-solid fa-arrow-left"></i> Back to Student List
      </a>
    </div>`;
}

// ── INIT ──
document.addEventListener('DOMContentLoaded', loadReport);
</script>
</body>
</html>