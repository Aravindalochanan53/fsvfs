<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Internship Portal – Kongu Engineering College</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet"/>
  <style>
    :root {
      --blue-900: #041b11;
      --blue-800: #072b18;
      --blue-700: #0b4425;
      --blue-600: #116530;
      --blue-500: #15803d;
      --blue-400: #22c55e;
      --blue-300: #4ade80;
      --blue-100: #dcfce7;
      --blue-50:  #f0fdf4;
      --accent:   #86efac;
      --white:    #ffffff;
      --text-dark: #0b1d13;
      --text-mid:  #36543d;
      --text-muted:#5f7d66;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; }
    html { scroll-behavior: smooth; }

    body {
      font-family: 'DM Sans', sans-serif;
      background: #f0fdf4;
      color: var(--text-dark);
      overflow-x: hidden;
    }

    /* ---- HEADER ---- */
    .site-header {
      background: linear-gradient(135deg, var(--blue-900) 0%, var(--blue-700) 60%, var(--blue-500) 100%);
      padding: 18px 20px 14px;
      text-align: center;
      position: sticky;
      top: 0;
      z-index: 1030;
      box-shadow: 0 4px 24px rgba(10,22,40,0.35);
    }
    .site-header h1 {
      font-family: 'Sora', sans-serif;
      font-weight: 800;
      font-size: 1.9rem;
      letter-spacing: 3px;
      color: #fff;
      text-transform: uppercase;
    }
    .site-header p {
      font-size: 0.85rem;
      color: var(--blue-300);
      margin-top: 2px;
      letter-spacing: 0.5px;
    }
    .header-line {
      width: 60px;
      height: 3px;
      background: var(--accent);
      margin: 8px auto 0;
      border-radius: 2px;
    }

    /* ---- NAVBAR ---- */
   
        .site-nav { background: var(--white); border-bottom: 2px solid var(--blue-100); position: sticky; top: 78px; z-index: 1020; box-shadow: 0 2px 12px rgba(18,81,181,0.08); }
        .site-nav nav { display: flex; justify-content: center; gap: 10px; padding: 10px 16px; flex-wrap: wrap; }
        .site-nav .nav-btn { font-family: 'Sora', sans-serif; font-weight: 600; font-size: 0.82rem; letter-spacing: 0.5px; color: var(--blue-600); border: 2px solid var(--blue-100); background: var(--blue-50); border-radius: 40px; padding: 7px 20px; text-decoration: none; transition: all 0.22s ease; white-space: nowrap; }
        .site-nav .nav-btn:hover, .site-nav .nav-btn.active { background: var(--blue-600); color: #fff; border-color: var(--blue-600); box-shadow: 0 4px 16px rgba(18,81,181,0.3); transform: translateY(-1px); }

    /* ---- CAROUSEL ---- */
    .carousel-section {
      padding: 28px 16px 0;
      max-width: 1200px;
      margin: 0 auto;
    }
    .carousel-wrap {
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 16px 48px rgba(10,22,40,0.18);
      position: relative;
    }
    .carousel-item img {
      width: 100%;
      height: 360px;
      object-fit: cover;
      filter: brightness(0.88);
    }
    .carousel-item::after {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, transparent 40%, rgba(10,22,40,0.55) 100%);
      pointer-events: none;
    }
    .carousel-caption {
      z-index: 10;
      bottom: 28px;
    }
    .carousel-caption h5 {
      font-family: 'Sora', sans-serif;
      font-weight: 700;
      font-size: 1.3rem;
      text-shadow: 0 2px 8px rgba(0,0,0,0.5);
    }
    .carousel-caption p { font-size: 0.9rem; opacity: 0.9; }
    .carousel-indicators [data-bs-target] {
      background-color: var(--accent);
      width: 28px; height: 4px;
      border-radius: 2px;
      opacity: 0.5;
      border: none;
    }
    .carousel-indicators .active { opacity: 1; }

    /* ---- HERO ---- */
    .hero-section {
      max-width: 1200px;
      margin: 52px auto 0;
      padding: 0 20px;
    }
    .hero-text h2 {
      font-family: 'Sora', sans-serif;
      font-weight: 800;
      font-size: 2.5rem;
      line-height: 1.15;
      color: var(--blue-800);
    }
    .hero-text h2 span { color: var(--blue-500); }
    .hero-text p {
      font-size: 1.05rem;
      color: var(--text-mid);
      margin-top: 16px;
      line-height: 1.7;
      max-width: 520px;
    }
    .hero-btn {
      display: inline-block;
      margin-top: 24px;
      background: linear-gradient(135deg, var(--blue-600), var(--blue-400));
      color: #fff;
      font-family: 'Sora', sans-serif;
      font-weight: 700;
      font-size: 0.95rem;
      padding: 14px 36px;
      border-radius: 50px;
      text-decoration: none;
      border: none;
      cursor: pointer;
      box-shadow: 0 8px 24px rgba(21,128,61,0.35);
      transition: all 0.25s;
    }
    .hero-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 12px 32px rgba(21,128,61,0.45);
      color: #fff;
    }
    .hero-img-wrap {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .hero-img-bg {
      width: 310px; height: 310px;
      border-radius: 50%;
      background: linear-gradient(135deg, var(--blue-100), var(--blue-300));
      position: absolute;
    }
    .semi-img {
      width: 290px; height: 290px;
      border-radius: 50%;
      object-fit: cover;
      border: 5px solid #fff;
      box-shadow: 0 20px 48px rgba(10,22,40,0.2);
      position: relative;
      z-index: 2;
      transition: transform 0.3s;
    }
    .semi-img:hover { transform: scale(1.03); }

    /* ---- STATS ---- */
    .stats-section {
      max-width: 1200px;
      margin: 48px auto 0;
      padding: 0 20px;
    }
    .stat-card {
      background: var(--white);
      border-radius: 20px;
      padding: 28px 18px;
      text-align: center;
      box-shadow: 0 4px 20px rgba(21,128,61,0.09);
      border: 1.5px solid var(--blue-100);
      border-top: 4px solid var(--blue-400);
      transition: all 0.25s;
    }
    .stat-card:hover { transform: translateY(-5px); box-shadow: 0 16px 40px rgba(21,128,61,0.15); border-color: var(--blue-300); }
    .stat-card .num {
      font-family: 'Sora', sans-serif;
      font-size: 2.2rem;
      font-weight: 800;
      color: var(--blue-600);
    }
    .stat-card .label {
      font-size: 0.82rem;
      color: var(--text-muted);
      margin-top: 4px;
      font-weight: 600;
    }

    /* ---- FEATURE CARDS ---- */
    .features-section {
      max-width: 1200px;
      margin: 56px auto 0;
      padding: 0 20px;
    }
    .section-title {
      font-family: 'Sora', sans-serif;
      font-weight: 800;
      font-size: 1.9rem;
      color: var(--blue-800);
      text-align: center;
      margin-bottom: 8px;
    }
    .section-sub {
      text-align: center;
      color: var(--text-muted);
      font-size: 1rem;
      margin-bottom: 36px;
    }
    .feat-card {
      background: #fff;
      border-radius: 20px;
      padding: 32px 24px;
      box-shadow: 0 4px 20px rgba(21,128,61,0.07);
      border: 1.5px solid var(--blue-100);
      transition: all 0.25s;
      height: 100%;
      text-align: center;
    }
    .feat-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 16px 40px rgba(21,128,61,0.15);
      border-color: var(--blue-300);
    }
    .feat-icon { font-size: 2.4rem; display: block; margin-bottom: 14px; }
    .feat-card h4 {
      font-family: 'Sora', sans-serif;
      font-weight: 700;
      font-size: 1.1rem;
      color: var(--blue-700);
      margin-bottom: 10px;
    }
    .feat-card p { color: var(--text-muted); font-size: 0.94rem; line-height: 1.6; }

    /* ---- INFO BAND ---- */
    .info-band {
      background: linear-gradient(135deg, var(--blue-800), var(--blue-600));
      margin: 56px 0 0;
      padding: 52px 20px;
      text-align: center;
    }
    .info-band h2 {
      font-family: 'Sora', sans-serif;
      font-weight: 800;
      font-size: 1.8rem;
      color: #fff;
      margin-bottom: 14px;
    }
    .info-band p {
      color: var(--blue-100);
      font-size: 1.02rem;
      max-width: 720px;
      margin: 0 auto;
      line-height: 1.7;
    }

    /* ---- TABLE SECTION ---- */
    .table-section {
      max-width: 1200px;
      margin: 56px auto 0;
      padding: 0 20px;
    }
    .table-wrap-inner {
      background: var(--white);
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 8px 32px rgba(21,128,61,0.09);
      border: 1.5px solid var(--blue-100);
    }
    table { width: 100%; border-collapse: collapse; }
    thead tr { background: var(--blue-800); }
    thead th {
      padding: 16px 20px;
      text-align: left;
      font-family: 'Sora', sans-serif;
      font-size: 0.82rem;
      font-weight: 700;
      color: var(--white);
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }
    tbody tr {
      border-bottom: 1px solid var(--blue-50);
      transition: background 0.2s;
    }
    tbody tr:last-child { border-bottom: none; }
    tbody tr:hover { background: var(--blue-50); }
    tbody td { padding: 14px 20px; font-size: 0.88rem; color: var(--text-dark); }
    tbody td:first-child { font-weight: 600; color: var(--text-muted); width: 60px; }
    .prog-name a {
      color: var(--blue-700);
      text-decoration: none;
      font-weight: 500;
      transition: color 0.2s;
    }
    .prog-name a:hover { color: var(--blue-500); text-decoration: underline; }
    .badge-dur {
      display: inline-block;
      padding: 3px 12px;
      border-radius: 20px;
      font-size: 0.75rem;
      font-weight: 600;
      background: var(--blue-50);
      color: var(--blue-600);
      border: 1px solid var(--blue-100);
    }
    .badge-dur-5 {
      background: #fff7ed;
      color: #92400e;
      border-color: #fed7aa;
    }
    .year-chip {
      display: inline-block;
      padding: 3px 12px;
      border-radius: 20px;
      font-size: 0.78rem;
      font-weight: 600;
      background: var(--blue-800);
      color: var(--blue-300);
    }
    .new-chip {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 6px;
      font-size: 0.65rem;
      font-weight: 700;
      background: var(--blue-400);
      color: #fff;
      margin-left: 8px;
      vertical-align: middle;
    }

    /* ---- OVERVIEW BAND ---- */
    .overview-band {
      background: var(--white);
      border: 1.5px solid var(--blue-100);
      border-radius: 24px;
      max-width: 1100px;
      margin: 56px auto 0;
      padding: 48px 36px;
      text-align: center;
      box-shadow: 0 8px 32px rgba(21,128,61,0.07);
    }
    .overview-band h2 {
      font-family: 'Sora', sans-serif;
      font-weight: 800;
      font-size: 1.8rem;
      color: var(--blue-800);
      margin-bottom: 14px;
    }
    .overview-band p {
      color: var(--text-mid);
      font-size: 1rem;
      line-height: 1.75;
      max-width: 700px;
      margin: 0 auto 24px;
    }
    .badge-pill {
      display: inline-block;
      background: var(--blue-50);
      color: var(--blue-700);
      border: 1.5px solid var(--blue-100);
      border-radius: 40px;
      padding: 8px 20px;
      font-size: 0.87rem;
      font-weight: 600;
      margin: 5px;
      font-family: 'Sora', sans-serif;
    }

    /* ---- FOOTER ---- */
    footer {
      background: var(--blue-900);
      margin-top: 64px;
      padding: 36px 20px;
      text-align: center;
    }
    footer p { color: var(--blue-300); font-size: 0.88rem; margin-bottom: 4px; }
    footer .footer-line {
      width: 50px; height: 2px;
      background: var(--accent);
      margin: 12px auto;
      border-radius: 2px;
    }

    /* ---- RESPONSIVE ---- */
    @media (max-width: 768px) {
      .hero-text h2 { font-size: 1.8rem; }
      .hero-img-bg, .semi-img { width: 230px; height: 230px; }
      .carousel-item img { height: 240px; }
      .section-title { font-size: 1.5rem; }
      thead th:nth-child(3), tbody td:nth-child(3) { display: none; }
    }
    @media (max-width: 480px) {
      .site-header h1 { font-size: 1.4rem; letter-spacing: 2px; }
      .site-nav .nav-btn { font-size: 0.75rem; padding: 6px 14px; }
    }
  </style>
</head>
<body>

<!-- ==================== HEADER ==================== -->
<div class="site-header">
  <h1>✦ INTERNSHIP PORTAL</h1>
  <p>Kongu Engineering College &nbsp;|&nbsp; Industry Ready Portal</p>
  
</div>

<!-- ==================== NAVBAR ==================== -->
<div class="site-nav">
    <nav>
        <a class="nav-btn active" href="home2.php">🏠 HOME</a>
        <a class="nav-btn" href="department.php">📘 DEPARTMENT</a>
        <a class="nav-btn" href="student_selection.php">🎓 STUDENTS</a>
        <a class="nav-btn" href="attendence_preview.php">👁️ ATTENDANCE PREVIEW</a>
        <a class="nav-btn" href="about2.php">ℹ️ ABOUT US</a>
    </nav>
</div>

<!-- ==================== INFO BAND ==================== -->
<div class="info-band">
  <h2>🏛️ Kongu Engineering College</h2>
  <p>Kongu Engineering College is committed to providing quality education and encouraging students to develop technical and professional skills. The institution supports innovation, industry interaction and research activities which help students gain knowledge beyond classroom learning.</p>
</div>

<!-- ==================== PROGRAMMES TABLE ==================== -->
<div class="table-section">
  <h2 class="section-title mt-0">Undergraduate Programmes</h2>
  <p class="section-sub">All programmes approved by AICTE &amp; affiliated to Anna University</p>
  <div class="table-wrap-inner">
    <table>
      <thead>
        <tr>
          <th>S.No</th>
          <th>Name of the Programme</th>
          <th>Duration</th>
    
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td class="prog-name"><a href="B.ECivilEngineering.php">B.E Civil Engineering</a></td>
          <td><span class="badge-dur">4 Years</span></td>
          
        </tr>
        <tr>
          <td>2</td>
          <td class="prog-name"><a href="B.EMechanicalEngineering.php">B.E Mechanical Engineering</a></td>
          <td><span class="badge-dur">4 Years</span></td>
          
        </tr>
        <tr>
          <td>3</td>
          <td class="prog-name"><a href="B.EElectronicsandCommunicationEngineering.php">B.E Electronics and Communication Engineering</a></td>
          <td><span class="badge-dur">4 Years</span></td>
          
        </tr>
        <tr>
  <td>4</td>
  <td class="prog-name">
    <a href="B.EComputerScienceandEngineering.php">
      B.E Computer Science and Engineering
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>5</td>
  <td class="prog-name">
    <a href="B.TechChemicalEngineering.php">
      B.Tech Chemical Engineering
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>6</td>
  <td class="prog-name">
    <a href="B.EElectricalandElectronicsEngineering.php">
      B.E Electrical and Electronics Engineering
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>7</td>
  <td class="prog-name">
    <a href="B.EElectronicsandInstrumentationEngineering.php">
      B.E Electronics and Instrumentation Engineering
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>8</td>
  <td class="prog-name">
    <a href="B.TechInformationTechnology.php">
      B.Tech Information Technology
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>9</td>
  <td class="prog-name">
    <a href="B.EMechatronicsEngineering.php">
      B.E Mechatronics Engineering
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>10</td>
  <td class="prog-name">
    <a href="B.TechFoodTechnology.php">
      B.Tech Food Technology
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>11</td>
  <td class="prog-name">
    <a href="B.EAutomobileEngineering.php">
      B.E Automobile Engineering
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>12</td>
  <td class="prog-name">
    <a href="B.EComputerScienceandDesign.php">
      B.E Computer Science and Design
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>13</td>
  <td class="prog-name">
    <a href="B.TechArtificialIntelligenceandMachineLearning.php">
      B.Tech Artificial Intelligence and Machine Learning
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>14</td>
  <td class="prog-name">
    <a href="B.TechArtificialIntelligenceandDataScience.php">
      B.Tech Artificial Intelligence and Data Science
    </a>
  </td>
  <td><span class="badge-dur">4 Years</span></td>
</tr>

<tr>
  <td>15</td>
  <td class="prog-name">
    <a href="B.Arch.php">
      B.Arch
    </a>
  </td>
  <td><span class="badge-dur badge-dur-5">5 Years</span></td>
</tr>
      </tbody>
    </table>
  </div>
</div>

<!-- ==================== OVERVIEW BAND ==================== -->
<div class="overview-band">
  <h2>📌 System Overview</h2>
  <p>The Internship Consolidated Report Portal provides a structured way to manage internship information for students and faculty. The system reduces manual work and improves accuracy of data. It helps maintain proper documentation of internship activities in a professional format.</p>
  <div>
    <span class="badge-pill">📅 Real-time Tracking</span>
    <span class="badge-pill">📑 Consolidated Reports</span>
    <span class="badge-pill">🔐 Role-based Access</span>
    <span class="badge-pill">🎓 15+ Programmes</span>
    <span class="badge-pill">🌐 500+ Industry Partners</span>
  </div>
</div>

<!-- ==================== FOOTER ==================== -->
<footer>
  <p>© 2025 Kongu Engineering College — Internship Management Portal</p>
  <p>📍 Perundurai, Erode, Tamil Nadu &nbsp;|&nbsp; 📧 internship@kongu.edu</p>
  <div class="footer-line"></div>
  <p>Empowering students with industry-ready internship tracking</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    var carousels = document.querySelectorAll('.carousel');
    carousels.forEach(function (carousel) {
      new bootstrap.Carousel(carousel, { interval: 3800, wrap: true, touch: true });
    });
    const btns = document.querySelectorAll('.nav-btn');
    btns.forEach(btn => {
      btn.addEventListener('mouseenter', () => btn.style.letterSpacing = '0.8px');
      btn.addEventListener('mouseleave', () => btn.style.letterSpacing = '0.5px');
    });
  });
</script>
</body>
</html>