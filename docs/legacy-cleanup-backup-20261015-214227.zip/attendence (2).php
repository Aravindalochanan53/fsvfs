<?php
// ── Suppress ALL PHP warnings/notices so they never pollute JSON output ──
error_reporting(0);
ini_set('display_errors', 0);

session_start();
date_default_timezone_set("Asia/Kolkata");

// ── DB connection ──────────────────────────────────────────────────────────
$conn = new mysqli("localhost", "root", "", "internship");
if ($conn->connect_error) {
    // Only die with JSON if this is an AJAX call
    if (isset($_POST['action'])) {
        header('Content-Type: application/json');
        echo json_encode(["success" => false, "message" => "DB connection failed."]);
        exit;
    }
    die("Connection failed: " . $conn->connect_error);
}

// ── Auto-fix table: add missing columns if they don't exist ───────────────
$existing_cols = [];
$cols_res = $conn->query("SHOW COLUMNS FROM attendance");
if ($cols_res) {
    while ($c = $cols_res->fetch_assoc()) {
        $existing_cols[] = $c['Field'];
    }
}
if (!in_array('in_distance', $existing_cols)) {
    $conn->query("ALTER TABLE attendance ADD COLUMN in_distance DECIMAL(8,2) DEFAULT NULL");
}
if (!in_array('out_distance', $existing_cols)) {
    $conn->query("ALTER TABLE attendance ADD COLUMN out_distance DECIMAL(8,2) DEFAULT NULL");
}
if (!in_array('register_no', $existing_cols)) {
    $conn->query("ALTER TABLE attendance ADD COLUMN register_no VARCHAR(50) DEFAULT NULL");
}

// ══════════════════════════════════════════════════════════════════════════
// AJAX: Check IN
// ══════════════════════════════════════════════════════════════════════════
if (isset($_POST['action']) && $_POST['action'] == 'in') {
    header('Content-Type: application/json');

    $student_id   = $conn->real_escape_string($_POST['student_id'] ?? '');
    $student_name = $conn->real_escape_string($_POST['student_name'] ?? '');
    $register_no  = $conn->real_escape_string($_POST['register_no'] ?? '');
    $lat          = (float)($_POST['lat'] ?? 0);
    $lng          = (float)($_POST['lng'] ?? 0);
    $distance     = (float)($_POST['distance'] ?? 0);
    $today        = date("Y-m-d");
    $time         = date("Y-m-d H:i:s");

    if (empty($student_id)) {
        echo json_encode(["success" => false, "message" => "Session expired. Please login again."]);
        exit;
    }

    // Check if already checked in today (and not yet checked out)
    $check = $conn->query("
        SELECT id FROM attendance
        WHERE student_id = '$student_id'
          AND attendance_date = '$today'
          AND out_time IS NULL
        LIMIT 1
    ");

    if ($check && $check->num_rows == 0) {
        $ins = $conn->query("
            INSERT INTO attendance
                (student_id, student_name, register_no,
                 attendance_date, in_time,
                 in_lat, in_lng, in_distance, status)
            VALUES
                ('$student_id', '$student_name', '$register_no',
                 '$today', '$time',
                 '$lat', '$lng', '$distance', 'Present')
        ");

        if ($ins) {
            echo json_encode([
                "success"  => true,
                "message"  => "Attendance Marked Successfully",
                "in_time"  => date("H:i", strtotime($time))
            ]);
        } else {
            echo json_encode(["success" => false, "message" => "Insert failed: " . $conn->error]);
        }
    } else {
        echo json_encode([
            "success"  => true,
            "message"  => "Already checked in for today",
            "in_time"  => date("H:i", strtotime($time))
        ]);
    }
    exit;
}

// ══════════════════════════════════════════════════════════════════════════
// AJAX: Check OUT
// ══════════════════════════════════════════════════════════════════════════
if (isset($_POST['action']) && $_POST['action'] == 'out') {
    header('Content-Type: application/json');

    $student_id = $conn->real_escape_string($_POST['student_id'] ?? '');
    $lat        = (float)($_POST['lat'] ?? 0);
    $lng        = (float)($_POST['lng'] ?? 0);
    $distance   = (float)($_POST['distance'] ?? 0);
    $today      = date("Y-m-d");
    $out_time   = date("Y-m-d H:i:s");

    if (empty($student_id)) {
        echo json_encode(["success" => false, "message" => "Session expired. Please login again."]);
        exit;
    }

    $get = $conn->query("
        SELECT *
        FROM attendance
        WHERE student_id    = '$student_id'
          AND attendance_date = '$today'
          AND out_time IS NULL
        LIMIT 1
    ");

    if ($get && $get->num_rows > 0) {
        $row    = $get->fetch_assoc();
        $in_ts  = strtotime($row['in_time']);
        $out_ts = strtotime($out_time);
        $hours  = round(($out_ts - $in_ts) / 3600, 2);

        $upd = $conn->query("
            UPDATE attendance
            SET out_time      = '$out_time',
                out_lat       = '$lat',
                out_lng       = '$lng',
                out_distance  = '$distance',
                working_hours = '$hours',
                status        = 'Present'
            WHERE student_id      = '$student_id'
              AND attendance_date  = '$today'
              AND out_time IS NULL
            LIMIT 1
        ");

        if ($upd && $conn->affected_rows > 0) {
            $h = floor($hours);
            $m = round(($hours - $h) * 60);
            echo json_encode([
                "success"       => true,
                "message"       => "Checked Out Successfully",
                "out_time"      => date("H:i", $out_ts),
                "working_hours" => "{$h}h {$m}m"
            ]);
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Checkout failed. You may have already checked out."
            ]);
        }
    } else {
        echo json_encode([
            "success" => false,
            "message" => "No active check-in found for today. Please check in first."
        ]);
    }
    exit;
}

// ══════════════════════════════════════════════════════════════════════════
// Auto-create attendance table if not exists
// ══════════════════════════════════════════════════════════════════════════
$conn->query("
    CREATE TABLE IF NOT EXISTS attendance (
        id              INT AUTO_INCREMENT PRIMARY KEY,
        student_id      VARCHAR(50)    NOT NULL,
        student_name    VARCHAR(150)   NOT NULL,
        register_no     VARCHAR(50)    DEFAULT NULL,
        attendance_date DATE           NOT NULL,
        in_time         DATETIME       DEFAULT NULL,
        out_time        DATETIME       DEFAULT NULL,
        working_hours   DECIMAL(5,2)   DEFAULT NULL,
        in_lat          DECIMAL(10,7)  DEFAULT NULL,
        in_lng          DECIMAL(10,7)  DEFAULT NULL,
        in_distance     DECIMAL(8,2)   DEFAULT NULL,
        out_lat         DECIMAL(10,7)  DEFAULT NULL,
        out_lng         DECIMAL(10,7)  DEFAULT NULL,
        out_distance    DECIMAL(8,2)   DEFAULT NULL,
        status          ENUM('Present','Absent') DEFAULT 'Absent',
        created_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP
    )
");

// ══════════════════════════════════════════════════════════════════════════
// Session / Page data
// ══════════════════════════════════════════════════════════════════════════
// Safely read session — redirect to login if missing
if (empty($_SESSION['student_id'])) {
    header("Location: index.php");
    exit;
}

$student_id   = $_SESSION['student_id'];
$student_name = $_SESSION['student_name']  ?? 'Student';
$register_no  = $_SESSION['register_no']   ?? '';

// Company location
$company_lat = 0;
$company_lng = 0;
$sid_esc = $conn->real_escape_string($student_id);
$getLoc  = $conn->query("SELECT company_location FROM student_signup WHERE id='$sid_esc' LIMIT 1");
if ($getLoc && $getLoc->num_rows > 0) {
    $locRow = $getLoc->fetch_assoc();
    if (!empty($locRow['company_location'])) {
        $coords      = explode(',', $locRow['company_location']);
        $company_lat = (float)trim($coords[0] ?? 0);
        $company_lng = (float)trim($coords[1] ?? 0);
    }
}

$today = date('Y-m-d');

// Today's record
$stmt = $conn->prepare("SELECT * FROM attendance WHERE student_id = ? AND attendance_date = ? LIMIT 1");
$stmt->bind_param("ss", $student_id, $today);
$stmt->execute();
$record = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Last 10 days history
$hist = $conn->prepare("SELECT * FROM attendance WHERE student_id = ? ORDER BY attendance_date DESC LIMIT 10");
$hist->bind_param("s", $student_id);
$hist->execute();
$history = $hist->get_result()->fetch_all(MYSQLI_ASSOC);
$hist->close();

// Monthly stats
$month_start = date('Y-m-01');
$month_end   = date('Y-m-t');
$mstmt = $conn->prepare("
    SELECT
        COUNT(*) AS total_days,
        SUM(status = 'Present') AS present_days,
        SUM(COALESCE(working_hours, 0)) AS total_hours
    FROM attendance
    WHERE student_id = ? AND attendance_date BETWEEN ? AND ?
");
$mstmt->bind_param("sss", $student_id, $month_start, $month_end);
$mstmt->execute();
$monthly = $mstmt->get_result()->fetch_assoc();
$mstmt->close();

// UI helpers
$has_in     = !empty($record['in_time']);
$has_out    = !empty($record['out_time']);
$is_present = $has_in && $has_out;

$attendance_pct = 0;
if (!empty($monthly['total_days']) && $monthly['total_days'] > 0) {
    $attendance_pct = round(($monthly['present_days'] / $monthly['total_days']) * 100);
}

$total_hrs = $monthly['total_hours'] ?? 0;
$th = floor($total_hrs);
$tm = round(($total_hrs - $th) * 60);

$in_time_display  = $has_in  ? date('H:i', strtotime($record['in_time']))  : '--:--';
$out_time_display = $has_out ? date('H:i', strtotime($record['out_time'])) : '--:--';

$today_wh_display = '—';
if ($has_in && $has_out && $record['working_hours'] !== null) {
    $h2 = floor($record['working_hours']);
    $m2 = round(($record['working_hours'] - $h2) * 60);
    $today_wh_display = "{$h2}h {$m2}m";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Attendance — KEC Internship Portal</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root {
  --green-dark:  #14532d;
  --green-mid:   #16a34a;
  --green-light: #22c55e;
  --green-pale:  #dcfce7;
  --green-50:    #f0fdf4;
  --white:       #ffffff;
  --gray-50:     #f8fafc;
  --gray-100:    #f1f5f9;
  --gray-200:    #e2e8f0;
  --gray-300:    #cbd5e1;
  --gray-400:    #94a3b8;
  --gray-500:    #64748b;
  --gray-600:    #475569;
  --gray-700:    #334155;
  --gray-800:    #1e293b;
  --gray-900:    #0f172a;
  --radius:      12px;
  --radius-lg:   18px;
  --shadow:      0 4px 20px rgba(0,0,0,.08);
  --shadow-lg:   0 12px 40px rgba(0,0,0,.12);
  --shadow-green: 0 8px 32px rgba(22,163,74,.3);
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body { font-family: 'Outfit', sans-serif; background: var(--gray-50); color: var(--gray-800); min-height: 100vh; }

.hero-bar {
  background: linear-gradient(135deg, #064e1b 0%, #166534 30%, #16a34a 65%, #4ade80 100%);
  padding: 0; position: relative; overflow: hidden;
}
.hero-bar::before {
  content: ''; position: absolute; inset: 0;
  background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Ccircle cx='30' cy='30' r='20'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
}
.portal-brand { display: flex; align-items: center; justify-content: center; gap: 12px; padding: 28px 24px 10px; position: relative; z-index: 2; }
.portal-brand .star { color: #86efac; font-size: 1.3rem; }
.portal-brand h1 { font-size: 1.6rem; font-weight: 800; color: white; letter-spacing: .12em; text-transform: uppercase; }
.portal-sub { text-align: center; color: rgba(255,255,255,.65); font-size: .82rem; font-weight: 500; position: relative; z-index: 2; padding-bottom: 4px; }
.portal-sub span { margin: 0 10px; }
.portal-underline { width: 50px; height: 2px; background: white; margin: 8px auto 0; border-radius: 2px; position: relative; z-index: 2; }

.top-nav { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 16px 24px 20px; position: relative; z-index: 2; flex-wrap: wrap; }
.nav-btn { display: flex; align-items: center; gap: 8px; padding: 9px 22px; border-radius: 50px; font-family: 'Outfit', sans-serif; font-size: .82rem; font-weight: 600; letter-spacing: .04em; text-transform: uppercase; text-decoration: none; border: 1.5px solid rgba(255,255,255,.25); color: rgba(255,255,255,.85); background: rgba(255,255,255,.08); cursor: pointer; transition: all .2s; backdrop-filter: blur(8px); }
.nav-btn:hover { background: rgba(255,255,255,.18); color: white; border-color: rgba(255,255,255,.5); }
.nav-btn.active { background: rgba(255,255,255,.95); color: var(--green-dark); border-color: white; box-shadow: 0 4px 16px rgba(0,0,0,.2); }
.nav-btn.back-btn { background: rgba(0,0,0,.2); border-color: rgba(255,255,255,.3); color: rgba(255,255,255,.9); margin-right: 16px; }
.nav-btn.back-btn:hover { background: rgba(0,0,0,.35); color: white; }

.hero-content { text-align: center; padding: 10px 24px 32px; position: relative; z-index: 2; }
.hero-pill { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,.15); border: 1px solid rgba(255,255,255,.3); border-radius: 40px; padding: 6px 18px; font-size: .75rem; font-weight: 700; color: white; letter-spacing: .1em; text-transform: uppercase; margin-bottom: 14px; backdrop-filter: blur(8px); }
.hero-content h2 { font-size: 2.2rem; font-weight: 800; color: white; letter-spacing: -.02em; margin-bottom: 10px; }
.hero-content p { color: rgba(255,255,255,.7); font-size: .9rem; max-width: 500px; margin: 0 auto; line-height: 1.6; }

.page-body { max-width: 1180px; margin: 0 auto; padding: 40px 24px 80px; }

.stat-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 18px; margin-bottom: 32px; }
.stat-card { background: white; border: 1px solid var(--gray-200); border-radius: var(--radius-lg); padding: 24px; box-shadow: var(--shadow); transition: transform .2s, box-shadow .2s; position: relative; overflow: hidden; }
.stat-card::after { content: ''; position: absolute; top: -20px; right: -20px; width: 80px; height: 80px; border-radius: 50%; opacity: .07; }
.stat-card.c-green::after { background: #16a34a; }
.stat-card.c-blue::after  { background: #3b82f6; }
.stat-card.c-amber::after { background: #f59e0b; }
.stat-card.c-violet::after{ background: #8b5cf6; }
.stat-card:hover { transform: translateY(-3px); box-shadow: var(--shadow-lg); }

.stat-icon { width: 44px; height: 44px; border-radius: 12px; display: grid; place-items: center; font-size: 1.05rem; margin-bottom: 16px; }
.si-green  { background: #dcfce7; color: #15803d; }
.si-blue   { background: #eff6ff; color: #2563eb; }
.si-amber  { background: #fefce8; color: #ca8a04; }
.si-violet { background: #f5f3ff; color: #7c3aed; }

.stat-num { font-family: 'JetBrains Mono', monospace; font-size: 2rem; font-weight: 700; color: var(--gray-900); line-height: 1; margin-bottom: 5px; }
.stat-label { font-size: .78rem; color: var(--gray-400); font-weight: 500; }
.stat-trend { display: inline-flex; align-items: center; gap: 4px; font-size: .71rem; font-weight: 600; margin-top: 10px; padding: 3px 10px; border-radius: 20px; }
.trend-up   { background: #dcfce7; color: #15803d; }
.trend-down { background: #fee2e2; color: #b91c1c; }
.trend-gray { background: var(--gray-100); color: var(--gray-500); }

.main-grid { display: grid; grid-template-columns: 1.1fr 1fr; gap: 20px; margin-bottom: 32px; }

.clock-card { background: linear-gradient(135deg, #0f4c24 0%, #166534 45%, #16a34a 100%); border-radius: var(--radius-lg); padding: 36px; color: white; position: relative; overflow: hidden; box-shadow: var(--shadow-green); }
.clock-card::before { content: ''; position: absolute; top: -60px; right: -60px; width: 200px; height: 200px; border-radius: 50%; background: rgba(255,255,255,.05); pointer-events: none; }
.clock-card::after  { content: ''; position: absolute; bottom: -50px; left: -30px; width: 160px; height: 160px; border-radius: 50%; background: rgba(255,255,255,.04); pointer-events: none; }
.clock-label { font-size: .7rem; font-weight: 700; letter-spacing: .14em; text-transform: uppercase; opacity: .6; margin-bottom: 10px; }
.live-time { font-family: 'JetBrains Mono', monospace; font-size: 3.6rem; font-weight: 600; line-height: 1; letter-spacing: -.04em; margin-bottom: 6px; }
.live-date { font-size: .88rem; opacity: .6; margin-bottom: 28px; }
.clock-stats { display: flex; gap: 14px; }
.clk-stat { flex: 1; background: rgba(255,255,255,.1); border-radius: 10px; padding: 13px 14px; backdrop-filter: blur(4px); }
.clk-stat-label { font-size: .65rem; opacity: .6; font-weight: 700; letter-spacing: .07em; text-transform: uppercase; margin-bottom: 4px; }
.clk-stat-val { font-family: 'JetBrains Mono', monospace; font-size: 1rem; font-weight: 600; }

.action-card { background: white; border: 1px solid var(--gray-200); border-radius: var(--radius-lg); padding: 30px; box-shadow: var(--shadow); display: flex; flex-direction: column; gap: 18px; }
.action-head { display: flex; align-items: center; justify-content: space-between; }
.action-title { font-size: 1rem; font-weight: 700; color: var(--gray-900); }
.badge { display: inline-flex; align-items: center; gap: 5px; padding: 4px 12px; border-radius: 40px; font-size: .73rem; font-weight: 600; }
.badge-dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
.badge-present { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
.badge-pending { background: #fef9c3; color: #854d0e; border: 1px solid #fde047; }
.badge-absent  { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }

.gps-strip { background: var(--gray-50); border: 1px solid var(--gray-200); border-radius: 10px; padding: 14px 16px; display: flex; align-items: center; gap: 12px; }
.gps-icon { width: 38px; height: 38px; border-radius: 9px; display: grid; place-items: center; font-size: .95rem; flex-shrink: 0; background: var(--gray-200); color: var(--gray-500); transition: all .3s; }
.gps-icon.ok    { background: #dcfce7; color: #15803d; }
.gps-icon.error { background: #fee2e2; color: #dc2626; }
.gps-info { flex: 1; min-width: 0; }
.gps-title { font-size: .83rem; font-weight: 600; color: var(--gray-700); }
.gps-sub   { font-size: .73rem; color: var(--gray-400); margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.pulse { width: 11px; height: 11px; border-radius: 50%; background: var(--gray-400); flex-shrink: 0; transition: background .3s; }
.pulse.ok { background: var(--green-light); animation: pulse-anim 2s infinite; }
.pulse.error { background: #ef4444; }
@keyframes pulse-anim { 0% { box-shadow: 0 0 0 0 rgba(34,197,94,.5); } 70% { box-shadow: 0 0 0 9px rgba(34,197,94,0); } 100% { box-shadow: 0 0 0 0 rgba(34,197,94,0); } }

.btn-att { width: 100%; padding: 14px 20px; border-radius: 10px; font-family: 'Outfit', sans-serif; font-size: .92rem; font-weight: 600; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 9px; transition: all .2s; }
.btn-att:active { transform: scale(.98); }
.btn-att:disabled { opacity: .4; cursor: not-allowed; }
.btn-checkin { background: linear-gradient(135deg, #15803d, #22c55e); color: white; box-shadow: 0 6px 20px rgba(22,163,74,.35); }
.btn-checkin:hover:not(:disabled) { box-shadow: 0 8px 28px rgba(22,163,74,.5); transform: translateY(-1px); }
.btn-checkout { background: white; color: #15803d; border: 2px solid #86efac; }
.btn-checkout:hover:not(:disabled) { background: #f0fdf4; border-color: #4ade80; }

.prog-wrap { height: 7px; background: var(--gray-100); border-radius: 40px; overflow: hidden; margin-top: 10px; }
.prog-fill { height: 100%; background: linear-gradient(90deg, #16a34a, #4ade80); border-radius: 40px; transition: width 1.2s ease; }

.spinner { width: 17px; height: 17px; border: 2.5px solid rgba(255,255,255,.35); border-top-color: white; border-radius: 50%; animation: spin .7s linear infinite; display: inline-block; }
@keyframes spin { to { transform: rotate(360deg); } }

.quick-stats { display: grid; grid-template-columns: repeat(4, 1fr); background: white; border: 1px solid var(--gray-200); border-radius: var(--radius-lg); box-shadow: var(--shadow); overflow: hidden; margin-bottom: 32px; }
.qs-item { padding: 24px 20px; text-align: center; border-right: 1px solid var(--gray-100); }
.qs-item:last-child { border-right: none; }
.qs-num { font-size: 2.2rem; font-weight: 800; color: var(--gray-900); line-height: 1; margin-bottom: 6px; }
.qs-num.green  { color: #15803d; }
.qs-num.blue   { color: #2563eb; }
.qs-num.amber  { color: #d97706; }
.qs-num.violet { color: #7c3aed; }
.qs-label { font-size: .8rem; color: var(--gray-400); font-weight: 500; }

.section-label { font-size: .72rem; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; color: var(--gray-400); margin-bottom: 16px; display: flex; align-items: center; gap: 12px; }
.section-label::after { content: ''; flex: 1; height: 1px; background: var(--gray-200); }

.table-card { background: white; border: 1px solid var(--gray-200); border-radius: var(--radius-lg); box-shadow: var(--shadow); overflow: hidden; }
.table-head { padding: 20px 24px; border-bottom: 1px solid var(--gray-100); display: flex; align-items: center; justify-content: space-between; }
.table-head h3 { font-size: .95rem; font-weight: 700; color: var(--gray-900); }
.table-head p  { font-size: .75rem; color: var(--gray-400); margin-top: 2px; }

table { width: 100%; border-collapse: collapse; }
thead th { padding: 11px 18px; text-align: left; font-size: .68rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; color: var(--gray-400); background: var(--gray-50); border-bottom: 1px solid var(--gray-200); }
tbody td { padding: 15px 18px; border-bottom: 1px solid var(--gray-100); font-size: .855rem; color: var(--gray-700); vertical-align: middle; }
tbody tr:last-child td { border-bottom: none; }
tbody tr:hover { background: var(--gray-50); }
.date-cell  { font-weight: 600; color: var(--gray-900); }
.time-mono  { font-family: 'JetBrains Mono', monospace; font-size: .8rem; color: #15803d; font-weight: 600; }
.hours-mono { font-family: 'JetBrains Mono', monospace; font-size: .8rem; color: var(--gray-500); }

.toast-wrap { position: fixed; bottom: 24px; right: 24px; z-index: 9999; display: flex; flex-direction: column; gap: 10px; }
.toast { display: flex; align-items: center; gap: 12px; padding: 14px 18px; border-radius: 12px; font-size: .85rem; font-weight: 500; color: white; box-shadow: var(--shadow-lg); transform: translateX(120%); transition: transform .4s cubic-bezier(.34,1.56,.64,1); min-width: 250px; max-width: 320px; }
.toast.show { transform: translateX(0); }
.toast.success { background: linear-gradient(135deg, #15803d, #22c55e); }
.toast.error   { background: linear-gradient(135deg, #7f1d1d, #dc2626); }
.toast-x { margin-left: auto; cursor: pointer; opacity: .7; font-size: .78rem; }

@keyframes fadeUp { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: translateY(0); } }
.fu { animation: fadeUp .5s ease both; }

@media (max-width: 1024px) {
  .stat-grid { grid-template-columns: repeat(2, 1fr); }
  .quick-stats { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 768px) {
  .main-grid { grid-template-columns: 1fr; }
  .stat-grid { grid-template-columns: 1fr 1fr; }
  .live-time { font-size: 2.6rem; }
  .hero-content h2 { font-size: 1.6rem; }
  .page-body { padding: 24px 16px 60px; }
  .clock-stats { flex-wrap: wrap; gap: 10px; }
}
</style>
</head>
<body>

<!-- HERO BAR -->
<div class="hero-bar">
  <div class="portal-brand">
    <span class="star">✦</span>
    <h1>Internship Portal</h1>
  </div>
  <div class="portal-sub">
    <span>Kongu Engineering College</span>|<span>Industry Ready Portal</span>
  </div>
  <div class="portal-underline"></div>
  <nav class="top-nav">
    <a href="consolidate.php" class="nav-btn back-btn">
      <i class="fa-solid fa-arrow-left"></i> Back
    </a>
    <a href="consolidate.php" class="nav-btn active">
      <i class="fa-solid fa-chart-bar"></i> Consolidate
    </a>
    <a href="#" class="nav-btn">
      <i class="fa-solid fa-circle-user"></i> About Us
    </a>
  </nav>
  <div class="hero-content">
    <div class="hero-pill">
      <i class="fa-solid fa-clock"></i>
      Attendance Management
    </div>
    <h2>Mark Your Attendance</h2>
    <p>Track your daily check-ins, working hours, and monthly attendance from a single dashboard.</p>
  </div>
</div>

<!-- QUICK STATS -->
<div style="max-width:1180px;margin:0 auto;padding:0 24px;">
  <div class="quick-stats" style="margin-top:-20px;position:relative;z-index:10;border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);">
    <div class="qs-item">
      <div class="qs-num green"><?= (int)($monthly['present_days'] ?? 0) ?></div>
      <div class="qs-label">Days Present</div>
    </div>
    <div class="qs-item">
      <div class="qs-num blue"><?= $th ?>h</div>
      <div class="qs-label">Hours Logged</div>
    </div>
    <div class="qs-item">
      <div class="qs-num amber" id="qs-today-hours">
        <?php if ($has_in && $has_out):
          $h2 = floor($record['working_hours']); echo "{$h2}h";
        elseif ($has_in): ?><span id="lh-qs">—</span>
        <?php else: ?>—<?php endif; ?>
      </div>
      <div class="qs-label">Today's Hours</div>
    </div>
    <div class="qs-item">
      <div class="qs-num violet"><?= $attendance_pct ?>%</div>
      <div class="qs-label">Avg. Attendance</div>
    </div>
  </div>
</div>

<!-- MAIN PAGE BODY -->
<div class="page-body">

  <!-- Stat cards -->
  <div class="stat-grid" style="margin-top:32px;">
    <div class="stat-card c-green fu">
      <div class="stat-icon si-green"><i class="fa-solid fa-calendar-check"></i></div>
      <div class="stat-num"><?= (int)($monthly['present_days'] ?? 0) ?></div>
      <div class="stat-label">Days Present (This Month)</div>
      <div class="stat-trend <?= $attendance_pct >= 75 ? 'trend-up' : 'trend-down' ?>">
        <i class="fa-solid fa-arrow-<?= $attendance_pct >= 75 ? 'up' : 'down' ?>"></i>
        <?= $attendance_pct ?>% Attendance
      </div>
    </div>
    <div class="stat-card c-blue fu">
      <div class="stat-icon si-blue"><i class="fa-solid fa-hourglass-half"></i></div>
      <div class="stat-num"><?= $th ?><span style="font-size:1rem">h</span></div>
      <div class="stat-label">Hours Logged (This Month)</div>
      <div class="stat-trend trend-gray"><i class="fa-solid fa-clock"></i> <?= $th ?>h <?= $tm ?>m total</div>
    </div>
    <div class="stat-card c-amber fu">
      <div class="stat-icon si-amber"><i class="fa-solid fa-business-time"></i></div>
      <div class="stat-num" id="today-hours">
        <?php if ($has_in && $has_out): echo $today_wh_display;
        elseif ($has_in): ?><span id="lh-display">—</span>
        <?php else: ?>—<?php endif; ?>
      </div>
      <div class="stat-label">Today's Working Hours</div>
      <div class="stat-trend trend-gray"><i class="fa-solid fa-map-pin"></i> Location verified</div>
    </div>
    <div class="stat-card c-violet fu">
      <div class="stat-icon si-violet"><i class="fa-solid fa-percent"></i></div>
      <div class="stat-num"><?= $attendance_pct ?>%</div>
      <div class="stat-label">Monthly Attendance Rate</div>
      <div class="prog-wrap"><div class="prog-fill" id="att-bar" style="width:0%"></div></div>
    </div>
  </div>

  <!-- Clock + Action -->
  <div class="main-grid">

    <!-- Clock card -->
    <div class="clock-card fu">
      <div class="clock-label"><i class="fa-regular fa-clock"></i> &nbsp;Live Clock</div>
      <div class="live-time" id="live-clock">--:--:--</div>
      <div class="live-date" id="live-date">—</div>
      <div class="clock-stats">
        <div class="clk-stat">
          <div class="clk-stat-label">Check-In</div>
          <div class="clk-stat-val" id="clk-in"><?= $in_time_display ?></div>
        </div>
        <div class="clk-stat">
          <div class="clk-stat-label">Check-Out</div>
          <div class="clk-stat-val" id="clk-out"><?= $out_time_display ?></div>
        </div>
        <div class="clk-stat">
          <div class="clk-stat-label">Status</div>
          <div class="clk-stat-val" id="clk-status">
            <?php if ($is_present): ?>✓ Present
            <?php elseif ($has_in): ?>◑ In Progress
            <?php else: ?>— Not Marked<?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- Action card -->
    <div class="action-card fu">
      <div class="action-head">
        <div class="action-title">Mark Attendance</div>
        <span class="badge <?= $is_present ? 'badge-present' : ($has_in ? 'badge-pending' : 'badge-absent') ?>" id="status-badge">
          <span class="badge-dot"></span>
          <span id="status-text"><?= $is_present ? 'Present' : ($has_in ? 'In Progress' : 'Not Marked') ?></span>
        </span>
      </div>

      <!-- Student info -->
      <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;background:var(--gray-50);border-radius:10px;border:1px solid var(--gray-200);">
        <div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#15803d,#4ade80);display:grid;place-items:center;color:white;font-weight:700;font-size:1rem;flex-shrink:0;">
          <?= strtoupper(substr($student_name, 0, 1)) ?>
        </div>
        <div>
          <div style="font-size:.88rem;font-weight:600;color:var(--gray-800);"><?= htmlspecialchars($student_name) ?></div>
          <div style="font-size:.73rem;color:var(--gray-400);"><?= htmlspecialchars($register_no) ?> · Intern · <?= date('d M Y') ?></div>
        </div>
      </div>

      <!-- GPS strip -->
      <div class="gps-strip" id="gps-strip">
        <div class="gps-icon" id="gps-icon"><i class="fa-solid fa-location-crosshairs"></i></div>
        <div class="gps-info">
          <div class="gps-title" id="gps-title">Acquiring GPS Signal…</div>
          <div class="gps-sub"   id="gps-sub">Allow location access when prompted</div>
        </div>
        <div class="pulse" id="pulse-ring"></div>
      </div>

      <!-- Buttons -->
      <button class="btn-att btn-checkin" id="btn-in" <?= $has_in ? 'disabled' : '' ?>>
        <?php if ($has_in): ?>
          <i class="fa-solid fa-circle-check"></i> Checked In · <?= $in_time_display ?>
        <?php else: ?>
          <i class="fa-solid fa-right-to-bracket"></i> Check IN
        <?php endif; ?>
      </button>

      <button class="btn-att btn-checkout" id="btn-out" <?= (!$has_in || $has_out) ? 'disabled' : '' ?>>
        <?php if ($has_out): ?>
          <i class="fa-solid fa-circle-check"></i> Checked Out · <?= $out_time_display ?>
        <?php else: ?>
          <i class="fa-solid fa-right-from-bracket"></i> Check OUT
        <?php endif; ?>
      </button>

      <p style="font-size:.73rem;color:var(--gray-400);text-align:center;">
        <i class="fa-solid fa-shield-halved" style="color:#16a34a"></i>
        Location verified · Must be within 100 m of company
      </p>
    </div>
  </div>

  <!-- History table -->
  <?php if (!empty($history)): ?>
  <div class="section-label">Recent Attendance</div>
  <div class="table-card fu">
    <div class="table-head">
      <div>
        <h3>Attendance History</h3>
        <p>Last <?= count($history) ?> records</p>
      </div>
      <span class="badge badge-present">
        <span class="badge-dot"></span><?= (int)($monthly['present_days'] ?? 0) ?> Days Present
      </span>
    </div>
    <div style="overflow-x:auto">
      <table>
        <thead>
          <tr>
            <th>Date</th><th>In Time</th><th>Out Time</th>
            <th>Working Hours</th><th>Distance</th><th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($history as $row): ?>
          <tr>
            <td class="date-cell"><?= date('d M Y', strtotime($row['attendance_date'])) ?></td>
            <td><?= !empty($row['in_time'])  ? '<span class="time-mono">'.date('H:i', strtotime($row['in_time'])).'</span>'  : '<span style="color:var(--gray-300)">—</span>' ?></td>
            <td><?= !empty($row['out_time']) ? '<span class="time-mono">'.date('H:i', strtotime($row['out_time'])).'</span>' : '<span style="color:var(--gray-300)">—</span>' ?></td>
            <td>
              <?php if ($row['working_hours'] !== null):
                $rh = floor($row['working_hours']); $rm = round(($row['working_hours']-$rh)*60);
                echo '<span class="hours-mono">'.$rh.'h '.$rm.'m</span>';
              else: echo '<span style="color:var(--gray-300)">—</span>'; endif; ?>
            </td>
            <td>
              <?php $d = $row['in_distance'] ?? null; ?>
              <?= $d !== null ? '<span style="font-size:.78rem;color:var(--gray-500)">'.round($d).' m</span>' : '<span style="color:var(--gray-300)">—</span>' ?>
            </td>
            <td>
              <?php $s = $row['status'] ?? 'Absent'; ?>
              <span class="badge badge-<?= strtolower($s) ?>">
                <span class="badge-dot"></span><?= $s ?>
              </span>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

</div><!-- /page-body -->

<div class="toast-wrap" id="toastWrap"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ── PHP values passed to JS ───────────────────────────────────────────────
const STUDENT_ID   = <?= json_encode((string)$student_id) ?>;
const STUDENT_NAME = <?= json_encode($student_name) ?>;
const REGISTER_NO  = <?= json_encode($register_no) ?>;
const COMPANY_LAT  = <?= json_encode((float)$company_lat) ?>;
const COMPANY_LNG  = <?= json_encode((float)$company_lng) ?>;
const ATT_PCT      = <?= json_encode((int)$attendance_pct) ?>;
const HAS_IN       = <?= $has_in  ? 'true' : 'false' ?>;
const HAS_OUT      = <?= $has_out ? 'true' : 'false' ?>;
<?php if ($has_in && !$has_out): ?>
const IN_TIME_ISO  = <?= json_encode(str_replace(' ', 'T', $record['in_time'])) ?>;
<?php endif; ?>

// ── Progress bar ──────────────────────────────────────────────────────────
window.addEventListener('load', () => {
  setTimeout(() => {
    const b = document.getElementById('att-bar');
    if (b) b.style.width = ATT_PCT + '%';
  }, 500);
});

// ── Live clock ────────────────────────────────────────────────────────────
(function() {
  const el  = document.getElementById('live-clock');
  const de  = document.getElementById('live-date');
  const DAYS   = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  function tick() {
    const n = new Date();
    el.textContent = [n.getHours(), n.getMinutes(), n.getSeconds()]
      .map(x => String(x).padStart(2,'0')).join(':');
    de.textContent = `${DAYS[n.getDay()]}, ${n.getDate()} ${MONTHS[n.getMonth()]} ${n.getFullYear()}`;
  }
  tick(); setInterval(tick, 1000);
})();

// ── Live working-hours counter (checked in but not yet out) ───────────────
<?php if ($has_in && !$has_out): ?>
(function() {
  const inTime = new Date(IN_TIME_ISO);
  let liveTimer = null;

  function startLiveCounter() {
    if (liveTimer) return;
    liveTimer = setInterval(() => {
      const secs = Math.floor((Date.now() - inTime) / 1000);
      const h = Math.floor(secs / 3600);
      const m = Math.floor((secs % 3600) / 60);
      const s = secs % 60;
      const el1 = document.getElementById('lh-display');
      const el2 = document.getElementById('lh-qs');
      if (el1) el1.textContent = `${h}h ${String(m).padStart(2,'0')}m ${String(s).padStart(2,'0')}s`;
      if (el2) el2.textContent = `${h}h`;
    }, 1000);
  }
  startLiveCounter();
  window._stopLiveTimer = function() { if (liveTimer) { clearInterval(liveTimer); liveTimer = null; } };
})();
<?php endif; ?>

// ── Toast helper ──────────────────────────────────────────────────────────
function showToast(msg, type = 'success') {
  const wrap = document.getElementById('toastWrap');
  const t = document.createElement('div');
  const icon = type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation';
  t.className = `toast ${type}`;
  t.innerHTML = `<i class="fa-solid ${icon}"></i><span>${msg}</span>`
              + `<i class="fa-solid fa-xmark toast-x" onclick="this.parentElement.remove()"></i>`;
  wrap.appendChild(t);
  requestAnimationFrame(() => requestAnimationFrame(() => t.classList.add('show')));
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, 5000);
}

// ── Haversine ─────────────────────────────────────────────────────────────
function haversine(lat1, lng1, lat2, lng2) {
  const R = 6371000, r = x => x * Math.PI / 180;
  const a = Math.sin(r(lat2-lat1)/2)**2
          + Math.cos(r(lat1)) * Math.cos(r(lat2)) * Math.sin(r(lng2-lng1)/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

let userLat = null, userLng = null, locReady = false, within = false;

function updateGPS(lat, lng) {
  const dist = haversine(lat, lng, COMPANY_LAT, COMPANY_LNG);
  within = dist <= 100;
  const icon  = document.getElementById('gps-icon');
  const title = document.getElementById('gps-title');
  const sub   = document.getElementById('gps-sub');
  const ring  = document.getElementById('pulse-ring');
  icon.className  = `gps-icon ${within ? 'ok' : 'error'}`;
  icon.innerHTML  = `<i class="fa-solid ${within ? 'fa-location-dot' : 'fa-triangle-exclamation'}"></i>`;
  ring.className  = `pulse ${within ? 'ok' : 'error'}`;
  title.textContent  = within ? '✓ Within Company Premises' : '✗ Outside Company Premises';
  title.style.color  = within ? '#15803d' : '#dc2626';
  sub.textContent    = `${Math.round(dist)} m from office  ·  ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
}

if (navigator.geolocation) {
  navigator.geolocation.watchPosition(
    pos => {
      userLat  = pos.coords.latitude;
      userLng  = pos.coords.longitude;
      locReady = true;
      updateGPS(userLat, userLng);
    },
    err => {
      document.getElementById('gps-title').textContent = '⚠ Location Unavailable';
      document.getElementById('gps-sub').textContent   = err.message;
    },
    { enableHighAccuracy: true, maximumAge: 10000 }
  );
} else {
  document.getElementById('gps-title').textContent = '⚠ Geolocation not supported';
}

// ── Attendance action (IN / OUT) ──────────────────────────────────────────
async function doAction(type) {
  if (!locReady) { showToast('Waiting for GPS fix — try again shortly.', 'error'); return; }
  if (!within)   { showToast('You must be within 100 m of the company.', 'error'); return; }

  const btn  = document.getElementById(`btn-${type}`);
  const orig = btn.innerHTML;
  btn.disabled  = true;
  btn.innerHTML = `<span class="spinner"></span> Saving…`;

  const fd = new FormData();
  fd.append('action',       type);
  fd.append('lat',          userLat);
  fd.append('lng',          userLng);
  fd.append('distance',     haversine(userLat, userLng, COMPANY_LAT, COMPANY_LNG).toFixed(2));
  fd.append('student_id',   STUDENT_ID);
  fd.append('student_name', STUDENT_NAME);
  fd.append('register_no',  REGISTER_NO);

  try {
    const res  = await fetch(window.location.href, { method: 'POST', body: fd });
    const text = await res.text();

    // Strip any BOM or whitespace before JSON
    const clean = text.trim().replace(/^\uFEFF/, '');

    let data;
    try {
      data = JSON.parse(clean);
    } catch(e) {
      console.error('Server returned non-JSON:', text);
      showToast('Server error. Please check PHP error logs.', 'error');
      btn.innerHTML = orig;
      btn.disabled  = false;
      return;
    }

    if (data.success) {
      showToast(data.message, 'success');

      if (type === 'in') {
        const inT = data.in_time || new Date().toTimeString().slice(0,5);
        btn.innerHTML = `<i class="fa-solid fa-circle-check"></i> Checked In · ${inT}`;
        btn.disabled  = true;

        const btnOut = document.getElementById('btn-out');
        btnOut.disabled  = false;
        btnOut.innerHTML = `<i class="fa-solid fa-right-from-bracket"></i> Check OUT`;

        document.getElementById('clk-in').textContent = inT;
        document.getElementById('clk-status').textContent = '◑ In Progress';

        const badge = document.getElementById('status-badge');
        badge.className = 'badge badge-pending';
        document.getElementById('status-text').textContent = 'In Progress';

        // Start live counter
        const inTimeNow = new Date();
        const thEl = document.getElementById('today-hours');
        if (thEl) thEl.innerHTML = '<span id="lh-display">0h 00m 00s</span>';
        const qsEl = document.getElementById('qs-today-hours');
        if (qsEl) qsEl.innerHTML = '<span id="lh-qs">0h</span>';

        setInterval(() => {
          const secs = Math.floor((Date.now() - inTimeNow) / 1000);
          const h = Math.floor(secs / 3600);
          const m = Math.floor((secs % 3600) / 60);
          const s = secs % 60;
          const el1 = document.getElementById('lh-display');
          const el2 = document.getElementById('lh-qs');
          if (el1) el1.textContent = `${h}h ${String(m).padStart(2,'0')}m ${String(s).padStart(2,'0')}s`;
          if (el2) el2.textContent = `${h}h`;
        }, 1000);

      } else {
        const outT = data.out_time      || new Date().toTimeString().slice(0,5);
        const wh   = data.working_hours || '—';

        btn.innerHTML = `<i class="fa-solid fa-circle-check"></i> Checked Out · ${outT}`;
        btn.disabled  = true;

        document.getElementById('clk-out').textContent    = outT;
        document.getElementById('clk-status').textContent = '✓ Present';

        const badge = document.getElementById('status-badge');
        badge.className = 'badge badge-present';
        document.getElementById('status-text').textContent = 'Present';

        // Stop live counter and show final hours
        if (typeof window._stopLiveTimer === 'function') window._stopLiveTimer();
        const el1 = document.getElementById('lh-display');
        const el2 = document.getElementById('lh-qs');
        const thEl = document.getElementById('today-hours');
        const qsEl = document.getElementById('qs-today-hours');
        if (el1)  el1.textContent  = wh;
        if (el2)  el2.textContent  = wh.split(' ')[0];
        if (thEl) thEl.textContent = wh;
        if (qsEl) qsEl.textContent = wh.split(' ')[0];

        setTimeout(() => location.reload(), 2000);
      }

    } else {
      showToast(data.message || 'Something went wrong.', 'error');
      btn.innerHTML = orig;
      btn.disabled  = false;
    }

  } catch(e) {
    console.error(e);
    showToast('Network error. Please try again.', 'error');
    btn.innerHTML = orig;
    btn.disabled  = false;
  }
}

document.getElementById('btn-in') .addEventListener('click', () => doAction('in'));
document.getElementById('btn-out').addEventListener('click', () => doAction('out'));
</script>

</body>
</html>