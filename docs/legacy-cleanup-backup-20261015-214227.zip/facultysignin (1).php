<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Signup | Internship Portal</title>

  <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">

  <style>
    *{
      margin:0;
      padding:0;
      box-sizing:border-box;
    }

    :root {
      --blue-900: #041b11;
      --blue-800: #072b18;
      --blue-700: #0b4425;
      --blue-600: #116530;
      --blue-500: #15803d;
      --blue-400: #22c55e;
      --blue-300: #4ade80;
      --blue-100: #dcfce7;
      --blue-50:  #f0fdf4;
      --accent:   #86efac;
      --white:    #ffffff;
      --text-dark: #0b1d13;
      --text-mid:  #36543d;
      --text-muted:#5f7d66;
    }

    body{
      font-family:'DM Sans', sans-serif;
      background:linear-gradient(135deg,var(--blue-900),var(--blue-700));
      min-height:100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      padding:30px 20px;
    }

    .signup-container{
      width:100%;
      max-width:850px;
      background:#fff;
      border-radius:28px;
      overflow:hidden;
      box-shadow:0 25px 60px rgba(0,0,0,0.35);
    }

    .signup-header{
      background:linear-gradient(135deg,var(--blue-800),var(--blue-500));
      padding:35px 30px;
      text-align:center;
    }

    .signup-header h1{
      font-family:'Sora', sans-serif;
      font-size:2rem;
      font-weight:800;
      color:#fff;
      letter-spacing:1px;
    }

    .signup-header p{
      color:var(--blue-100);
      margin-top:8px;
      font-size:0.95rem;
    }

    .signup-form{
      padding:35px 30px;
    }

    .form-grid{
      display:grid;
      grid-template-columns:1fr 1fr;
      gap:22px;
    }

    .form-group{
      display:flex;
      flex-direction:column;
    }

    .form-group.full{
      grid-column:1 / -1;
    }

    .form-group label{
      margin-bottom:8px;
      font-weight:700;
      color:var(--blue-700);
      font-size:0.9rem;
    }

    .form-group input,
    .form-group select,
    .form-group textarea{
      padding:14px 16px;
      border:2px solid var(--blue-100);
      border-radius:14px;
      font-size:0.95rem;
      outline:none;
      transition:0.25s;
      background:var(--blue-50);
      color:var(--text-dark);
    }

    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus{
      border-color:var(--blue-400);
      background:#fff;
      box-shadow:0 0 0 4px rgba(74,222,128,0.18);
    }

    textarea{
      resize:none;
      min-height:100px;
    }

    .submit-btn{
      margin-top:30px;
      width:100%;
      border:none;
      border-radius:50px;
      padding:16px;
      background:linear-gradient(135deg,var(--blue-600),var(--blue-400));
      color:#fff;
      font-family:'Sora', sans-serif;
      font-size:1rem;
      font-weight:700;
      cursor:pointer;
      transition:0.25s;
      box-shadow:0 10px 25px rgba(17,101,48,0.35);
    }

    .submit-btn:hover{
      transform:translateY(-3px);
      background:linear-gradient(135deg,var(--blue-700),var(--blue-500));
      box-shadow:0 16px 35px rgba(17,101,48,0.45);
    }

    .bottom-text{
      text-align:center;
      margin-top:18px;
      color:var(--text-muted);
      font-size:0.9rem;
    }

    .bottom-text a{
      color:var(--blue-600);
      font-weight:700;
      text-decoration:none;
    }

    @media(max-width:768px){
      .form-grid{
        grid-template-columns:1fr;
      }

      .signup-header h1{
        font-size:1.6rem;
      }

      .signup-form{
        padding:25px 20px;
      }
    }
  </style>
</head>
<body>

<div class="signup-container">

  <div class="signup-header">
    <h1>🎓 Faculty Signup</h1>
    <p>Internship Management Portal - Kongu Engineering College</p>
  </div>

<form class="signup-form" action="faculty_signup_process.php" method="POST">

    <div class="form-grid">

      <div class="form-group">
        <label>Kongu ID</label>
        <input type="text" name="roll_number" placeholder="Enter Kongu Gmail ID" required>
      </div>

      <div class="form-group">
        <label>Faculty Name</label>
        <input type="text" name="student_name" placeholder="Enter Faculty Name" required>
      </div>
      <div class="form-group">
        <label>New Password</label>
        <input type="password" name="password" placeholder="Enter New Password" required>
      </div>
      <div class="form-group">
        <label>Confirm Password</label>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
      </div>

      <div class="form-group">
        <label>Department</label>
        <select name="department" required>
          <option value="">Select Department</option>
          <option>CSE</option>
          <option>ECE</option>
          <option>EEE</option>
          <option>ARCH</option>
          <option>AUTO</option>
          <option>CSD</option>
          <option>EIE</option>
          <option>MTS</option>
          <option>CHEM</option>
          <option>FT</option>
          <option>IT</option>
          <option>MECH</option>
          <option>CIVIL</option>
          <option>AIDS</option>
          <option>AIML</option>
        </select>
      </div>


      

    </div>

    <button type="submit" class="submit-btn" >
      🚀 Create Faculty Account
    </button>

    

  </form>

</div>

</body>
</html>