<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "internship";

/* DATABASE CONNECTION */
$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}

/* GET FORM DATA */
$roll_number = $_POST['roll_number'];
$student_name = $_POST['student_name'];
$department = $_POST['department'];
$year_section = $_POST['year_section'];
$semester = $_POST['semester'];
$duration = $_POST['duration'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$company_name = $_POST['company_name'];
$company_location = $_POST['company_location'];
$raw_password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

/* CHECK PASSWORD MATCH */
if ($raw_password != $confirm_password) {

    echo "
    <script>
        alert('Password and Confirm Password do not match!');
        window.history.back();
    </script>
    ";

    exit();
}

/* HASH PASSWORD */
$password = password_hash($raw_password, PASSWORD_DEFAULT);
/* INSERT QUERY */
$sql = "INSERT INTO student_signup
(
    roll_number,
    student_name,
    password,
    department,
    year_section,
    semester,
    duration,
    start_date,
    end_date,
    company_name,
    company_location
)

VALUES
(
    '$roll_number',
    '$student_name',
    '$password',
    '$department',
    '$year_section',
    '$semester',
    '$duration',
    '$start_date',
    '$end_date',
    '$company_name',
    '$company_location'
)";

/* EXECUTE */
if (mysqli_query($conn, $sql)) {

    echo "
    <script>
     
        window.location.href='index.php';
    </script>
    ";

} else {

    echo "Error: " . mysqli_error($conn);

}

mysqli_close($conn);

?>