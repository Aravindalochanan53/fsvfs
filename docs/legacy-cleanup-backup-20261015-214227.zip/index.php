<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>KEC Portal</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

:root{
  --bg:       #080f09;
  --surface:  #0e1a10;
  --card:     #121f14;
  --border:   rgba(255,255,255,0.07);
  --border-h: rgba(74,200,100,0.45);
  --green:    #4ac864;
  --green-d:  #2e8a42;
  --green-dim:#1a3d22;
  --text:     #e8f0e9;
  --muted:    #6b896e;
  --white:    #ffffff;
}

html,body{
  height:100%;
  background:var(--bg);
  color:var(--text);
  font-family:'DM Sans',sans-serif;
  -webkit-font-smoothing:antialiased;
}

body{
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  min-height:100vh;
  padding:24px;
  position:relative;
  overflow:hidden;
}

/* subtle grid lines */
body::before{
  content:'';
  position:fixed;inset:0;
  background-image:
    linear-gradient(rgba(74,200,100,0.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(74,200,100,0.03) 1px, transparent 1px);
  background-size:60px 60px;
  pointer-events:none;
}

/* glow blob */
body::after{
  content:'';
  position:fixed;
  width:600px;height:600px;
  border-radius:50%;
  background:radial-gradient(circle, rgba(46,138,66,0.12) 0%, transparent 70%);
  top:50%;left:50%;
  transform:translate(-50%,-50%);
  pointer-events:none;
}

.shell{
  width:100%;
  max-width:440px;
  position:relative;
  z-index:10;
  animation:rise .55s cubic-bezier(.22,1,.36,1) both;
}

@keyframes rise{
  from{opacity:0;transform:translateY(32px)}
  to{opacity:1;transform:translateY(0)}
}

/* ── header ── */
.header{
  text-align:center;
  margin-bottom:48px;
}

.kec-badge{
  display:inline-flex;
  align-items:center;
  gap:7px;
  border:1px solid var(--border);
  border-radius:999px;
  padding:5px 14px;
  font-size:11px;
  letter-spacing:1.4px;
  text-transform:uppercase;
  color:var(--muted);
  margin-bottom:22px;
  background:var(--surface);
}
.kec-badge span.dot{
  width:6px;height:6px;
  border-radius:50%;
  background:var(--green);
  box-shadow:0 0 6px var(--green);
}

.college-name{
  font-family:'DM Serif Display',serif;
  font-size:clamp(22px,5vw,30px);
  color:var(--white);
  line-height:1.15;
  letter-spacing:-0.5px;
  margin-bottom:10px;
}
.college-name em{
  font-style:italic;
  color:var(--green);
}

.tagline{
  font-size:13px;
  color:var(--muted);
  letter-spacing:0.2px;
}

/* ── prompt ── */
.prompt{
  font-size:11px;
  letter-spacing:2px;
  text-transform:uppercase;
  color:var(--muted);
  margin-bottom:14px;
}

/* ── role cards ── */
.roles{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:12px;
  margin-bottom:20px;
}

.role{
  border:1px solid var(--border);
  border-radius:16px;
  background:var(--card);
  padding:28px 20px 24px;
  cursor:pointer;
  transition:
    border-color .2s,
    background .2s,
    transform .18s;
  position:relative;
  overflow:hidden;
  outline:none;
  text-align:left;
}

/* shimmer line at top */
.role::before{
  content:'';
  position:absolute;
  top:0;left:0;right:0;
  height:2px;
  background:linear-gradient(90deg,transparent,var(--green),transparent);
  opacity:0;
  transition:opacity .25s;
}

.role:hover{
  border-color:var(--border-h);
  background:#151f16;
  transform:translateY(-3px);
}
.role:hover::before{ opacity:.7; }

.role.chosen{
  border-color:var(--green);
  background:var(--green-dim);
  transform:translateY(-3px);
}
.role.chosen::before{ opacity:1; }

/* tick */
.tick{
  position:absolute;
  top:12px;right:12px;
  width:20px;height:20px;
  border-radius:50%;
  background:var(--green);
  display:flex;align-items:center;justify-content:center;
  opacity:0;
  transform:scale(.5);
  transition:opacity .2s, transform .2s;
}
.role.chosen .tick{
  opacity:1;
  transform:scale(1);
}
.tick svg{stroke:#080f09;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round;}

.role-icon{
  width:44px;height:44px;
  border-radius:12px;
  background:var(--green-dim);
  border:1px solid rgba(74,200,100,0.2);
  display:flex;align-items:center;justify-content:center;
  margin-bottom:16px;
  transition:background .2s;
}
.role.chosen .role-icon{ background:rgba(74,200,100,0.18); }
.role-icon svg{ width:22px;height:22px; stroke:var(--green); stroke-width:1.8; fill:none; stroke-linecap:round;stroke-linejoin:round; }

.role-title{
  font-size:16px;
  font-weight:500;
  color:var(--white);
  margin-bottom:4px;
}
.role-desc{
  font-size:12px;
  color:var(--muted);
  line-height:1.5;
}

/* ── CTA ── */
.cta{
  width:100%;
  padding:15px;
  border:none;
  border-radius:12px;
  background:var(--green);
  color:#080f09;
  font-family:'DM Sans',sans-serif;
  font-size:14px;
  font-weight:600;
  letter-spacing:0.3px;
  cursor:pointer;
  display:flex;align-items:center;justify-content:center;gap:8px;
  transition:background .18s, transform .14s, opacity .18s;
  position:relative;
  overflow:hidden;
}
.cta::after{
  content:'';
  position:absolute;inset:0;
  background:rgba(255,255,255,0.12);
  opacity:0;
  transition:opacity .18s;
}
.cta:hover:not(:disabled)::after{ opacity:1; }
.cta:hover:not(:disabled){ transform:translateY(-1px); }
.cta:active:not(:disabled){ transform:scale(.98); }
.cta:disabled{
  background:var(--green-dim);
  color:var(--muted);
  cursor:not-allowed;
}
.cta svg{width:16px;height:16px;stroke:currentColor;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round;transition:transform .18s;}
.cta:hover:not(:disabled) svg{transform:translateX(3px);}

/* ── footer ── */
.footer{
  text-align:center;
  margin-top:28px;
  font-size:11px;
  color:var(--muted);
  letter-spacing:0.3px;
}
.footer span{
  color:rgba(74,200,100,0.6);
}

/* ── responsive ── */
@media(max-width:400px){
  .roles{grid-template-columns:1fr 1fr;gap:10px;}
  .role{padding:22px 14px 18px;}
}
</style>
</head>
<body>

<div class="shell">

  <header class="header">
    <div class="kec-badge">
      <span class="dot"></span>
      Academic Portal
    </div>
    <h1 class="college-name">Kongu<br/><em>Engineering College</em></h1>
    <p class="tagline">Erode — Autonomous Institution</p>
  </header>

  <p class="prompt">I am a —</p>

  <div class="roles">

    <button class="role" id="r-student" onclick="pick('student')" aria-pressed="false">
      <div class="tick">
        <svg viewBox="0 0 12 12"><polyline points="2 6 5 9 10 3"/></svg>
      </div>
      <div class="role-icon">
        <!-- graduation cap -->
        <svg viewBox="0 0 24 24">
          <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
          <path d="M6 12v5c3 3 9 3 12 0v-5"/>
        </svg>
      </div>
      <div class="role-title">Student</div>
      <div class="role-desc">Attendance, marks &amp; timetable</div>
    </button>

    <button class="role" id="r-faculty" onclick="pick('faculty')" aria-pressed="false">
      <div class="tick">
        <svg viewBox="0 0 12 12"><polyline points="2 6 5 9 10 3"/></svg>
      </div>
      <div class="role-icon">
        <!-- person + board -->
        <svg viewBox="0 0 24 24">
          <rect x="2" y="3" width="20" height="14" rx="2"/>
          <path d="M8 21h8M12 17v4"/>
          <path d="M9 10l2 2 4-4"/>
        </svg>
      </div>
      <div class="role-title">Faculty</div>
      <div class="role-desc">Courses, attendance &amp; reports</div>
    </button>

  </div>

  <button class="cta" id="cta" disabled onclick="proceed()">
    <span id="cta-label">Select your role</span>
    <svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
  </button>

  <p class="footer">Powered by <span>Linways AMS</span> &nbsp;·&nbsp; KEC</p>

</div>

<script>
  var chosen = null;

  /* ← Replace these with your real login page URLs */
  var loginUrls = {
    student: 'studentlogin.php',
    faculty: 'facultylogin.php'
  };

  function pick(role) {
    chosen = role;
    ['student','faculty'].forEach(function(r){
      var el = document.getElementById('r-' + r);
      el.classList.toggle('chosen', r === role);
      el.setAttribute('aria-pressed', r === role ? 'true' : 'false');
    });
    var cta = document.getElementById('cta');
    var lbl = document.getElementById('cta-label');
    cta.disabled = false;
    lbl.textContent = 'Continue as ' + (role === 'student' ? 'Student' : 'Faculty');
  }

  function proceed() {
    if (!chosen) return;
    window.location.href = loginUrls[chosen];
  }

  /* keyboard shortcut: 1 = student, 2 = faculty, Enter = proceed */
  document.addEventListener('keydown', function(e){
    if (e.key === '1') pick('student');
    if (e.key === '2') pick('faculty');
    if (e.key === 'Enter' && chosen) proceed();
  });
</script>

</body>
</html>