<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>KEC Internship Portal | Smart Internship Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
    --blue-900: #041b11;
    --blue-800: #072b18;
    --blue-700: #0b4425;
    --blue-600: #116530;
    --blue-500: #15803d;
    --blue-400: #22c55e;
    --blue-300: #4ade80;
    --blue-100: #dcfce7;
    --blue-50:  #f0fdf4;

    --accent:   #86efac;

    --white:    #ffffff;

    --text-dark: #0b1d13;
    --text-mid:  #36543d;
    --text-muted:#5f7d66;
}

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'DM Sans', sans-serif;
            background: #f0f6ff;
            color: var(--text-dark);
        }

        /* ---- HEADER ---- */
        .site-header {
            background: linear-gradient(135deg, var(--blue-900) 0%, var(--blue-700) 60%, var(--blue-500) 100%);
            padding: 18px 20px 14px;
            text-align: center;
            position: sticky;
            top: 0;
            z-index: 1030;
            box-shadow: 0 4px 24px rgba(10,22,40,0.35);
        }
        .site-header h1 {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 1.9rem;
            letter-spacing: 3px;
            color: #fff;
            text-transform: uppercase;
        }
        .site-header p {
            font-size: 0.85rem;
            color: var(--blue-300);
            margin-top: 2px;
            letter-spacing: 0.5px;
        }
        .header-line {
            width: 60px;
            height: 3px;
            background: var(--accent);
            margin: 8px auto 0;
            border-radius: 2px;
        }

        /* ---- NAVBAR ---- */
        
        .site-nav { background: var(--white); border-bottom: 2px solid var(--blue-100); position: sticky; top: 78px; z-index: 1020; box-shadow: 0 2px 12px rgba(18,81,181,0.08); }
        .site-nav nav { display: flex; justify-content: center; gap: 10px; padding: 10px 16px; flex-wrap: wrap; }
        .site-nav .nav-btn { font-family: 'Sora', sans-serif; font-weight: 600; font-size: 0.82rem; letter-spacing: 0.5px; color: var(--blue-600); border: 2px solid var(--blue-100); background: var(--blue-50); border-radius: 40px; padding: 7px 20px; text-decoration: none; transition: all 0.22s ease; white-space: nowrap; }
        .site-nav .nav-btn:hover, .site-nav .nav-btn.active { background: var(--blue-600); color: #fff; border-color: var(--blue-600); box-shadow: 0 4px 16px rgba(18,81,181,0.3); transform: translateY(-1px); }


        /* ---- CAROUSEL ---- */
        .carousel-section {
            padding: 28px 16px 0;
            max-width: 1200px;
            margin: 0 auto;
        }
        .carousel-wrap {
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 16px 48px rgba(10,22,40,0.18);
            position: relative;
        }
        .carousel-item img {
            width: 100%;
            height: 360px;
            object-fit: cover;
            filter: brightness(0.88);
        }
        /* Blue overlay on slides */
        .carousel-item::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, transparent 40%, rgba(10,22,40,0.55) 100%);
            pointer-events: none;
        }
        .carousel-caption {
            z-index: 10;
            bottom: 28px;
        }
        .carousel-caption h5 {
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 1.3rem;
            text-shadow: 0 2px 8px rgba(0,0,0,0.5);
        }
        .carousel-caption p {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        .carousel-indicators [data-bs-target] {
            background-color: var(--accent);
            width: 28px;
            height: 4px;
            border-radius: 2px;
            opacity: 0.5;
            border: none;
        }
        .carousel-indicators .active { opacity: 1; }

        /* ---- HERO SPLIT SECTION ---- */
        .hero-section {
            max-width: 1200px;
            margin: 52px auto 0;
            padding: 0 20px;
        }
        .hero-text h2 {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 2.5rem;
            line-height: 1.15;
            color: var(--blue-800);
        }
        .hero-text h2 span {
            color: var(--blue-500);
        }
        .hero-text p {
            font-size: 1.05rem;
            color: var(--text-mid);
            margin-top: 16px;
            line-height: 1.7;
            max-width: 520px;
        }
        .hero-btn {
            display: inline-block;
            margin-top: 24px;
            background: linear-gradient(135deg, var(--blue-600), var(--blue-400));
            color: #fff;
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 0.95rem;
            padding: 14px 36px;
            border-radius: 50px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(18,81,181,0.35);
            transition: all 0.25s;
        }
        .hero-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 32px rgba(18,81,181,0.45);
            color: #fff;
        }
        .hero-img-wrap {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .hero-img-bg {
            width: 310px;
            height: 310px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--blue-100), var(--blue-300));
            position: absolute;
        }
        .semi-img {
            width: 290px;
            height: 290px;
            border-radius: 50%;
            object-fit: cover;
            border: 5px solid #fff;
            box-shadow: 0 20px 48px rgba(10,22,40,0.2);
            position: relative;
            z-index: 2;
            transition: transform 0.3s;
        }
        .semi-img:hover { transform: scale(1.03); }

        /* ---- FEATURE CARDS ---- */
        .features-section {
            max-width: 1200px;
            margin: 56px auto 0;
            padding: 0 20px;
        }
        .section-title {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 1.9rem;
            color: var(--blue-800);
            text-align: center;
            margin-bottom: 8px;
        }
        .section-sub {
            text-align: center;
            color: var(--text-muted);
            font-size: 1rem;
            margin-bottom: 36px;
        }
        .feat-card {
            background: #fff;
            border-radius: 20px;
            padding: 32px 24px;
            box-shadow: 0 4px 20px rgba(18,81,181,0.07);
            border: 1.5px solid var(--blue-100);
            transition: all 0.25s;
            height: 100%;
            text-align: center;
        }
        .feat-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 16px 40px rgba(18,81,181,0.15);
            border-color: var(--blue-300);
        }
        .feat-icon {
            font-size: 2.4rem;
            display: block;
            margin-bottom: 14px;
        }
        .feat-card h4 {
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--blue-700);
            margin-bottom: 10px;
        }
        .feat-card p { color: var(--text-muted); font-size: 0.94rem; line-height: 1.6; }

        /* ---- INFO BAND ---- */
        .info-band {
            background: linear-gradient(135deg, var(--blue-800), var(--blue-600));
            margin: 56px 0 0;
            padding: 52px 20px;
            text-align: center;
        }
        .info-band h2 {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 1.8rem;
            color: #fff;
            margin-bottom: 14px;
        }
        .info-band p {
            color: var(--blue-200, #bfdbfe);
            font-size: 1.02rem;
            max-width: 720px;
            margin: 0 auto;
            line-height: 1.7;
        }

        /* ---- GRID CARDS (Features / Benefits) ---- */
        .grid-section {
            max-width: 1200px;
            margin: 56px auto 0;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
        }
        .grid-card {
            background: #fff;
            border-radius: 20px;
            padding: 28px 24px;
            border: 1.5px solid var(--blue-100);
            box-shadow: 0 4px 16px rgba(18,81,181,0.06);
            transition: all 0.25s;
        }
        .grid-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(18,81,181,0.14);
            border-color: var(--blue-400);
        }
        .grid-card-title {
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 1.05rem;
            color: var(--blue-700);
            margin-bottom: 16px;
            padding-bottom: 10px;
            border-bottom: 3px solid var(--blue-100);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .grid-card ul {
            list-style: none;
            padding: 0;
        }
        .grid-card ul li {
            padding: 7px 0 7px 28px;
            position: relative;
            font-size: 0.93rem;
            color: var(--text-mid);
            border-bottom: 1px solid #f0f6ff;
        }
        .grid-card ul li:last-child { border-bottom: none; }
        .grid-card ul li::before {
            content: "✓";
            color: var(--blue-500);
            font-weight: 700;
            position: absolute;
            left: 0;
        }

        /* ---- WHY SECTION ---- */
        .why-section {
            max-width: 1200px;
            margin: 56px auto 0;
            padding: 0 20px;
            text-align: center;
        }

        /* ---- OVERVIEW BAND ---- */
        .overview-band {
            background: var(--white);
            border: 1.5px solid var(--blue-100);
            border-radius: 24px;
            max-width: 1100px;
            margin: 56px auto 0;
            padding: 48px 36px;
            text-align: center;
            box-shadow: 0 8px 32px rgba(18,81,181,0.07);
        }
        .overview-band h2 {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 1.8rem;
            color: var(--blue-800);
            margin-bottom: 14px;
        }
        .overview-band p {
            color: var(--text-mid);
            font-size: 1rem;
            line-height: 1.75;
            max-width: 700px;
            margin: 0 auto 24px;
        }
        .badge-pill {
            display: inline-block;
            background: var(--blue-50);
            color: var(--blue-700);
            border: 1.5px solid var(--blue-200, #bfdbfe);
            border-radius: 40px;
            padding: 8px 20px;
            font-size: 0.87rem;
            font-weight: 600;
            margin: 5px;
            font-family: 'Sora', sans-serif;
        }

        /* ---- FOOTER ---- */
        footer {
            background: var(--blue-900);
            margin-top: 64px;
            padding: 36px 20px;
            text-align: center;
        }
        footer p { color: var(--blue-300); font-size: 0.88rem; margin-bottom: 4px; }
        footer .footer-line {
            width: 50px;
            height: 2px;
            background: var(--accent);
            margin: 12px auto;
            border-radius: 2px;
        }

        /* ---- RESPONSIVE ---- */
        @media (max-width: 768px) {
            .hero-text h2 { font-size: 1.8rem; }
            .hero-img-bg, .semi-img { width: 230px; height: 230px; }
            .carousel-item img { height: 240px; }
            .section-title { font-size: 1.5rem; }
            .overview-band { padding: 32px 20px; }
        }
        @media (max-width: 480px) {
            .site-header h1 { font-size: 1.4rem; letter-spacing: 2px; }
            .site-nav .nav-btn { font-size: 0.75rem; padding: 6px 14px; }
        }
    </style>
</head>
<body>

<!-- ==================== HEADER ==================== -->
<div class="site-header">
    <h1>✦ INTERNSHIP PORTAL</h1>
    <p>Kongu Engineering College &nbsp;|&nbsp; Industry Ready Portal</p>
    
</div>

<!-- ==================== NAVBAR ==================== -->
<div class="site-nav">
    <nav>
        <a class="nav-btn" href="home1.php">🏠 HOME</a>
        <a class="nav-btn" href="consolidate.php">📊 CONSOLIDATE</a>
        
        <a class="nav-btn" href="about1.php">ℹ️ ABOUT US</a>
    </nav>
</div>

<!-- ==================== CAROUSEL ==================== -->
<div class="carousel-section">
    <div class="carousel-wrap">
        <div id="demo" class="carousel slide" data-bs-ride="carousel">
            <!-- Indicators -->
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#demo" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#demo" data-bs-slide-to="2" aria-label="Slide 3"></button>
                <button type="button" data-bs-target="#demo" data-bs-slide-to="3" aria-label="Slide 4"></button>
            </div>
            <!-- Slides with Unsplash images -->
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=1200&q=80" class="d-block w-100" alt="Students collaborating">
                    <div class="carousel-caption">
                        <h5>🎓 Launch Your Career</h5>
                        <p>Connect with top industry partners through KEC Internship Portal</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=1200&q=80" class="d-block w-100" alt="Engineering internship">
                    <div class="carousel-caption">
                        <h5>⚙️ Industry-Ready Training</h5>
                        <p>Gain hands-on experience in cutting-edge engineering domains</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?w=1200&q=80" class="d-block w-100" alt="Campus life">
                    <div class="carousel-caption">
                        <h5>🏛️ Kongu Engineering College</h5>
                        <p>Perundurai, Erode — shaping tomorrow's innovators</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&q=80" class="d-block w-100" alt="Team meeting">
                    <div class="carousel-caption">
                        <h5>📊 Track &amp; Report</h5>
                        <p>Effortless internship documentation for students &amp; faculty</p>
                    </div>
                </div>
            </div>
            <!-- Controls -->
            <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
</div>

<!-- ==================== HERO SPLIT SECTION ==================== -->
<div class="hero-section">
    <div class="row align-items-center g-5">
        <div class="col-md-6 hero-text">
            <h2>Empowering Students at <span>Kongu Engineering College</span></h2>
            <p>This portal helps students easily manage internship details, track attendance and generate consolidated reports. It improves the documentation process and helps faculty monitor progress efficiently.</p>
            <button class="hero-btn">✨ Explore Features</button>
        </div>
        <div class="col-md-6 hero-img-wrap">
            <div class="hero-img-bg"></div>
            <img src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600&q=80" class="semi-img" alt="Campus students">
        </div>
    </div>
</div>

<!-- ==================== FEATURE CARDS ==================== -->
<div class="features-section">
    <h2 class="section-title">What We Offer</h2>
    <p class="section-sub">Everything you need to manage internships, in one place.</p>
    <div class="row g-4">
        <div class="col-md-4">
            <div class="feat-card">
                <span class="feat-icon">📌</span>
                <h4>Easy Tracking</h4>
                <p>Maintain internship data with a simple form system and track real-time progress effortlessly.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="feat-card">
                <span class="feat-icon">🔒</span>
                <h4>Secure Records</h4>
                <p>All student internship details stored safely with role-based access controls.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="feat-card">
                <span class="feat-icon">⚡</span>
                <h4>Quick Reports</h4>
                <p>Generate consolidated reports instantly for faculty review and verification.</p>
            </div>
        </div>
    </div>
</div>

<!-- ==================== INFO BAND ==================== -->
<div class="info-band">
    <h2>🏛️ Kongu Engineering College</h2>
    <p>Kongu Engineering College is committed to providing quality education and encouraging students to develop technical and professional skills. The institution supports innovation, industry interaction and research activities which help students gain knowledge beyond classroom learning.</p>
</div>

<!-- ==================== GRID CARDS (Features / Student / Faculty) ==================== -->
<div class="grid-section">
    <div class="grid-card">
        <div class="grid-card-title">📋 Portal Features</div>
        <ul>
            <li>Maintain internship details</li>
            <li>Organized student records</li>
            <li>Easy navigation system</li>
            <li>Centralized data storage</li>
            <li>Simple user interface</li>
        </ul>
    </div>
    <div class="grid-card">
        <div class="grid-card-title">🎓 Student Benefits</div>
        <ul>
            <li>Track internship progress</li>
            <li>Store company details</li>
            <li>Access report anytime</li>
            <li>Improve documentation</li>
            <li>Better academic record</li>
        </ul>
    </div>
    <div class="grid-card">
        <div class="grid-card-title">👨‍🏫 Faculty Benefits</div>
        <ul>
            <li>Monitor student activity</li>
            <li>Verify internship records</li>
            <li>Easy report checking</li>
            <li>Department level tracking</li>
            <li>Improved data management</li>
        </ul>
    </div>
</div>

<!-- ==================== WHY SECTION ==================== -->
<div class="why-section mt-5">
    <h2 class="section-title">Why Internship Portal?</h2>
    <p class="section-sub" style="max-width:700px; margin: 0 auto;">The system reduces manual work and improves accuracy of data. Students and faculty can easily manage internship activities in a professional and streamlined way.</p>
</div>

<!-- ==================== SECOND GRID (Workflow / Highlights / Future) ==================== -->
<div class="grid-section">
    <div class="grid-card">
        <div class="grid-card-title">⚙️ Workflow</div>
        <ul>
            <li>Register / Login</li>
            <li>Fill Internship Form</li>
            <li>Submit Attendance</li>
            <li>Generate Consolidated Report</li>
            <li>Faculty Verification</li>
        </ul>
    </div>
    <div class="grid-card">
        <div class="grid-card-title">✨ Highlights</div>
        <ul>
            <li>Simple interface</li>
            <li>Fast data entry</li>
            <li>Secure storage</li>
            <li>Easy report generation</li>
            <li>Useful for academic records</li>
        </ul>
    </div>
    <div class="grid-card">
        <div class="grid-card-title">🚀 Future Scope</div>
        <ul>
            <li>Company feedback integration</li>
            <li>Certificate upload</li>
            <li>Internship analytics</li>
            <li>Placement preparation tools</li>
            <li>Skill tracking</li>
        </ul>
    </div>
</div>

<!-- ==================== SYSTEM OVERVIEW ==================== -->
<div class="overview-band" style="margin-left:auto; margin-right:auto; margin-bottom: 0;">
    <h2>📌 System Overview</h2>
    <p>The Internship Consolidated Report Portal provides a structured way to manage internship information for students and faculty. The system reduces manual work and improves accuracy of data. It helps maintain proper documentation of internship activities in a professional format.</p>
    <div>
        <span class="badge-pill">📅 Real-time Tracking</span>
        <span class="badge-pill">📑 Consolidated Reports</span>
        <span class="badge-pill">🔐 Role-based Access</span>
    </div>
</div>

<!-- ==================== FOOTER ==================== -->
<footer>
    <p>© 2025 Kongu Engineering College — Internship Management Portal</p>
    <p>📍 Perundurai, Erode, Tamil Nadu &nbsp;|&nbsp; 📧 internship@kongu.edu</p>
    <div class="footer-line"></div>
    <p>Empowering students with industry-ready internship tracking</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var carousels = document.querySelectorAll('.carousel');
        carousels.forEach(function (carousel) {
            new bootstrap.Carousel(carousel, { interval: 3800, wrap: true, touch: true });
        });
        const btns = document.querySelectorAll('.nav-btn');
        btns.forEach(btn => {
            btn.addEventListener('mouseenter', () => btn.style.letterSpacing = '0.8px');
            btn.addEventListener('mouseleave', () => btn.style.letterSpacing = '0.5px');
        });
    });
</script>
</body>
</html>