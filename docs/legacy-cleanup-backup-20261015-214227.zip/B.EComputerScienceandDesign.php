<?php
$conn = mysqli_connect("localhost", "root", "", "internship");
$sql = "SELECT * FROM student_signup WHERE department='CSD'";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Internship Registry</title>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
  <style>
    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background: linear-gradient(135deg, #EAF3DE 0%, #f5fbf0 50%, #dff0d4 100%);
      min-height: 100vh;
      padding: 2.5rem 1.5rem;
      color: #2C2C2A;
    }

    .page-wrapper {
      max-width: 900px;
      margin: 0 auto;
    }

    /* ── Header ── */
    .page-header {
      display: flex;
      align-items: center;
      gap: 16px;
      margin-bottom: 2rem;
    }

    .logo-box {
      width: 52px;
      height: 52px;
      background: #27500A;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      box-shadow: 0 4px 12px rgba(39,80,10,0.25);
    }

    .logo-box i {
      font-size: 26px;
      color: #C0DD97;
    }

    .header-text h1 {
      font-size: 22px;
      font-weight: 700;
      color: #27500A;
      letter-spacing: -0.3px;
    }

    .header-text p {
      font-size: 13px;
      color: #3B6D11;
      margin-top: 3px;
    }

    .dept-badge {
      display: inline-block;
      background: #27500A;
      color: #C0DD97;
      font-size: 11px;
      font-weight: 700;
      padding: 4px 12px;
      border-radius: 20px;
      letter-spacing: 0.8px;
      margin-left: 10px;
      vertical-align: middle;
    }

    /* ── Stats Bar ── */
    .stats-bar {
      display: flex;
      gap: 12px;
      margin-bottom: 1.5rem;
      flex-wrap: wrap;
    }

    .stat-card {
      background: #fff;
      border: 1.5px solid #C0DD97;
      border-radius: 12px;
      padding: 12px 20px;
      display: flex;
      align-items: center;
      gap: 10px;
      flex: 1;
      min-width: 150px;
    }

    .stat-icon {
      width: 36px;
      height: 36px;
      background: #EAF3DE;
      border-radius: 9px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .stat-icon i {
      font-size: 18px;
      color: #3B6D11;
    }

    .stat-info label {
      display: block;
      font-size: 11px;
      color: #639922;
      font-weight: 600;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }

    .stat-info span {
      font-size: 20px;
      font-weight: 700;
      color: #27500A;
    }

    /* ── Table Card ── */
    .table-card {
      background: #fff;
      border-radius: 16px;
      border: 1.5px solid #C0DD97;
      overflow: hidden;
      box-shadow: 0 4px 24px rgba(39,80,10,0.08);
    }

    .table-toolbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 14px 20px;
      border-bottom: 1.5px solid #EAF3DE;
      background: #F5FAF0;
    }

    .toolbar-title {
      font-size: 14px;
      font-weight: 600;
      color: #27500A;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .toolbar-title i {
      font-size: 16px;
      color: #639922;
    }

    .live-dot {
      width: 8px;
      height: 8px;
      background: #639922;
      border-radius: 50%;
      display: inline-block;
      animation: pulse 2s infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.5; transform: scale(0.85); }
    }

    /* ── Table ── */
    table {
      width: 100%;
      border-collapse: collapse;
    }

    thead tr {
      background: #27500A;
    }

    thead th {
      color: #C0DD97;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 1px;
      text-transform: uppercase;
      padding: 14px 20px;
      text-align: left;
      white-space: nowrap;
    }

    thead th i {
      font-size: 14px;
      vertical-align: -2px;
      margin-right: 6px;
      opacity: 0.8;
    }

    tbody tr {
      border-bottom: 1px solid #EAF3DE;
      transition: background 0.15s ease;
    }

    tbody tr:last-child {
      border-bottom: none;
    }

    tbody tr:hover {
      background: #EAF3DE;
    }

    tbody tr:nth-child(even) {
      background: #F5FAF0;
    }

    tbody tr:nth-child(even):hover {
      background: #EAF3DE;
    }

    td {
      padding: 13px 20px;
      vertical-align: middle;
      font-size: 14px;
      color: #2C2C2A;
    }

    /* Roll number */
    td:first-child {
      font-weight: 700;
      color: #3B6D11;
      font-size: 13px;
      font-family: monospace;
      letter-spacing: 0.5px;
    }

    /* Name */
    td:nth-child(2) {
      font-weight: 500;
    }

    /* Department pill */
    .dept-pill {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      background: #C0DD97;
      color: #27500A;
      font-size: 12px;
      font-weight: 700;
      padding: 4px 12px;
      border-radius: 20px;
      letter-spacing: 0.3px;
    }

    .dept-pill i {
      font-size: 12px;
    }

    /* Company cell */
    .company-cell {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .company-avatar {
      width: 30px;
      height: 30px;
      background: #EAF3DE;
      border: 1.5px solid #C0DD97;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 11px;
      font-weight: 700;
      color: #27500A;
      flex-shrink: 0;
    }

    /* ── Empty State ── */
    .empty-state {
      text-align: center;
      padding: 3rem 1rem;
      color: #639922;
    }

    .empty-state i {
      font-size: 40px;
      color: #C0DD97;
      display: block;
      margin-bottom: 10px;
    }

    .empty-state p {
      font-size: 14px;
      font-weight: 500;
    }

    /* ── Footer ── */
    .page-footer {
      margin-top: 1.25rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 8px;
    }

    .footer-note {
      font-size: 12px;
      color: #3B6D11;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .footer-note i {
      font-size: 14px;
    }

    .footer-time {
      font-size: 12px;
      color: #639922;
    }
  </style>
</head>
<body>

<div class="page-wrapper">

  <!-- Header -->
  <div class="page-header">
    <div class="logo-box">
      <i class="ti ti-school"></i>
    </div>
    <div class="header-text">
      <h1>Internship Registry <span class="dept-badge">CSD</span></h1>
      <p>Student Placement Records</p>
    </div>
  </div>

  <!-- Stats Bar -->
  <?php
    // Re-run count query for stats
    $count_result = mysqli_query($conn, "SELECT COUNT(*) as total FROM student_signup WHERE department='CSD'");
    $count_row = mysqli_fetch_assoc($count_result);
    $total_students = $count_row['total'];

    $company_result = mysqli_query($conn, "SELECT COUNT(DISTINCT company_name) as total FROM student_signup WHERE department='CSD'");
    $company_row = mysqli_fetch_assoc($company_result);
    $total_companies = $company_row['total'];
  ?>
  <div class="stats-bar">
    <div class="stat-card">
      <div class="stat-icon"><i class="ti ti-users"></i></div>
      <div class="stat-info">
        <label>Total Students</label>
        <span><?php echo $total_students; ?></span>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon"><i class="ti ti-building"></i></div>
      <div class="stat-info">
        <label>Companies</label>
        <span><?php echo $total_companies; ?></span>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon"><i class="ti ti-chart-pie"></i></div>
      <div class="stat-info">
        <label>Department</label>
        <span>CSD</span>
      </div>
    </div>
  </div>

  <!-- Table Card -->
  <div class="table-card">
    <div class="table-toolbar">
      <div class="toolbar-title">
        <i class="ti ti-table"></i>
        Student List
      </div>
      <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:#639922;">
        
       
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th><i class="ti ti-id-badge"></i>Roll No</th>
          <th><i class="ti ti-user"></i>Name</th>
          <th><i class="ti ti-cpu"></i>Department</th>
          <th><i class="ti ti-briefcase"></i>Company</th>
        </tr>
      </thead>
      <tbody>
        <?php if (mysqli_num_rows($result) > 0): ?>
          <?php while ($row = mysqli_fetch_assoc($result)): ?>
          <tr>
            <td><?php echo htmlspecialchars($row['roll_number']); ?></td>
            <td><?php echo htmlspecialchars($row['student_name']); ?></td>
            <td>
              <span class="dept-pill">
                <i class="ti ti-code"></i>
                <?php echo htmlspecialchars($row['department']); ?>
              </span>
            </td>
            <td>
              <div class="company-cell">
                <div class="company-avatar">
                  <?php echo strtoupper(substr($row['company_name'], 0, 2)); ?>
                </div>
                <?php echo htmlspecialchars($row['company_name']); ?>
              </div>
            </td>
          </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="4">
              <div class="empty-state">
                <i class="ti ti-database-off"></i>
                <p>No students found for CSD department.</p>
              </div>
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

 

</div>

</body>
</html>